#!/bin/bash
# helper for local testing: starts the built server in the background with sample content
cd "$(dirname "$0")/.."
export DATA_DIR=${DATA_DIR:-/tmp/olmt} PUBLIC_URL=${PUBLIC_URL:-http://localhost:8099} PORT=${PORT:-8099} CONTENT_DIR=${CONTENT_DIR:-$PWD/tests/fixtures/content}
nohup node --no-warnings --enable-source-maps dist/server.js > /tmp/olm-server.log 2>&1 &
echo $! > /tmp/olm-server.pid
