// Bundles the server + CLI (Node) and the client (browser) with esbuild.
import { build } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'dist');
const buildId = Date.now().toString(36);
fs.mkdirSync(path.join(out, 'public/assets'), { recursive: true });

const node = {
  bundle: true, platform: 'node', format: 'esm', target: 'node22', sourcemap: true,
  external: ['sharp', 'ws', 'node:*'], loader: { '.sql': 'text' }, outdir: out,
  banner: { js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);" },
};
const jobs = [
  build({ ...node, entryPoints: { server: path.join(root, 'server/index.ts'), cli: path.join(root, 'server/cli.ts') } }),
];
if (fs.existsSync(path.join(root, 'client/main.tsx'))) {
  jobs.push(build({
    entryPoints: { app: path.join(root, 'client/main.tsx') }, outdir: path.join(out, 'public/assets'),
    bundle: true, platform: 'browser', format: 'esm', target: ['es2022', 'safari15'], minify: true, jsx: 'automatic',
    define: { 'process.env.NODE_ENV': '"production"' }, entryNames: '[name]', loader: { '.css': 'css' },
  }));
}
await Promise.all(jobs);
let html = fs.readFileSync(path.join(root, 'client/index.html'), 'utf8').replace(/__BUILD__/g, buildId);
fs.writeFileSync(path.join(out, 'public/index.html'), html);
for (const f of fs.readdirSync(path.join(root, 'client/static'))) fs.copyFileSync(path.join(root, 'client/static', f), path.join(out, 'public', f));
console.log('build ok', buildId);
