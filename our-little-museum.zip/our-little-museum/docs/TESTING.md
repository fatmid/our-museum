# Testing

## Automated: `npm run build && npm test` (108 checks)

Starts a real server on a random port with sample content, then drives two independent browser sessions:
**Fatmid** on a 1280×800 laptop and **Fatima** on a 390×844 touch phone (separate cookies, separate WebSockets).

| Your scenario | Checks |
|---|---|
| 1 Fatmid opens the museum on a laptop | 1, 1b–1d |
| 2 Fatima opens the invitation on her phone | 2a, 2/3 |
| 3 Both characters appear in the same room | 3 |
| 4 / 5 Movement seen by the other player | 4, 5, 7a (virtual joystick) |
| 6 Shared viewing of a photograph | 6a–6g |
| 7 Both sit on the same bench | 7a–7f |
| 8 Dance seen by the other player | 8a–8c, 22a–22b (dance together) |
| 9 Proposal invitation, 10 declining it | 9a–9j, 10 |
| 11 Shared music | 11a–11g |
| 12 Connection drops / server restarts | 12a–12g |
| 13 / 14 New photo and room song with no restart | 13, 13b, 14 |
| 15 Unauthorised visitor | 15a–15g |
| 16 Narrow phone screens (390 px and 320 px) | 16, 16b, 16c |
| 17 Refresh and reconnect | 17a–17d |
| 18 Declined hug is neutral | 18a–18e |
| 19 Revoked invitation (also a slow phone tapping "Open" early) | 19a–19g |
| 20 Separate browsers | the whole run uses two independent sessions |
| Also covered | timeline (20a–c), hold hands (21a–c), Space key (23), new look + reduced motion (24), photo moment incl. the saved PNG (25a–d), Promise Room pedestal (26), notes + HTML stripping (N1–N3), second window takeover (8d–8e), room music offer (1d), no browser errors |

## Manual checklist on real devices (after you deploy)

Do this once with your own two phones, ideally one on Wi-Fi and one on mobile data.

- [ ] Scan the QR code with the phone camera: the welcome page opens over https with no warnings.
- [ ] Tap **OPEN OUR MUSEUM ♡**: doors open, you walk in (try the same on iPhone Safari and Android Chrome).
- [ ] With Fatmid already inside, Fatima sees his character at once, and he sees hers appear.
- [ ] Walk with the joystick; the other phone sees you walk smoothly, and you cannot pass through walls or benches.
- [ ] Open a photo together ("Join her?"), then sit together on a bench ("Some memories are better together").
- [ ] Dance, wave, heart, kiss, spin; hug and hold-hands invitations (try declining one).
- [ ] The proposal: Fatima receives the invitation, answers each of the three ways in separate tries.
- [ ] Play a song together (the first tap on each phone is needed for sound); pause on one, the other pauses.
- [ ] Take a memory together and save the picture to the phone's gallery.
- [ ] Turn on aeroplane mode for 10 seconds, then off: she reappears at the same spot without reloading.
- [ ] Lock the screen for a minute and unlock: the museum reconnects by itself.
- [ ] Revoke the invitation with `revoke <id>` and confirm that device is sent to the gate.
- [ ] Open the public address in a private window: only the gate is visible; `/api/museum` says 401.
