// The museum screen: canvas + HUD + every panel, wired to the game engine and the WebSocket.
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { otherSlot, type Anim, type IxKind, type MessageRow, type MuseumBundle, type NoteRow, type Slot } from '../shared/types';
import { findPath, type WFrame } from '../shared/world';
import { api, store } from './api';
import { Net, type NetStatus } from './net';
import { Music } from './music';
import { Game, type GameUi } from './engine/game';
import { ActionsPanel, ComposePanel, GuidePanel, IncomingInvite, InboxPanel, MenuPanel, MusicPanel, NoteCard, PhotoPickPanel, PhotoResultPanel, ProposalOverlay, SettingsPanel, TimelinePanel, ViewerPanel } from './ui/panels';
import { Joystick, Minimap, Modal, Toasts, useToasts } from './ui/parts';

const EMPTY_UI: GameUi = { roomId: null, roomName: '', peerRoomId: null, peerOnline: false, peerName: '', peerDist: 999, near: null, seated: false, locked: false, anim: 'idle', peerSeated: false, connected: false };
const noopSub = () => () => {};
const PROPOSAL_STAGES = ['kneel', 'ring', 'msg1', 'msg2', 'ask', 'yes', 'hug', 'later'];

interface IxInfo { id: string; kind: IxKind; from: Slot; to: Slot; stage: string; data: any }
type Modal_ = null | 'timeline' | 'compose' | 'inbox' | 'guide' | 'settings' | 'photoPick' | 'pedestal' | 'leave' | { k: 'note'; msg: MessageRow | null } | { k: 'photoResult'; shot: HTMLCanvasElement; frame: string };

function pickMessage(msgs: MessageRow[], roomId: number | null, recent: number[]): MessageRow | null {
  if (!msgs.length) return null;
  const roomOnes = msgs.filter((m) => m.room_id != null && m.room_id === roomId), general = msgs.filter((m) => m.room_id == null);
  const fresh = (l: MessageRow[]) => l.filter((m) => !recent.includes(m.id));
  const rs = fresh(roomOnes), g = fresh(general);
  let pool = rs.length && (Math.random() < 0.45 || !g.length) ? rs : g;
  if (!pool.length) { recent.length = 0; pool = roomOnes.length && Math.random() < 0.45 ? roomOnes : general.length ? general : msgs; }
  const m = pool[Math.floor(Math.random() * pool.length)];
  recent.push(m.id); while (recent.length > 40) recent.shift();
  return m;
}

export function Museum({ initial, onLeave, onSignedOut }: { initial: MuseumBundle; onLeave: () => void; onSignedOut: () => void }) {
  const me = initial.you; const peerSlot = otherSlot(me);
  const [bundle, setBundle] = useState(initial);
  const bundleRef = useRef(bundle); bundleRef.current = bundle;
  const names = useMemo(() => ({ fatmid: bundle.players.fatmid.name, fatima: bundle.players.fatima.name }), [bundle]);
  const looks = useMemo(() => ({ fatmid: bundle.players.fatmid.look, fatima: bundle.players.fatima.look }), [bundle]);
  const features = bundle.settings.features;
  const touch = useMemo(() => { try { return window.matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window; } catch { return false; } }, []);
  const [reduced, setReducedState] = useState(() => { const s = store.get('reduced'); if (s != null) return s === '1'; try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } });

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [core, setCore] = useState<{ net: Net; game: Game; music: Music } | null>(null);
  const toasts = useToasts(); const toastRef = useRef(toasts.push); toastRef.current = toasts.push;
  const [status, setStatus] = useState<NetStatus>('connecting');
  const [veil, setVeil] = useState(true);
  const [sheet, setSheet] = useState<null | 'actions' | 'menu' | 'music'>(null);
  const [modal, setModal] = useState<Modal_>(null);
  const [viewId, setViewId] = useState<number | null>(null); const viewRef = useRef<number | null>(null); viewRef.current = viewId;
  const [together, setTogether] = useState(false);
  const [peerView, setPeerView] = useState<{ frame: number; slot: Slot; name: string } | null>(null);
  const [invite, setInvite] = useState<{ id: string; kind: IxKind; from: Slot } | null>(null);
  const [outgoing, setOutgoing] = useState<{ id: string; kind: IxKind } | null>(null);
  const [ix, setIx] = useState<IxInfo | null>(null); const ixRef = useRef<IxInfo | null>(null); ixRef.current = ix;
  const [count, setCount] = useState<number | null>(null);
  const [flash, setFlash] = useState(0);
  const [unread, setUnread] = useState(0);
  const [offer, setOffer] = useState<{ track: number; title: string } | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const shotRef = useRef<HTMLCanvasElement | null>(null); const photoFrameRef = useRef('classic');
  const recentRef = useRef<number[]>((() => { try { return JSON.parse(store.get('recent', '[]') || '[]'); } catch { return []; } })());
  const offeredRooms = useRef(new Set<number>()); const firstWelcome = useRef(true);

  // ---------------------------------------------------------------- refresh content (after the museum is updated)
  const refreshing = useRef(false);
  const refresh = useCallback(async () => {
    if (refreshing.current) return; refreshing.current = true;
    try { const b = await api<MuseumBundle>('/api/museum'); setBundle(b); core?.game.setBundle(b); core?.music.setTracks(b.tracks); }
    catch (e: any) { if (e?.status === 401) onSignedOut(); }
    finally { setTimeout(() => { refreshing.current = false; }, 800); }
  }, [core, onSignedOut]);
  const refreshRef = useRef(refresh); refreshRef.current = refresh;

  // ---------------------------------------------------------------- viewer helpers
  const openFrameById = useCallback((id: number) => {
    if (!core) return; setViewId(id); setSheet(null); setPeerView((pv) => (pv?.frame === id ? null : pv)); core.net.send({ t: 'view', frame: id });
  }, [core]);
  const closeViewer = useCallback(() => { setViewId(null); setTogether(false); core?.net.send({ t: 'view', frame: null }); }, [core]);

  // ---------------------------------------------------------------- create the engine
  useEffect(() => {
    const net = new Net(); const music = new Music(net, bundleRef.current.settings.default_volume); music.setTracks(bundleRef.current.tracks);
    const game = new Game(canvasRef.current!, bundleRef.current, net, {
      openFrame: (f: WFrame) => openRef.current(f.id), openMusic: () => setSheet('music'), pedestal: () => pedestalRef.current(),
      toast: (t) => toastRef.current(t), wantRefresh: () => refreshRef.current(), waved: () => {},
    }, reduced);
    const offStatus = net.onStatus((s) => setStatus(s)); net.connect(); setCore({ net, game, music });
    const t = setTimeout(() => setVeil(false), 9000);
    return () => { clearTimeout(t); offStatus(); game.destroy(); music.destroy(); net.close(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const openRef = useRef(openFrameById); openRef.current = openFrameById;
  const pedestalRef = useRef(() => {}); pedestalRef.current = () => {
    if (features.proposal && me === 'fatmid') setModal('pedestal'); else toastRef.current('A quiet place for big questions ♡', true);
  };

  // Test hook: only exists when a tester sets localStorage "olm.debug" = "1". It exposes nothing the page does not already hold.
  useEffect(() => { if (core && store.get('debug') === '1') (window as any).__olm = { ...core, findPath }; }, [core]);

  const ui = useSyncExternalStore(core ? core.game.subscribe : noopSub, core ? core.game.getUi : () => EMPTY_UI);
  const mv = useSyncExternalStore(core ? core.music.subscribe.bind(core.music) : noopSub, core ? () => core.music.view : () => null as any);
  useEffect(() => { if (core && mv) core.game.musicPlaying = mv.playing; }, [core, mv?.playing]);
  // a "listen together" request must be seen even when the music panel is closed
  useEffect(() => { if (mv?.shareRequest) { setSheet('music'); toastRef.current(`${mv.shareRequest} would like to listen together ♡`, true); } }, [mv?.shareRequest]);
  useEffect(() => { core?.game.setReduced(reduced); store.set('reduced', reduced ? '1' : '0'); }, [core, reduced]);

  // ---------------------------------------------------------------- unread notes
  useEffect(() => { api<NoteRow[]>('/api/notes').then((n) => setUnread(n.filter((x) => x.to_slot === me && !x.read_at).length)).catch(() => {}); }, [me]);

  // ---------------------------------------------------------------- network events
  useEffect(() => {
    if (!core) return; const { net, game, music } = core;
    return net.on((m: any) => {
      switch (m.t) {
        case 'welcome': {
          setVeil(false); setIx(m.ix || null); setPeerView(null); setTogether(false);
          if (viewRef.current != null) net.send({ t: 'view', frame: viewRef.current }); // restore shared viewing after a reconnect
          if (firstWelcome.current) {
            firstWelcome.current = false; const pn = bundleRef.current.players[otherSlot(me)].name;
            if (!m.peer?.online) toastRef.current(`${pn} isn't here yet ♡ You will see them the moment they arrive.`);
            if (!store.get('hint-seen')) { setHint(touch ? 'Drag the round pad to walk · tap the button when something is nearby' : 'Use the arrow keys or WASD to walk · E to interact'); store.set('hint-seen', '1'); setTimeout(() => setHint(null), 8000); }
          }
          break;
        }
        case 'ix_invite': setInvite({ id: m.id, kind: m.kind, from: m.from }); break;
        case 'ix_invite_sent': setOutgoing({ id: m.id, kind: m.kind }); break;
        case 'ix_start':
          setInvite(null); setOutgoing(null); setIx(m.ix); setSheet(null); setModal((x) => (x && typeof x === 'object' && x.k === 'photoResult' ? x : null));
          if (viewRef.current != null) closeViewerRef.current();
          photoFrameRef.current = m.ix?.data?.frame || 'classic';
          break;
        case 'ix_stage': {
          setIx((p) => (p && p.id === m.id ? { ...p, stage: m.stage, data: { ...p.data, ...(m.data || {}) } } : p));
          if (m.stage === 'count') setCount(m.data?.n ?? null); else setCount(null);
          if (m.stage === 'flash') { shotRef.current = game.capture(); setFlash((k) => k + 1); }
          if (m.stage === 'ring') { const tr = ixRef.current?.data?.track; if (tr != null && !music.view.playing && !music.view.shared) music.play(tr); }
          break;
        }
        case 'ix_end': {
          setInvite((p) => (p && p.id === m.id ? null : p)); setOutgoing((p) => (p && p.id === m.id ? null : p)); setIx(null); setCount(null);
          const pn = bundleRef.current.players[otherSlot(me)].name;
          if (m.result === 'declined' && m.from === me) toastRef.current('That is okay, maybe a little later ♡');
          else if (m.result === 'expired' && m.from === me) toastRef.current('No answer just yet, maybe a little later ♡');
          else if (m.result === 'left') toastRef.current(`${pn} stepped away ♡`);
          else if (m.result === 'done' && m.kind === 'photo' && shotRef.current) setModal({ k: 'photoResult', shot: shotRef.current, frame: photoFrameRef.current });
          else if (m.result === 'done' && m.kind === 'hug') toastRef.current('♡', true);
          break;
        }
        case 'peer_view': if (m.frame == null) setPeerView(null); else if (bundleRef.current.settings.features.sharedViewing && viewRef.current !== m.frame) setPeerView({ frame: m.frame, slot: m.s, name: m.name || bundleRef.current.players[m.s as Slot].name }); break;
        case 'together_view': setTogether(m.frame != null && m.frame === viewRef.current); if (m.frame != null) setPeerView(null); break;
        case 'view_auto': openRef.current(m.frame); break;
        case 'view_closed': setViewId(null); setTogether(false); break;
        case 'note': setUnread((u) => u + 1); toastRef.current(`A note from ${bundleRef.current.players[m.note.from_slot as Slot].name} is waiting ♡`, true); break;
        case 'notice': toastRef.current(m.text); break;
        case 'together_sit': toastRef.current('Some memories are better together.', true); break;
      }
    });
  }, [core, me, touch]);
  const closeViewerRef = useRef(closeViewer); closeViewerRef.current = closeViewer;

  // ---------------------------------------------------------------- room music offers
  useEffect(() => {
    if (!core || ui.roomId == null || !mv || offeredRooms.current.has(ui.roomId)) return;
    offeredRooms.current.add(ui.roomId);
    const room = bundle.rooms.find((r) => r.id === ui.roomId); const tid = room?.music_track_id;
    if (tid == null || mv.shared || (mv.track === tid && mv.playing)) return;
    const title = bundle.tracks.find((t) => t.id === tid)?.title; if (!title) return;
    setOffer({ track: tid, title }); const t = setTimeout(() => setOffer((o) => (o?.track === tid ? null : o)), 14000); return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ui.roomId, core]);

  // ---------------------------------------------------------------- keyboard: Escape closes sheets
  useEffect(() => { const f = (e: KeyboardEvent) => { if (e.key === 'Escape') setSheet(null); }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); }, []);

  const proposalOn = ix?.kind === 'propose' && PROPOSAL_STAGES.includes(ix.stage);
  const blocked = !!modal || viewId != null || !!invite || status === 'replaced' || status === 'signedout';
  useEffect(() => { core?.game.setBlocked(blocked); }, [core, blocked]);

  // ---------------------------------------------------------------- actions
  const send = (m: any) => core?.net.send(m);
  const act = (a: Anim) => { core?.game.act(a); setSheet(null); };
  const askTogether = (kind: IxKind) => { send({ t: 'invite', kind, data: kind === 'dance' ? { variant: 1 + Math.floor(Math.random() * 3) } : undefined }); setSheet(null); setModal(null); };
  const showNote = () => { const m = pickMessage(bundle.messages, ui.roomId, recentRef.current); store.set('recent', JSON.stringify(recentRef.current)); setModal({ k: 'note', msg: m }); setSheet(null); };
  const signOut = async () => { try { await api('/api/logout', { method: 'POST', body: {} }); } catch { /* ignore */ } core?.net.close(); onSignedOut(); };
  const leave = () => { core?.net.close(); onLeave(); };

  const peerName = names[peerSlot]; const viewFrame = viewId != null ? bundle.frames.find((f) => f.id === viewId) : null;
  const hands = ix?.kind === 'hands' && ix.stage === 'play'; const dancing = ix?.kind === 'dance' && ix.stage === 'play';
  const pronoun = peerView?.slot === 'fatima' ? 'her' : 'him';

  return (
    <div className={'museum' + (touch ? ' touch' : '') + (reduced ? ' reduce-motion' : '')}>
      <div className="stage" onPointerDown={() => { if (sheet) setSheet(null); }}><canvas ref={canvasRef} role="img" aria-label="The museum. Walk with the arrow keys, WASD, or the on-screen pad." /></div>

      <div className="hud">
        <div className="top-left">
          {ui.roomName && <div className="pill room" key={ui.roomName}>{ui.roomName}</div>}
          <div className="pill" role="status"><span className={'dot' + (ui.peerOnline ? '' : ' off')} aria-hidden="true" />{ui.peerOnline ? `${peerName} is here` : `${peerName} is away`}<span className="sr">{ui.peerOnline ? 'online' : 'offline'}</span></div>
          {features.minimap && core && <Minimap world={core.game.world} ui={ui} meSlot={me} />}
        </div>
        <div className="top-right">
          <button className="icon-btn" onClick={() => setSheet(sheet === 'music' ? null : 'music')} aria-label="Music" aria-pressed={sheet === 'music'}>♪</button>
          <button className="icon-btn" onClick={() => setSheet(sheet === 'menu' ? null : 'menu')} aria-label="Menu" aria-expanded={sheet === 'menu'}>☰{unread > 0 && <span className="badge">{unread}</span>}</button>
        </div>

        {(status === 'reconnecting' || status === 'connecting') && !veil && <div className="banner" role="status">Reconnecting… your place is saved ♡</div>}
        {hint && <div className="first-run" role="status">{hint}</div>}

        {offer && !modal && <div className="offer" role="status"><span>♪ “{offer.title}” plays in this room</span><button className="btn small primary" onClick={() => { core?.music.play(offer.track); setOffer(null); }}>Play</button><button className="btn small quiet" aria-label="Dismiss" onClick={() => setOffer(null)}>✕</button></div>}
        {outgoing && !ix && <div className="chip-top" role="status"><span>Waiting for {peerName}…</span><button className="btn small" onClick={() => { send({ t: 'end_ix' }); setOutgoing(null); }}>Cancel</button></div>}
        {(hands || dancing) && !proposalOn && <div className="chip-top" role="status"><span>{hands ? `Holding hands with ${peerName} ♡` : `Dancing with ${peerName} ♪`}</span><button className="btn small" onClick={() => send({ t: 'end_ix' })}>{hands ? 'Let go' : 'Stop'}</button></div>}
        {peerView && viewId == null && !modal && !invite && <div className="join-card" role="alert"><span>{peerView.name} is looking at this memory. Join {pronoun}?</span><button className="btn small primary" onClick={() => openFrameById(peerView.frame)}>Join ♡</button><button className="btn small quiet" onClick={() => setPeerView(null)}>Not now</button></div>}

        {sheet === 'menu' && <MenuPanel features={features} unread={unread} peerOnline={ui.peerOnline}
          onNote={showNote} onCompose={() => { setModal('compose'); setSheet(null); }} onInbox={() => { setModal('inbox'); setSheet(null); }} onTimeline={() => { setModal('timeline'); setSheet(null); }}
          onPhoto={() => { setModal('photoPick'); setSheet(null); }} onGuide={() => { setModal('guide'); setSheet(null); }} onSettings={() => { setModal('settings'); setSheet(null); }} onLeave={() => { setModal('leave'); setSheet(null); }} />}
        {sheet === 'music' && core && mv && <MusicPanel music={core.music} view={mv} sharedAllowed={features.sharedMusic} peerName={peerName} peerOnline={ui.peerOnline} />}
        {sheet === 'actions' && <ActionsPanel ui={ui} slot={me} peerName={peerName} features={features} peerOnline={ui.peerOnline} dance={1}
          onAct={(a) => act(a)} onInvite={askTogether} onSit={() => { core?.game.sit(); setSheet(null); }} onStand={() => { core?.game.stand(); setSheet(null); }} onPhoto={() => { setModal('photoPick'); setSheet(null); }} onClose={() => setSheet(null)} />}

        {!blocked && !proposalOn && (
          <div className="dock">
            {ui.seated ? <button className="prompt" onClick={() => core?.game.stand()}>STAND UP</button>
              : ui.near && !ui.locked ? <button className="prompt" onClick={() => core?.game.interact()}>{!touch && ui.near.kind === 'frame' ? <>Press <kbd>E</kbd> to remember ♡</> : ui.near.label}</button> : null}
            <button className="actions-btn" onClick={() => setSheet(sheet === 'actions' ? null : 'actions')} aria-expanded={sheet === 'actions'}>✦ Things to do</button>
          </div>
        )}
        {touch && !blocked && <Joystick onChange={(x, y) => core?.game.setStick(x, y)} />}
        <Toasts items={toasts.items} />
      </div>

      {count != null && <div className="big-count" key={count} aria-hidden="true">{count}</div>}
      {flash > 0 && <div className="flash" key={flash} aria-hidden="true" />}
      {proposalOn && ix && <ProposalOverlay stage={ix.stage} data={ix.data} isAsker={ix.from === me} peerName={peerName} onChoice={(c) => send({ t: 'choice', id: ix.id, choice: c })} onClose={() => send({ t: 'end_ix' })} />}

      {viewFrame && <ViewerPanel frame={viewFrame} together={together} meSlot={me} names={names} looks={looks} audioTitle={bundle.tracks.find((t) => t.id === viewFrame.audio_id)?.title || ''} onPlay={(id) => core?.music.play(id)} onClose={closeViewer} />}
      {invite && <IncomingInvite kind={invite.kind} from={names[invite.from]} onAnswer={(accept) => { send({ t: 'reply', id: invite.id, accept }); setInvite(null); }} />}

      {modal === 'timeline' && <TimelinePanel entries={bundle.timeline} tracks={bundle.tracks} onPlay={(id) => core?.music.play(id)} onClose={() => setModal(null)} />}
      {modal === 'compose' && <ComposePanel toName={peerName} onClose={() => setModal(null)} onSent={() => { setModal(null); toasts.push(`Your note is on its way to ${peerName} ♡`, true); }} />}
      {modal === 'inbox' && <InboxPanel me={me} names={names} onClose={() => setModal(null)} onRead={() => setUnread(0)} />}
      {modal === 'guide' && <GuidePanel touch={touch} onClose={() => setModal(null)} />}
      {modal === 'settings' && <SettingsPanel slot={me} look={looks[me]} reduced={reduced} onReduced={setReducedState} onSaved={() => { setModal(null); toasts.push('Looking lovely ♡', true); }} onSignOut={signOut} onClose={() => setModal(null)} />}
      {modal === 'photoPick' && <PhotoPickPanel peerName={peerName} onClose={() => setModal(null)} onAsk={(frame) => { send({ t: 'invite', kind: 'photo', data: { frame } }); setModal(null); }} />}
      {modal && typeof modal === 'object' && modal.k === 'photoResult' && <PhotoResultPanel shot={modal.shot} initial={modal.frame} caption={`${names.fatmid} & ${names.fatima} · ${new Date().toLocaleDateString([], { dateStyle: 'medium' })}`} onClose={() => setModal(null)} />}
      {modal && typeof modal === 'object' && modal.k === 'note' && <NoteCard text={modal.msg?.text || 'No notes are waiting just now ♡'} from={modal.msg && bundle.settings.show_sender ? modal.msg.sender : ''} onClose={() => setModal(null)} onAnother={() => setModal({ k: 'note', msg: pickMessage(bundle.messages, ui.roomId, recentRef.current) })} />}
      {modal === 'pedestal' && (
        <Modal title="The Promise Room" onClose={() => setModal(null)}>
          <h2>THE PROMISE ROOM</h2>
          <p className="lead" style={{ fontFamily: 'var(--serif)', fontSize: '1.05rem' }}>A quiet place for one little question. {peerName} can answer however feels right, and there is never any pressure.</p>
          <div className="row end"><button className="btn quiet" onClick={() => setModal(null)}>Not yet</button><button className="btn primary" disabled={!ui.peerOnline} onClick={() => askTogether('propose')}>ONE LITTLE QUESTION 💍</button></div>
          {!ui.peerOnline && <p className="lbl" style={{ color: 'var(--muted)' }}>{peerName} isn't here right now.</p>}
        </Modal>
      )}
      {modal === 'leave' && (
        <Modal title="Leave the museum" onClose={() => setModal(null)}>
          <h2>LEAVE THE MUSEUM?</h2>
          <p className="lead">The doors will stay open for you. {peerName} will see that you stepped away.</p>
          <div className="row end"><button className="btn" onClick={() => setModal(null)}>Stay a little longer</button><button className="btn primary" onClick={leave}>Leave</button></div>
        </Modal>
      )}
      {status === 'replaced' && (
        <Modal title="Open in another window" onClose={() => {}} dismissable={false}>
          <h2>OPEN IN ANOTHER WINDOW</h2>
          <p className="lead">You are already in the museum from another tab or device, so this window paused.</p>
          <div className="row end"><button className="btn primary" onClick={() => core?.net.resume()}>Use this window</button></div>
        </Modal>
      )}
      {status === 'signedout' && (
        <Modal title="Signed out" onClose={() => {}} dismissable={false}>
          <h2>THE DOOR WAS CLOSED</h2>
          <p className="lead">This device is no longer signed in. Please open your invitation link or scan the QR code again.</p>
          <div className="row end"><button className="btn primary" onClick={onSignedOut}>OK</button></div>
        </Modal>
      )}

      {veil && <div style={{ position: 'absolute', inset: 0, zIndex: 60, display: 'grid', placeItems: 'center', background: 'radial-gradient(circle at 50% 50%, #fff1cf, #f0dcb4 70%, #e6c896)', color: '#6b4a33', fontFamily: 'var(--serif)', letterSpacing: '0.2em' }} role="status" aria-live="polite"><div style={{ textAlign: 'center' }}><div style={{ fontSize: '2rem', animation: 'float 2.4s ease-in-out infinite' }}>♡</div>OPENING THE DOORS…</div></div>}
    </div>
  );
}
