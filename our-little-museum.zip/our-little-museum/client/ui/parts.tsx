// Small shared UI pieces: modal, character badge, joystick, minimap, toasts.
import { useEffect, useRef, useState, type ReactNode } from 'react';
import type { Look, Slot } from '../../shared/types';
import { drawChar } from '../engine/chars';
import { TILE, type World } from '../../shared/world';
import type { GameUi } from '../engine/game';

// ---------------------------------------------------------------- modal (focus trap, Escape, restores focus)
const stack: symbol[] = [];
export function Modal({ title, onClose, children, wide = false, className = '', dismissable = true, clear = false }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean; className?: string; dismissable?: boolean; clear?: boolean }) {
  const ref = useRef<HTMLDivElement>(null); const close = useRef(onClose); close.current = onClose;
  useEffect(() => {
    const id = Symbol(); stack.push(id); const prev = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => {
      if (stack[stack.length - 1] !== id) return;
      if (e.key === 'Escape' && dismissable) { e.stopPropagation(); e.preventDefault(); close.current(); }
      else if (e.key === 'Tab' && ref.current) {
        const f = (Array.from(ref.current.querySelectorAll<HTMLElement>('button:not(:disabled), [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')) as HTMLElement[]).filter((x) => x.offsetParent !== null);
        if (!f.length) return; const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', onKey, true); ref.current?.focus({ preventScroll: true });
    return () => { window.removeEventListener('keydown', onKey, true); const i = stack.indexOf(id); if (i >= 0) stack.splice(i, 1); try { prev?.focus?.({ preventScroll: true }); } catch { /* gone */ } };
  }, [dismissable]);
  return (
    <div className={'backdrop' + (clear ? ' clear' : '')} onPointerDown={(e) => { if (dismissable && e.target === e.currentTarget && !clear) close.current(); }}>
      <div ref={ref} className={'sheet ' + (wide ? 'wide ' : '') + className} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}>
        {dismissable && <button className="close-x" onClick={() => close.current()} aria-label="Close">✕</button>}
        {children}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- character badge (small live preview)
export function CharBadge({ look, slot, size = 72, anim = 'idle', animate = true }: { look: Look; slot: Slot; size?: number; anim?: any; animate?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current; if (!cv) return; const dpr = Math.min(2, window.devicePixelRatio || 1); const w = size, h = Math.round(size * 1.15);
    cv.width = w * dpr; cv.height = h * dpr; const c = cv.getContext('2d')!; let raf = 0; let stop = false;
    const draw = (ts: number) => {
      c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, cv.width, cv.height); const s = (size / 54) * dpr;
      c.setTransform(s, 0, 0, s, (w / 2) * dpr, (h - 5) * dpr); drawChar(c, { x: 0, y: 0, look, dir: 'down', anim, t: ts / 1000, walk: 0, moving: false, slot });
      if (animate && !stop) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw); return () => { stop = true; cancelAnimationFrame(raf); };
  }, [look, slot, size, anim, animate]);
  return <canvas ref={ref} style={{ width: size, height: Math.round(size * 1.15) }} role="img" aria-label={slot === 'fatima' ? 'Fatima' : 'Fatmid'} />;
}

// ---------------------------------------------------------------- virtual joystick
export function Joystick({ onChange }: { onChange: (x: number, y: number) => void }) {
  const base = useRef<HTMLDivElement>(null); const knob = useRef<HTMLDivElement>(null); const act = useRef<number | null>(null);
  const R = 44;
  const move = (e: React.PointerEvent) => {
    const r = base.current!.getBoundingClientRect(); let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2); const l = Math.hypot(dx, dy);
    if (l > R) { dx = (dx / l) * R; dy = (dy / l) * R; }
    knob.current!.style.transform = `translate(${dx}px, ${dy}px)`; const n = Math.hypot(dx, dy) / R; onChange(n < 0.18 ? 0 : dx / R, n < 0.18 ? 0 : dy / R);
  };
  const end = () => { act.current = null; if (knob.current) knob.current.style.transform = ''; onChange(0, 0); };
  return (
    <div className="joy" ref={base} role="group" aria-label="Movement pad"
      onPointerDown={(e) => { act.current = e.pointerId; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); move(e); }}
      onPointerMove={(e) => { if (act.current === e.pointerId) move(e); }} onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end}>
      <div className="knob" ref={knob} />
    </div>
  );
}

// ---------------------------------------------------------------- minimap
export function Minimap({ world, ui, meSlot }: { world: World; ui: GameUi; meSlot: Slot }) {
  const cw = 18, ch = 12, gap = 4;
  let maxX = 0, maxY = 0; for (const r of world.rooms) { maxX = Math.max(maxX, r.row.gx); maxY = Math.max(maxY, r.row.gy); }
  const W = (maxX + 1) * (cw + gap) - gap, H = (maxY + 1) * (ch + gap) - gap;
  const pos = (id: number | null) => { const r = id != null ? world.roomById.get(id) : null; return r ? { x: r.row.gx * (cw + gap) + cw / 2, y: r.row.gy * (ch + gap) + ch / 2 } : null; };
  const me = pos(ui.roomId), peer = ui.peerOnline ? pos(ui.peerRoomId) : null;
  return (
    <div className="minimap" role="img" aria-label={`Map. You are in ${ui.roomName || 'the museum'}.${ui.peerOnline ? ` ${ui.peerName} is ${ui.peerRoomId === ui.roomId ? 'in the same room' : 'in another room'}.` : ''}`}>
      <svg width={W + 4} height={H + 4} viewBox={`-2 -2 ${W + 4} ${H + 4}`}>
        {world.doors.map((d, i) => { const a = world.roomById.get(d.a)!, b = world.roomById.get(d.b)!; const ax = a.row.gx * (cw + gap) + cw / 2, ay = a.row.gy * (ch + gap) + ch / 2, bx = b.row.gx * (cw + gap) + cw / 2, by = b.row.gy * (ch + gap) + ch / 2; return <line key={i} x1={ax} y1={ay} x2={bx} y2={by} stroke="#c9b08a" strokeWidth="3" />; })}
        {world.rooms.map((r) => <rect key={r.row.id} x={r.row.gx * (cw + gap)} y={r.row.gy * (ch + gap)} width={cw} height={ch} rx="3" fill={r.row.id === ui.roomId ? '#ecc4bd' : '#efe3cc'} stroke="#b8946a" strokeWidth="1" />)}
        {peer && <circle cx={peer.x + (me && peer.x === me.x && peer.y === me.y ? 4 : 0)} cy={peer.y} r="3.4" fill={meSlot === 'fatmid' ? '#d98c9b' : '#6f93b0'} stroke="#fff" strokeWidth="1" />}
        {me && <circle cx={me.x - (peer && peer.x === me.x && peer.y === me.y ? 3 : 0)} cy={me.y} r="3.4" fill={meSlot === 'fatmid' ? '#6f93b0' : '#d98c9b'} stroke="#fff" strokeWidth="1" />}
      </svg>
    </div>
  );
}

// ---------------------------------------------------------------- toasts
export interface ToastItem { id: number; text: string; love?: boolean }
export function useToasts() {
  const [items, setItems] = useState<ToastItem[]>([]);
  const idRef = useRef(1);
  const push = (text: string, love = false, ms = 3800) => {
    const id = idRef.current++; setItems((l) => [...l.slice(-2), { id, text, love }]); setTimeout(() => setItems((l) => l.filter((t) => t.id !== id)), ms);
  };
  return { items, push };
}
export function Toasts({ items }: { items: ToastItem[] }) {
  return <div className="toasts" role="status" aria-live="polite">{items.map((t) => <div key={t.id} className={'toast' + (t.love ? ' love' : '')}>{t.text}</div>)}</div>;
}

void TILE;
