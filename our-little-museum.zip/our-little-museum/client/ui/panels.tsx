// Panels and overlays of the museum UI. Everything user-written is rendered as plain text (React escapes it).
import { useEffect, useMemo, useRef, useState } from 'react';
import { HAIR_COLORS, HAIR_STYLES, MAX_NOTE_LEN, OUTFITS, OUTFIT_COLORS, SKIN_TONES, type Anim, type Features, type FrameRow, type IxKind, type Look, type NoteRow, type Slot, type TimelineRow, type TrackRow } from '../../shared/types';
import { api, mediaUrl } from '../api';
import type { GameUi } from '../engine/game';
import type { Music, MusicView } from '../music';
import { CharBadge, Modal } from './parts';
import { PHOTO_FRAMES, composePhoto, sampleShot } from './photoFrames';

const fmtTime = (t: number) => { try { return new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); } catch { return ''; } };
const mmss = (s: number) => { if (!isFinite(s)) return '0:00'; const m = Math.floor(s / 60), x = Math.floor(s % 60); return `${m}:${String(x).padStart(2, '0')}`; };

// ---------------------------------------------------------------- quick actions
export function ActionsPanel(p: { ui: GameUi; slot: Slot; peerName: string; features: Features; peerOnline: boolean; dance: number; onAct: (a: Anim, variant?: number) => void; onInvite: (k: IxKind) => void; onSit: () => void; onStand: () => void; onPhoto: () => void; onClose: () => void }) {
  const { ui, features: f } = p; const nearBench = ui.near?.kind === 'bench'; const locked = ui.locked;
  const Btn = (props: { g: string; label: string; onClick: () => void; disabled?: boolean; special?: boolean; on?: boolean; title?: string }) => (
    <button className={'act' + (props.special ? ' special' : '') + (props.on ? ' on' : '')} onClick={props.onClick} disabled={props.disabled} title={props.title}><span className="g" aria-hidden="true">{props.g}</span>{props.label}</button>
  );
  const together = !p.peerOnline ? `${p.peerName} is away` : undefined;
  return (
    <div className="act-sheet" role="dialog" aria-label="Things to do">
      <div className="row" style={{ justifyContent: 'space-between', flexWrap: 'nowrap' }}><div className="sec-title" style={{ margin: '0 4px' }}>Just for you</div><button className="icon-btn" style={{ width: 38, height: 38 }} aria-label="Close" onClick={p.onClose}>✕</button></div>
      <div className="act-grid">
        <Btn g="💃" label="Dance · sway" on={ui.anim === 'dance1'} onClick={() => p.onAct('dance1')} disabled={locked} />
        <Btn g="🌸" label="Dance · twirl" on={ui.anim === 'dance2'} onClick={() => p.onAct('dance2')} disabled={locked} />
        <Btn g="🎉" label="Dance · party" on={ui.anim === 'dance3'} onClick={() => p.onAct('dance3')} disabled={locked} />
        <Btn g="👋" label="Wave" onClick={() => p.onAct('wave')} disabled={locked} />
        <Btn g="💗" label="Send a heart" onClick={() => p.onAct('heart')} disabled={locked} />
        <Btn g="😘" label="Blow a kiss" onClick={() => p.onAct('kiss')} disabled={locked} />
        <Btn g="☺️" label="Shy / blush" onClick={() => p.onAct('shy')} disabled={locked} />
        <Btn g="🦋" label="Happy jump" onClick={() => p.onAct('jump')} disabled={locked} />
        <Btn g="🌀" label="Spin" onClick={() => p.onAct('spin')} disabled={locked} />
        <Btn g="🎩" label="Bow" onClick={() => p.onAct('bow')} disabled={locked} />
        {ui.seated ? <Btn g="🧍" label="STAND UP" onClick={p.onStand} /> : <Btn g="🪑" label="SIT HERE ♡" onClick={p.onSit} disabled={!nearBench || locked} title={nearBench ? undefined : 'Walk up to a bench first'} />}
        <Btn g="✨" label="Return to idle" onClick={() => p.onAct('idle')} />
      </div>
      <div className="sec-title">Together with {p.peerName}</div>
      <div className="act-grid">
        {f.hugs && <Btn g="🤗" label="CAN I HAVE A HUG? ♡" onClick={() => p.onInvite('hug')} disabled={!p.peerOnline || locked} title={together} />}
        {f.handHolding && <Btn g="🤝" label="Hold hands" onClick={() => p.onInvite('hands')} disabled={!p.peerOnline || locked} title={together} />}
        {f.danceTogether && <Btn g="🎶" label="Dance together" onClick={() => p.onInvite('dance')} disabled={!p.peerOnline || locked} title={together} />}
        {f.photoMoment && <Btn g="📸" label="LET'S TAKE A MEMORY ♡" onClick={p.onPhoto} disabled={!p.peerOnline || locked} title={together} />}
        {f.proposal && p.slot === 'fatmid' && <Btn g="💍" label="ONE LITTLE QUESTION 💍" special onClick={() => p.onInvite('propose')} disabled={!p.peerOnline || locked} title={together} />}
      </div>
      {!p.peerOnline && <p className="lbl" style={{ margin: '10px 4px 0', color: 'var(--muted)' }}>{p.peerName} isn't here right now, so the together-actions are resting ♡</p>}
    </div>
  );
}

// ---------------------------------------------------------------- menu
export function MenuPanel(p: { features: Features; unread: number; onNote: () => void; onCompose: () => void; onInbox: () => void; onTimeline: () => void; onPhoto: () => void; onGuide: () => void; onSettings: () => void; onLeave: () => void; peerOnline: boolean }) {
  const f = p.features;
  return (
    <div className="menu-anchor" role="menu" aria-label="Menu">
      <div className="menu-list">
        {f.randomMessages && <button className="menu-item" role="menuitem" onClick={p.onNote}>A LITTLE NOTE FOR YOU ♡</button>}
        {f.notes && <button className="menu-item" role="menuitem" onClick={p.onCompose}>LEAVE A NOTE ♡</button>}
        {f.notes && <button className="menu-item" role="menuitem" onClick={p.onInbox}>Notes for me{p.unread > 0 && <span className="badge" style={{ position: 'static' }}>{p.unread}</span>}</button>}
        {f.timeline && <button className="menu-item" role="menuitem" onClick={p.onTimeline}>HOW OUR STORY UNFOLDED</button>}
        {f.photoMoment && <button className="menu-item" role="menuitem" onClick={p.onPhoto} disabled={!p.peerOnline}>LET'S TAKE A MEMORY ♡ {!p.peerOnline && <small>(together only)</small>}</button>}
        <div className="sec-title">Museum</div>
        <button className="menu-item" role="menuitem" onClick={p.onGuide}>Controls guide</button>
        <button className="menu-item" role="menuitem" onClick={p.onSettings}>Settings &amp; my character</button>
        <button className="menu-item" role="menuitem" onClick={p.onLeave}>Leave the museum</button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- photo viewer
export function ViewerPanel(p: { frame: FrameRow; together: boolean; meSlot: Slot; names: Record<Slot, string>; looks: Record<Slot, Look>; audioTitle: string; onPlay: (id: number) => void; onClose: () => void }) {
  const { frame } = p; const [src, setSrc] = useState(frame.photo_id != null ? mediaUrl(frame.photo_id, true) : '');
  const [broken, setBroken] = useState(false);
  useEffect(() => { if (frame.photo_id == null) return; const im = new Image(); im.onload = () => setSrc(mediaUrl(frame.photo_id!)); im.onerror = () => { /* keep the thumbnail */ }; im.src = mediaUrl(frame.photo_id); }, [frame.photo_id]);
  return (
    <Modal title={frame.title || 'A memory'} onClose={p.onClose} wide className="viewer">
      <div className="frame">{src && !broken ? <img src={src} alt={frame.title ? `Photograph: ${frame.title}` : 'A photograph'} onError={() => setBroken(true)} /> : <div style={{ width: 260, height: 180, display: 'grid', placeItems: 'center', fontSize: '2.4rem', color: '#d98c9b' }}>♡</div>}</div>
      <div className="meta">
        {frame.date && <div className="date">{frame.date}</div>}
        {frame.title && <h2 style={{ margin: '0 0 2px' }}>{frame.title}</h2>}
        {frame.caption && <p className="caption">{frame.caption}</p>}
      </div>
      {frame.memory && <div className="story">{frame.memory}</div>}
      {p.together && (
        <div className="together" aria-live="polite">
          <CharBadge look={p.looks.fatmid} slot="fatmid" size={54} /><span style={{ padding: '0 6px 14px' }}>looking together ♡</span><CharBadge look={p.looks.fatima} slot="fatima" size={54} />
        </div>
      )}
      <div className="row center">
        {frame.audio_id != null && <button className="btn soft" onClick={() => p.onPlay(frame.audio_id!)}>♪ Play {p.audioTitle ? `“${p.audioTitle}”` : 'our song'}</button>}
        <button className="btn" onClick={p.onClose}>Back to the museum</button>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------- timeline
export function TimelinePanel(p: { entries: TimelineRow[]; tracks: TrackRow[]; onPlay: (id: number) => void; onClose: () => void }) {
  const [big, setBig] = useState<number | null>(null);
  return (
    <Modal title="How our story unfolded" onClose={p.onClose} wide>
      <h2>HOW OUR STORY UNFOLDED</h2>
      <p className="lead">Chapters in the order they happened.</p>
      {p.entries.length === 0 && <p className="lead" style={{ textAlign: 'center', padding: '24px 0' }}>No chapters have been added yet ♡</p>}
      <div className="tl">
        {p.entries.map((e) => (
          <article className="tl-item" key={e.id}>
            {e.date && <div className="d">{e.date}</div>}
            {e.title && <h3>{e.title}</h3>}
            {e.photo_id != null && <button style={{ all: 'unset', cursor: 'zoom-in', display: 'block' }} onClick={() => setBig(big === e.id ? null : e.id)} aria-label={big === e.id ? 'Show smaller' : 'Show larger'}><img src={mediaUrl(e.photo_id, big !== e.id)} alt={e.title || 'A moment from our story'} loading="lazy" style={big === e.id ? { maxHeight: '70dvh' } : undefined} /></button>}
            {e.caption && <p style={{ fontStyle: 'italic', fontFamily: 'var(--serif)' }}>{e.caption}</p>}
            {e.story && <p style={{ whiteSpace: 'pre-wrap' }}>{e.story}</p>}
            {e.audio_id != null && <button className="btn small soft" onClick={() => p.onPlay(e.audio_id!)}>♪ Play {p.tracks.find((t) => t.id === e.audio_id)?.title || 'song'}</button>}
          </article>
        ))}
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------- notes
export function ComposePanel(p: { toName: string; onClose: () => void; onSent: () => void }) {
  const [text, setText] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const send = async () => {
    if (!text.trim() || busy) return; setBusy(true); setErr('');
    try { await api('/api/notes', { body: { text } }); p.onSent(); } catch (e: any) { setErr(e.message || 'Could not send. Please try again.'); setBusy(false); }
  };
  return (
    <Modal title="Leave a note" onClose={p.onClose}>
      <h2>LEAVE A NOTE ♡</h2>
      <p className="lead">A little message for {p.toName}. They will find it waiting.</p>
      <label htmlFor="note-text">Your note</label>
      <textarea id="note-text" value={text} maxLength={MAX_NOTE_LEN} onChange={(e) => setText(e.target.value)} placeholder="Write something kind…" autoFocus />
      <div className="counter" aria-live="polite">{text.length} / {MAX_NOTE_LEN}</div>
      {err && <p role="alert" style={{ color: '#8a2f3f', margin: '4px 0' }}>{err}</p>}
      <div className="row end" style={{ marginTop: 10 }}><button className="btn quiet" onClick={p.onClose}>Cancel</button><button className="btn primary" onClick={send} disabled={!text.trim() || busy}>Send ♡</button></div>
    </Modal>
  );
}
export function InboxPanel(p: { me: Slot; names: Record<Slot, string>; onClose: () => void; onRead: () => void }) {
  const [notes, setNotes] = useState<NoteRow[] | null>(null); const [err, setErr] = useState('');
  useEffect(() => { api<NoteRow[]>('/api/notes').then((n) => { setNotes(n); return api('/api/notes/read', { method: 'POST', body: {} }); }).then(() => p.onRead()).catch((e) => setErr(e.message)); }, []);
  return (
    <Modal title="Notes" onClose={p.onClose}>
      <h2>NOTES</h2>
      {err && <p role="alert">{err}</p>}
      {notes && notes.length === 0 && <p className="lead">No notes yet. Leave one for {p.names[p.me === 'fatmid' ? 'fatima' : 'fatmid']} ♡</p>}
      <div className="stack">
        {(notes || []).map((n: NoteRow) => (
          <article key={n.id} className="tl-item" style={{ margin: 0 }}>
            <div className="d">{n.from_slot === p.me ? `You → ${p.names[n.to_slot]}` : `From ${p.names[n.from_slot]}`} · {fmtTime(n.created_at)}</div>
            <p style={{ whiteSpace: 'pre-wrap', fontFamily: 'var(--serif)', fontSize: '1.05rem' }}>{n.text}</p>
          </article>
        ))}
      </div>
    </Modal>
  );
}
export function NoteCard(p: { text: string; from: string; onClose: () => void; onAnother: () => void }) {
  return (
    <Modal title="A little note for you" onClose={p.onClose} className="note-card">
      <span className="heart" aria-hidden="true">♡</span>
      <blockquote>{p.text}</blockquote>
      {p.from && <cite>— {p.from}</cite>}
      <div className="row center" style={{ marginTop: 20 }}><button className="btn soft" onClick={p.onAnother}>Another one ♡</button><button className="btn" onClick={p.onClose}>Close</button></div>
    </Modal>
  );
}

// ---------------------------------------------------------------- guide & settings
export function GuidePanel({ onClose, touch }: { onClose: () => void; touch: boolean }) {
  return (
    <Modal title="Controls" onClose={onClose}>
      <h2>HOW TO WANDER</h2>
      <p className="lead">A small museum for two. Take your time.</p>
      <div className="stack" style={{ lineHeight: 1.6 }}>
        <div><span className="kbd">↑</span> <span className="kbd">↓</span> <span className="kbd">←</span> <span className="kbd">→</span> or <span className="kbd">W</span><span className="kbd">A</span><span className="kbd">S</span><span className="kbd">D</span> — walk</div>
        <div><span className="kbd">E</span> — look at a photograph, sit on a bench, play the record</div>
        <div><span className="kbd">Space</span> — sit or stand, or dance for a moment</div>
        <div><span className="kbd">Esc</span> — close a photograph or menu</div>
        <div>✦ <b>Things to do</b> — dance, wave, hug, hold hands, take a memory together</div>
        {touch && <div>On a phone: drag the round pad to walk, tap the big button when something is nearby.</div>}
        <div>♪ — music, alone or listening together</div>
      </div>
      <div className="row end" style={{ marginTop: 14 }}><button className="btn primary" onClick={onClose}>Got it ♡</button></div>
    </Modal>
  );
}

export function SettingsPanel(p: { slot: Slot; look: Look; reduced: boolean; onReduced: (v: boolean) => void; onSaved: () => void; onSignOut: () => void; onClose: () => void }) {
  const [look, setLook] = useState<Look>(p.look); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const set = (k: keyof Look, v: string) => setLook((l) => ({ ...l, [k]: v }));
  const save = async () => { setBusy(true); setErr(''); try { await api('/api/me/look', { method: 'PATCH', body: look }); p.onSaved(); } catch (e: any) { setErr(e.message); setBusy(false); } };
  const Sw = ({ k, list, label }: { k: keyof Look; list: string[]; label: string }) => (
    <div><label>{label}</label><div className="swatches">{list.map((c) => <button key={c} className="sw" style={{ background: c }} aria-label={`${label} ${c}`} aria-pressed={look[k] === c} onClick={() => set(k, c)} />)}</div></div>
  );
  return (
    <Modal title="Settings" onClose={p.onClose}>
      <h2>SETTINGS</h2>
      <div className="row" style={{ alignItems: 'flex-start', gap: 18 }}>
        <div style={{ textAlign: 'center' }}><CharBadge look={look} slot={p.slot} size={108} /></div>
        <div className="stack" style={{ flex: 1, minWidth: 200 }}>
          <div><label htmlFor="hair">Hairstyle</label><select id="hair" value={look.hair} onChange={(e) => set('hair', e.target.value)}>{HAIR_STYLES.map((h) => <option key={h} value={h}>{h}</option>)}</select></div>
          <div><label htmlFor="outfit">Clothing</label><select id="outfit" value={look.outfit} onChange={(e) => set('outfit', e.target.value)}>{OUTFITS.map((h) => <option key={h} value={h}>{h}</option>)}</select></div>
        </div>
      </div>
      <div className="stack" style={{ marginTop: 12 }}>
        <Sw k="hairColor" list={HAIR_COLORS} label="Hair colour" /><Sw k="skin" list={SKIN_TONES} label="Skin tone" /><Sw k="top" list={OUTFIT_COLORS} label="Clothing colour" /><Sw k="bottom" list={OUTFIT_COLORS} label="Second colour" />
      </div>
      {err && <p role="alert" style={{ color: '#8a2f3f' }}>{err}</p>}
      <div className="row end" style={{ margin: '12px 0' }}><button className="btn primary" onClick={save} disabled={busy}>Save my look</button></div>
      <hr style={{ border: 0, borderTop: '1px solid var(--line)' }} />
      <label className="switch"><span>Reduce motion (calmer camera and effects)</span><input type="checkbox" checked={p.reduced} onChange={(e) => p.onReduced(e.target.checked)} /></label>
      <div className="row"><button className="btn quiet small" onClick={p.onSignOut}>Sign out of this device</button></div>
    </Modal>
  );
}

// ---------------------------------------------------------------- music
export function MusicPanel(p: { music: Music; view: MusicView; sharedAllowed: boolean; peerName: string; peerOnline: boolean }) {
  const { music: m, view: v } = p;
  return (
    <div className="music" role="dialog" aria-label="Music player">
      <div className="title" aria-live="polite">{v.title ? `♪ ${v.title}` : v.tracks.length ? 'Choose a song' : 'No songs have been added yet'}</div>
      {v.needsGesture && <div role="status" style={{ background: '#fff4d6', borderRadius: 10, padding: '6px 10px', fontSize: '0.85rem' }}>Your browser is waiting for a tap. Press play ♡</div>}
      <div className="ctl">
        <button className="icon-btn" onClick={() => m.prev()} aria-label="Previous song" disabled={!v.tracks.length}>⏮</button>
        <button className="icon-btn on" onClick={() => m.toggle()} aria-label={v.playing ? 'Pause' : 'Play'} disabled={!v.tracks.length} style={{ width: 54, height: 54 }}>{v.playing ? '❚❚' : '▶'}</button>
        <button className="icon-btn" onClick={() => m.next()} aria-label="Next song" disabled={!v.tracks.length}>⏭</button>
        <button className="icon-btn" aria-pressed={v.loop} onClick={() => m.setLoop(!v.loop)} aria-label="Repeat this song">🔁</button>
      </div>
      <div className="row" style={{ flexWrap: 'nowrap' }}>
        <span className="lbl">{mmss(v.pos)}</span>
        <input type="range" min={0} max={Math.max(1, v.dur)} step={1} value={Math.min(v.pos, Math.max(1, v.dur))} onChange={(e) => m.seek(Number(e.target.value))} aria-label="Song position" disabled={!v.dur} />
        <span className="lbl">{mmss(v.dur)}</span>
      </div>
      <div className="row" style={{ flexWrap: 'nowrap', marginTop: 6 }}>
        <button className="icon-btn" style={{ width: 40, height: 40 }} onClick={() => m.setMuted(!v.muted)} aria-pressed={v.muted} aria-label={v.muted ? 'Unmute' : 'Mute'}>{v.muted || v.volume === 0 ? '🔇' : '🔈'}</button>
        <input type="range" min={0} max={1} step={0.02} value={v.volume} onChange={(e) => { m.setVolume(Number(e.target.value)); if (v.muted) m.setMuted(false); }} aria-label="Volume" />
      </div>
      {v.tracks.length > 0 && <div className="tracklist" role="list">{v.tracks.map((t) => <button key={t.id} className="track" role="listitem" aria-current={t.id === v.track} onClick={() => m.play(t.id)}>{t.id === v.track && v.playing ? '♪' : '·'} {t.title}</button>)}</div>}
      {p.sharedAllowed && (
        <div style={{ marginTop: 10, borderTop: '1px solid var(--line)', paddingTop: 10 }}>
          {v.shareRequest ? (
            <div className="stack"><div>{v.shareRequest} would like to listen together ♡</div><div className="row"><button className="btn small primary" onClick={() => m.answerShare(true)}>Listen together</button><button className="btn small" onClick={() => m.answerShare(false)}>Not now</button></div></div>
          ) : v.shared ? (
            <div className="row" style={{ justifyContent: 'space-between' }}><span>♡ Listening together with {p.peerName}</span><button className="btn small" onClick={() => m.leaveShare()}>Listen on my own</button></div>
          ) : (
            <div className="row" style={{ justifyContent: 'space-between' }}><span className="lbl" style={{ color: 'var(--muted)' }}>Personal mode</span><button className="btn small soft" disabled={!p.peerOnline || v.sharePending} onClick={() => m.requestShare()}>{v.sharePending ? 'Asked… ♡' : `Listen together with ${p.peerName}`}</button></div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- shared photo moment
export function PhotoPickPanel(p: { onClose: () => void; onAsk: (frame: string) => void; peerName: string }) {
  const [frame, setFrame] = useState(PHOTO_FRAMES[0].id); const sample = useMemo(() => sampleShot(), []);
  const thumbs = useMemo(() => PHOTO_FRAMES.map((f) => ({ f, url: composePhoto(sample, f.id, 'us ♡').toDataURL('image/jpeg', 0.7) })), [sample]);
  return (
    <Modal title="Let's take a memory" onClose={p.onClose}>
      <h2>LET'S TAKE A MEMORY ♡</h2>
      <p className="lead">Pick a frame, then ask {p.peerName}. You will both stand close, smile, and the picture stays on your own device.</p>
      <div className="frame-pick" role="group" aria-label="Frames">
        {thumbs.map((t) => <button key={t.f.id} aria-pressed={frame === t.f.id} onClick={() => setFrame(t.f.id)}><img src={t.url} alt="" style={{ width: '100%', borderRadius: 6, display: 'block' }} />{t.f.name}</button>)}
      </div>
      <div className="row end"><button className="btn quiet" onClick={p.onClose}>Cancel</button><button className="btn primary" onClick={() => p.onAsk(frame)}>Ask {p.peerName} ♡</button></div>
    </Modal>
  );
}
export function PhotoResultPanel(p: { shot: HTMLCanvasElement; initial: string; caption: string; onClose: () => void }) {
  const [frame, setFrame] = useState(PHOTO_FRAMES.some((f) => f.id === p.initial) ? p.initial : 'classic'); const [url, setUrl] = useState(''); const blobRef = useRef<Blob | null>(null);
  useEffect(() => {
    let revoked = false; let u = ''; const cv = composePhoto(p.shot, frame, p.caption);
    cv.toBlob((b) => { if (!b || revoked) return; blobRef.current = b; u = URL.createObjectURL(b); setUrl(u); }, 'image/png');
    return () => { revoked = true; if (u) URL.revokeObjectURL(u); };
  }, [frame, p.shot, p.caption]);
  const name = 'our-little-memory.png'; const canShare = typeof navigator !== 'undefined' && !!(navigator as any).canShare;
  const download = () => { if (!url) return; const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); };
  const share = async () => { const b = blobRef.current; if (!b) return; const file = new File([b], name, { type: 'image/png' }); try { if ((navigator as any).canShare({ files: [file] })) await (navigator as any).share({ files: [file], title: 'Our little memory' }); } catch { /* cancelled */ } };
  return (
    <Modal title="Our memory" onClose={p.onClose} className="photo-result">
      <h2>OUR MEMORY ♡</h2>
      <p className="lead">It lives only on your device. Save it if you like.</p>
      {url ? <img src={url} alt="A picture of the two of you in the museum" /> : <p>Developing…</p>}
      <div className="frame-pick" role="group" aria-label="Choose a frame" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
        {PHOTO_FRAMES.map((f) => <button key={f.id} aria-pressed={frame === f.id} onClick={() => setFrame(f.id)} style={{ padding: '8px 2px' }}>{f.name}</button>)}
      </div>
      <div className="row end"><button className="btn quiet" onClick={p.onClose}>Close</button>{canShare && <button className="btn soft" onClick={share} disabled={!url}>Share…</button>}<button className="btn primary" onClick={download} disabled={!url}>Save picture</button></div>
    </Modal>
  );
}

// ---------------------------------------------------------------- invitations between the two players
const INVITE_COPY: Record<IxKind, (n: string) => { title: string; text: string; yes: string }> = {
  hug: (n) => ({ title: 'CAN I HAVE A HUG? ♡', text: `${n} would like a hug.`, yes: 'Of course ♡' }),
  hands: (n) => ({ title: 'Hold hands?', text: `${n} would like to walk with you, hand in hand.`, yes: 'Yes ♡' }),
  dance: (n) => ({ title: 'A little dance?', text: `${n} is asking you to dance.`, yes: "Let's dance ♪" }),
  photo: (n) => ({ title: "LET'S TAKE A MEMORY ♡", text: `${n} would like to take a picture with you.`, yes: 'Smile ♡' }),
  propose: (n) => ({ title: 'One little question', text: `${n} has one little question for you.`, yes: 'Okay ♡' }),
};
export function IncomingInvite(p: { kind: IxKind; from: string; onAnswer: (accept: boolean) => void }) {
  const c = INVITE_COPY[p.kind](p.from);
  return (
    <Modal title={c.title} onClose={() => p.onAnswer(false)}>
      <h2>{c.title}</h2>
      <p className="lead" style={{ fontSize: '1.05rem', fontFamily: 'var(--serif)' }}>{c.text}</p>
      <div className="row end"><button className="btn quiet" onClick={() => p.onAnswer(false)}>Not now</button><button className="btn primary" onClick={() => p.onAnswer(true)} autoFocus>{c.yes}</button></div>
    </Modal>
  );
}

export function ProposalOverlay(p: { stage: string; data: any; isAsker: boolean; peerName: string; onChoice: (c: number) => void; onClose: () => void }) {
  const d = p.data || {}; const st = p.stage;
  const line = st === 'msg1' ? d.line1 : st === 'msg2' ? d.line2 : st === 'ask' ? d.line2 : st === 'yes' ? d.yesReply : st === 'hug' ? d.hugReply : st === 'later' ? d.laterReply : '';
  const small = st === 'yes' || st === 'hug' || st === 'later' || st === 'ask';
  return (
    <div className="cine" role="region" aria-label="One little question" aria-live="polite">
      <button className="btn quiet small close" style={{ color: '#fff6e6' }} onClick={p.onClose} aria-label="End this moment gently">✕</button>
      {line ? <div className={'line' + (small ? ' small' : '')} key={st}>{line}</div> : <div className="line small" style={{ opacity: 0.8 }}>♡</div>}
      {st === 'ask' && !p.isAsker && (
        <div className="answers">
          <button className="btn primary" onClick={() => p.onChoice(0)} autoFocus>{d.yes || 'YES, MY LOVE ♡'}</button>
          <button className="btn soft" onClick={() => p.onChoice(1)}>{d.hug || 'HUG FIRST! 🥹'}</button>
          <button className="btn" onClick={() => p.onChoice(2)}>{d.later || 'NOT YET, LET ME THINK ♡'}</button>
        </div>
      )}
      {st === 'ask' && p.isAsker && <div className="lbl">Waiting for {p.peerName}… there is no hurry ♡</div>}
    </div>
  );
}
