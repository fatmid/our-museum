// Decorative frames for the shared photo moment. Everything is drawn locally; nothing is uploaded anywhere.
export const PHOTO_FRAMES = [
  { id: 'classic', name: 'Classic' }, { id: 'polaroid', name: 'Polaroid' }, { id: 'film', name: 'Film strip' },
  { id: 'hearts', name: 'Hearts' }, { id: 'gold', name: 'Golden' },
];
const SERIF = 'Georgia, "Iowan Old Style", "Palatino Linotype", serif';

function heart(c: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  c.save(); c.translate(x, y); c.scale(s, s); c.fillStyle = col; c.beginPath(); c.moveTo(0, 3); c.bezierCurveTo(-6, -1, -4, -6, 0, -3); c.bezierCurveTo(4, -6, 6, -1, 0, 3); c.fill(); c.restore();
}
function text(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, col: string, style = '', font = SERIF) {
  c.fillStyle = col; c.font = `${style} ${size}px ${font}`.trim(); c.textAlign = 'center'; c.textBaseline = 'middle';
  let t = s; while (c.measureText(t).width > c.canvas.width - 40 && t.length > 8) t = t.slice(0, -2); c.fillText(t === s ? s : t + '…', x, y);
}

export function composePhoto(src: HTMLCanvasElement, frame: string, caption: string): HTMLCanvasElement {
  const w = src.width, h = src.height, u = w / 960; // unit: scales decorations with the picture
  const cv = document.createElement('canvas'); const c = cv.getContext('2d')!;
  const mount = (padL: number, padT: number, padR: number, padB: number) => { cv.width = Math.round(w + padL + padR); cv.height = Math.round(h + padT + padB); };
  if (frame === 'polaroid') {
    mount(44 * u, 44 * u, 44 * u, 150 * u); c.fillStyle = '#fdfbf6'; c.fillRect(0, 0, cv.width, cv.height);
    c.strokeStyle = 'rgba(120,90,60,.18)'; c.lineWidth = 2; c.strokeRect(1, 1, cv.width - 2, cv.height - 2);
    c.drawImage(src, 44 * u, 44 * u); c.strokeStyle = 'rgba(0,0,0,.12)'; c.strokeRect(44 * u, 44 * u, w, h);
    text(c, caption, cv.width / 2, cv.height - 82 * u, 34 * u, '#5b4636', 'italic', '"Segoe Script","Bradley Hand","Brush Script MT",cursive');
    text(c, 'Our Little Museum ♡', cv.width / 2, cv.height - 36 * u, 20 * u, '#a08672');
  } else if (frame === 'film') {
    mount(0, 74 * u, 0, 108 * u); c.fillStyle = '#1e1713'; c.fillRect(0, 0, cv.width, cv.height); c.drawImage(src, 0, 74 * u);
    c.fillStyle = '#f3e4c8'; for (let x = 14 * u; x < cv.width; x += 46 * u) { c.beginPath(); c.roundRect(x, 20 * u, 26 * u, 34 * u, 5 * u); c.fill(); c.beginPath(); c.roundRect(x, cv.height - 54 * u - 40 * u, 26 * u, 34 * u, 5 * u); c.fill(); }
    text(c, caption, cv.width / 2, cv.height - 30 * u, 26 * u, '#f0cf7a', '', '"Courier New",monospace');
  } else if (frame === 'hearts') {
    const p = 70 * u; mount(p, p, p, p + 60 * u); c.fillStyle = '#f6d3cf'; c.fillRect(0, 0, cv.width, cv.height);
    for (let y = 8 * u; y < cv.height; y += 34 * u) for (let x = ((y / (34 * u)) % 2 ? 24 : 8) * u; x < cv.width; x += 48 * u) heart(c, x, y, 2.4 * u, 'rgba(217,140,155,.5)');
    c.fillStyle = '#fffaf2'; c.fillRect(p - 10 * u, p - 10 * u, w + 20 * u, h + 20 * u); c.drawImage(src, p, p);
    text(c, caption, cv.width / 2, cv.height - 44 * u, 30 * u, '#8a4a58', 'italic');
  } else if (frame === 'gold') {
    const p = 64 * u; mount(p, p, p, p + 64 * u); c.fillStyle = '#fbf4e4'; c.fillRect(0, 0, cv.width, cv.height);
    c.drawImage(src, p, p);
    const g = c.createLinearGradient(0, 0, cv.width, cv.height); g.addColorStop(0, '#b98d4b'); g.addColorStop(0.5, '#f1d28c'); g.addColorStop(1, '#a37a3c');
    c.strokeStyle = g; c.lineWidth = 10 * u; c.strokeRect(p - 5 * u, p - 5 * u, w + 10 * u, h + 10 * u); c.lineWidth = 3 * u; c.strokeRect(14 * u, 14 * u, cv.width - 28 * u, cv.height - 28 * u);
    c.fillStyle = g; for (const [x, y] of [[14, 14], [cv.width / u - 14, 14], [14, cv.height / u - 14], [cv.width / u - 14, cv.height / u - 14]]) { c.save(); c.translate(x * u, y * u); c.rotate(Math.PI / 4); c.fillRect(-7 * u, -7 * u, 14 * u, 14 * u); c.restore(); }
    text(c, caption, cv.width / 2, cv.height - 40 * u, 30 * u, '#7a5a2c', 'italic');
  } else { // classic
    const p = 56 * u; mount(p, p, p, p + 62 * u); c.fillStyle = '#f7f0e3'; c.fillRect(0, 0, cv.width, cv.height);
    const g = c.createLinearGradient(0, 0, cv.width, cv.height); g.addColorStop(0, '#a77c4c'); g.addColorStop(0.5, '#e2c288'); g.addColorStop(1, '#8f6a40');
    c.fillStyle = g; c.fillRect(8 * u, 8 * u, cv.width - 16 * u, cv.height - 16 * u - 56 * u * 0);
    c.fillStyle = '#f7f1e4'; c.fillRect(26 * u, 26 * u, cv.width - 52 * u, cv.height - 52 * u); c.drawImage(src, p, p);
    c.strokeStyle = 'rgba(80,50,30,.35)'; c.lineWidth = 2; c.strokeRect(p, p, w, h);
    text(c, caption, cv.width / 2, cv.height - 52 * u, 30 * u, '#5b4636', 'italic'); heart(c, cv.width / 2, cv.height - 22 * u, 3 * u, '#d98c9b');
  }
  return cv;
}

/** A tiny stand-in picture so the frame choices can be previewed before anything is captured. */
export function sampleShot(): HTMLCanvasElement {
  const cv = document.createElement('canvas'); cv.width = 240; cv.height = 160; const c = cv.getContext('2d')!;
  const g = c.createLinearGradient(0, 0, 0, 160); g.addColorStop(0, '#f3e6d0'); g.addColorStop(1, '#e4d3b6'); c.fillStyle = g; c.fillRect(0, 0, 240, 160);
  c.fillStyle = '#d8c3a5'; c.fillRect(0, 110, 240, 50); heart(c, 120, 70, 6, '#d98c9b'); return cv;
}
