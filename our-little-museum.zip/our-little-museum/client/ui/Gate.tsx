// The welcome gate: an illustrated museum entrance, two small silhouettes, and the doors that open.
import { useEffect, useRef } from 'react';

type Style = 'ivory' | 'blush' | 'night';
const SKY: Record<Style, { top: string; mid: string; low: string; sun: string; ground: string; ground2: string; night: boolean }> = {
  ivory: { top: '#f8e6c8', mid: '#f7d9c1', low: '#f4e7d2', sun: '#fff1cf', ground: '#eadcc0', ground2: '#decbab', night: false },
  blush: { top: '#f6d6d0', mid: '#f4c9c4', low: '#f6e2d6', sun: '#ffe6df', ground: '#ecd5c4', ground2: '#e0c1b0', night: false },
  night: { top: '#2f3358', mid: '#6a5878', low: '#c9a08c', sun: '#ffd9a0', ground: '#6d5a5e', ground2: '#54444c', night: true },
};

function Scene({ style }: { style: Style }) {
  const k = SKY[style] || SKY.ivory; const w = k.night ? '#ffe3a8' : '#fff4d4';
  return (
    <svg className="gate-art" viewBox="0 0 900 560" preserveAspectRatio="xMidYMax slice" role="img" aria-label="The entrance of a small museum, with two people standing hand in hand near the gate">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={k.top} /><stop offset="0.55" stopColor={k.mid} /><stop offset="1" stopColor={k.low} /></linearGradient>
        <radialGradient id="sun" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor={k.sun} stopOpacity="0.95" /><stop offset="1" stopColor={k.sun} stopOpacity="0" /></radialGradient>
        <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={k.ground} /><stop offset="1" stopColor={k.ground2} /></linearGradient>
        <linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={k.night ? '#cdb9a4' : '#f4e7cf'} /><stop offset="1" stopColor={k.night ? '#a89484' : '#e8d5b5'} /></linearGradient>
        <linearGradient id="wing" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={k.night ? '#bfa994' : '#ecdcc0'} /><stop offset="1" stopColor={k.night ? '#98857a' : '#dfcba8'} /></linearGradient>
        <linearGradient id="col" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#d9c6a6" /><stop offset="0.5" stopColor="#fbf3e2" /><stop offset="1" stopColor="#cdb893" /></linearGradient>
        <linearGradient id="wood" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#7d5638" /><stop offset="0.5" stopColor="#99694a" /><stop offset="1" stopColor="#6f4b31" /></linearGradient>
        <radialGradient id="inside" cx="0.5" cy="0.62" r="0.7"><stop offset="0" stopColor="#fffbe8" /><stop offset="0.5" stopColor="#ffe3a6" /><stop offset="1" stopColor="#f2b777" /></radialGradient>
        <radialGradient id="lamp" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor="#ffe9a6" stopOpacity="0.95" /><stop offset="1" stopColor="#ffe9a6" stopOpacity="0" /></radialGradient>
        <clipPath id="arch"><path d="M414 392V316Q414 292 450 292Q486 292 486 316V392Z" /></clipPath>
      </defs>
      <rect width="900" height="560" fill="url(#sky)" />
      <circle cx="450" cy="250" r="260" fill="url(#sun)" />
      {k.night && Array.from({ length: 36 }).map((_, i) => <circle key={i} cx={(i * 197) % 900} cy={10 + ((i * 61) % 170)} r={i % 3 ? 1 : 1.6} fill="#fff6dc" style={{ animation: `twinkle ${2 + (i % 5)}s ease-in-out ${(i % 7) * 0.3}s infinite` }} />)}
      {/* distant hills */}
      <path d="M0 360 Q120 300 260 340 T520 330 T780 335 T900 320 V400 H0Z" fill={k.night ? '#4a4660' : '#ead9bd'} opacity="0.9" />
      <path d="M0 380 Q180 340 340 372 T640 366 T900 360 V420 H0Z" fill={k.night ? '#3c3a52' : '#e2cfae'} />
      <g className="world">
        {/* ground */}
        <rect y="392" width="900" height="168" fill="url(#ground)" />
        <path d="M382 414 H518 L660 560 H240Z" fill={k.night ? '#9a8484' : '#f6ecd9'} />
        <path d="M382 414 L240 560 M518 414 L660 560" stroke={k.night ? '#7d6a6e' : '#d9c7a5'} strokeWidth="2" />
        {[430, 456, 490, 530].map((y, i) => <line key={i} x1={382 - (y - 414) * 0.87} y1={y} x2={518 + (y - 414) * 0.87} y2={y} stroke={k.night ? '#826f72' : '#e6d6b8'} strokeWidth="1" opacity="0.7" />)}
        {/* lawns & flowers */}
        <ellipse cx="170" cy="470" rx="170" ry="40" fill={k.night ? '#5d6258' : '#cfd8b6'} /><ellipse cx="740" cy="476" rx="170" ry="40" fill={k.night ? '#5d6258' : '#cfd8b6'} />
        {Array.from({ length: 22 }).map((_, i) => <circle key={i} cx={30 + ((i * 83) % 300) + (i > 10 ? 560 : 0)} cy={462 + ((i * 17) % 26)} r="3" fill={['#e9a3ae', '#f6e0a6', '#f4ece0'][i % 3]} />)}
        {/* trees */}
        {[[86, 1], [816, 1.1]].map(([x, s], i) => <g key={i} transform={`translate(${x} 0) scale(${s})`}><rect x="-5" y="300" width="10" height="100" fill="#8a6a4b" /><circle cx="0" cy="285" r="52" fill={k.night ? '#55654f' : '#a9bf93'} /><circle cx="-30" cy="305" r="34" fill={k.night ? '#4a5a46' : '#98b283'} /><circle cx="32" cy="302" r="36" fill={k.night ? '#4a5a46' : '#9fb88c'} /></g>)}
        {/* building: wings */}
        <rect x="170" y="318" width="132" height="76" fill="url(#wing)" /><rect x="598" y="318" width="132" height="76" fill="url(#wing)" />
        <rect x="164" y="310" width="144" height="10" rx="3" fill={k.night ? '#a8927f' : '#e3cfaa'} /><rect x="592" y="310" width="144" height="10" rx="3" fill={k.night ? '#a8927f' : '#e3cfaa'} />
        {[212, 262, 638, 688].map((x) => <g key={x}><path d={`M${x} 366V338Q${x} 326 ${x + 12} 326Q${x + 24} 326 ${x + 24} 338V366Z`} fill={w} opacity={k.night ? 1 : 0.85} /><path d={`M${x} 366V338Q${x} 326 ${x + 12} 326Q${x + 24} 326 ${x + 24} 338V366Z`} fill="none" stroke="#b79a73" strokeWidth="2.4" /><line x1={x + 12} y1="326" x2={x + 12} y2="366" stroke="#b79a73" strokeWidth="1.4" /><rect x={x - 3} y="366" width="30" height="4" fill="#cbb48e" /></g>)}
        {/* building: main block */}
        <rect x="300" y="250" width="300" height="144" fill="url(#wall)" />
        <polygon points="290,254 450,184 610,254" fill={k.night ? '#b79f8a' : '#ead8ba'} /><polygon points="312,250 450,190 588,250" fill={k.night ? '#c7b19b' : '#f2e4c8'} />
        <circle cx="450" cy="231" r="14" fill={k.night ? '#a8927f' : '#e6d2ae'} /><path d="M450 238c-2-4-8-2-6 2 1 2 4 4 6 5 2-1 5-3 6-5 2-4-4-6-6-2z" fill="#d98c9b" transform="translate(0 -3)" />
        <rect x="290" y="250" width="320" height="12" rx="3" fill={k.night ? '#a8927f' : '#e0c9a0'} />
        {[326, 372, 528, 574].map((x) => <g key={x}><rect x={x} y="262" width="16" height="132" fill="url(#col)" /><rect x={x - 3} y="262" width="22" height="7" rx="2" fill="#e8d6b4" /><rect x={x - 3} y="386" width="22" height="8" rx="2" fill="#e0cca6" /></g>)}
        {/* entrance steps */}
        {[0, 1, 2].map((i) => <rect key={i} x={290 - i * 10} y={394 + i * 7} width={320 + i * 20} height="7" fill={['#f3e8d2', '#ecdfc5', '#e4d5b8'][i]} stroke="#d4c19e" strokeWidth="0.8" />)}
        {/* doorway */}
        <path d="M408 392V316Q408 286 450 286Q492 286 492 316V392Z" fill="#43301f" />
        <g clipPath="url(#arch)">
          <g className="interior"><rect x="414" y="290" width="72" height="104" fill="url(#inside)" />
            <rect x="424" y="318" width="14" height="18" fill="#c58f6b" opacity="0.6" /><rect x="462" y="318" width="14" height="18" fill="#c58f6b" opacity="0.6" /><rect x="438" y="360" width="24" height="30" fill="#fff6d8" opacity="0.5" />
          </g>
          <g className="door-l"><rect x="414" y="290" width="36" height="104" fill="url(#wood)" /><rect x="420" y="302" width="24" height="38" rx="2" fill="none" stroke="#5e3f29" strokeWidth="1.6" /><rect x="420" y="348" width="24" height="38" rx="2" fill="none" stroke="#5e3f29" strokeWidth="1.6" /><circle cx="444" cy="346" r="2.4" fill="#e2c288" /></g>
          <g className="door-r"><rect x="450" y="290" width="36" height="104" fill="url(#wood)" /><rect x="456" y="302" width="24" height="38" rx="2" fill="none" stroke="#5e3f29" strokeWidth="1.6" /><rect x="456" y="348" width="24" height="38" rx="2" fill="none" stroke="#5e3f29" strokeWidth="1.6" /><circle cx="456" cy="346" r="2.4" fill="#e2c288" /></g>
        </g>
        <path d="M408 392V316Q408 286 450 286Q492 286 492 316V392" fill="none" stroke="#c9ac7d" strokeWidth="5" />
        <ellipse className="glow-door" cx="450" cy="398" rx="80" ry="16" fill="url(#lamp)" />
        {/* topiaries */}
        {[366, 534].map((x) => <g key={x}><path d={`M${x - 11} 420h22l-3 -18h-16z`} fill="#c9a07c" /><circle cx={x} cy="392" r="15" fill="#86a275" /><circle cx={x - 5} cy="388" r="7" fill="#96b384" opacity="0.8" /></g>)}
        {/* lamp posts */}
        {[262, 638].map((x) => <g key={x}><circle className="floaty" cx={x} cy="420" r="46" fill="url(#lamp)" opacity={k.night ? 1 : 0.55} /><rect x={x - 2} y="424" width="4" height="62" fill="#5e4a3c" /><rect x={x - 8} y="484" width="16" height="6" rx="2" fill="#5e4a3c" /><rect x={x - 8} y="408" width="16" height="18" rx="3" fill="#ffe7a0" stroke="#5e4a3c" strokeWidth="2" /></g>)}
        <g transform="translate(0 -52)">{/* the two silhouettes, hand in hand */}
        <ellipse cx="437" cy="506" rx="30" ry="5" fill="#2b1d17" opacity="0.18" />
        <g fill="#4f3a30" opacity="0.94">
          {/* Fatmid */}
          <circle cx="421" cy="438" r="8.2" /><path d="M413 436q8-9 16 0z" />
          <path d="M411 448h20l3 36h-26z" /><rect x="414" y="482" width="6" height="22" rx="2.5" /><rect x="422" y="482" width="6" height="22" rx="2.5" />
          <path d="M411 450l-4 24 4 1 5-20z" /><path d="M431 452l8 14 3-1-5-16z" />
          {/* Fatima */}
          <circle cx="452" cy="441" r="7.4" /><path d="M444 440q-3 22 2 28h12q5-6 2-28q-8-10-16 0z" opacity="0.98" />
          <path d="M444 452h16l8 36h-32z" /><rect x="448" y="486" width="5" height="18" rx="2.3" /><rect x="456" y="486" width="5" height="18" rx="2.3" />
          <path d="M444 454l-4 12 3 2 6-10z" />
        </g>
        <path d="M441 466l4-2" stroke="#4f3a30" strokeWidth="3" strokeLinecap="round" />
        <g className="floaty" transform="translate(436 414)"><path d="M0 4c-3-5-10-2-8 3 1 3 5 6 8 8 3-2 7-5 8-8 2-5-5-8-8-3z" fill="#d98c9b" /></g>
        </g>
      </g>
    </svg>
  );
}

export function Gate(p: { title: string; quote: string; subtitle: string; style: Style; welcome: string | null; error: string | null; opening: boolean; shakeKey: number; onOpen: () => void; busy: boolean }) {
  const btn = useRef<HTMLButtonElement>(null);
  useEffect(() => { btn.current?.focus({ preventScroll: true }); }, []);
  return (
    <main className={'gate' + (p.opening ? ' opening' : '')}>
      <Scene style={p.style} />
      <div className="gate-ui">
        <header>
          <h1>{p.title}</h1>
          <p className="quote">“{p.quote}”</p>
          <p className="sub">{p.subtitle}</p>
        </header>
        <div className="cta">
          {p.welcome && <p className="welcome" aria-live="polite">{p.welcome}</p>}
          {p.error && <p className="err" role="alert">{p.error}</p>}
          <button ref={btn} key={p.shakeKey} className={'btn primary open-btn' + (p.shakeKey ? ' shake' : '')} onClick={p.onOpen} disabled={p.busy || p.opening}>OPEN OUR MUSEUM ♡</button>
        </div>
      </div>
      <div className="gate-fade" />
    </main>
  );
}
