import './styles.css';
import { useCallback, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import type { MuseumBundle } from '../shared/types';
import { api, ApiError } from './api';
import { Gate } from './ui/Gate';
import { Museum } from './Museum';

interface GateInfo { title: string; quote: string; subtitle: string; welcome_style: 'ivory' | 'blush' | 'night'; session: { slot: string; name: string; welcome: string } | null }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const INVALID = 'This invitation is not valid any more. Please ask for a new link or QR code.';

function App() {
  const token = useRef<string | null>((() => { try { return new URLSearchParams(location.search).get('invite'); } catch { return null; } })());
  const [gate, setGate] = useState<GateInfo | null>(null);
  const [peek, setPeek] = useState<{ valid: boolean; welcome?: string } | null>(null);
  const [phase, setPhase] = useState<'gate' | 'opening' | 'museum'>('gate');
  const [bundle, setBundle] = useState<MuseumBundle | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);

  // `ready` always holds the latest gate/invitation check, so tapping "Open" never races ahead of it.
  const ready = useRef<Promise<{ g: GateInfo | null; p: { valid: boolean; welcome?: string } | null }> | null>(null);
  const load = useCallback(() => {
    const run = (async () => {
      try {
        const g = await api<GateInfo>('/api/gate'); setGate(g);
        let p: { valid: boolean; welcome?: string } | null = null;
        if (token.current) { p = await api<{ valid: boolean; welcome?: string }>(`/api/invite/peek?token=${encodeURIComponent(token.current)}`); setPeek(p); if (!p.valid && !g.session) setError(INVALID); }
        return { g, p };
      } catch { setError('The museum could not be reached. Please check your connection and try again.'); return { g: null, p: null }; }
    })();
    ready.current = run; return run;
  }, []);
  useEffect(() => { void load(); }, [load]);

  const open = async () => {
    if (busy) return; setBusy(true); setError(null);
    try {
      let info = await (ready.current ?? load());
      if (!info.g) { setError(null); info = await load(); } // the first load failed (offline?): try once more
      if (!info.g) throw new ApiError(0, 'The museum could not be reached. Please check your connection and try again.');
      if (token.current && info.p?.valid) await api('/api/invite/redeem', { body: { token: token.current } });
      else if (!info.g.session) throw new ApiError(403, token.current ? INVALID : 'This museum is private. Please open it from your invitation link or QR code.');
      const b = await api<MuseumBundle>('/api/museum');
      if (token.current) { token.current = null; try { history.replaceState(null, '', location.pathname); } catch { /* ignore */ } }
      setBundle(b); setPhase('opening');
      let reduced = false; try { reduced = matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { /* ignore */ }
      await sleep(reduced ? 400 : 2700); setPhase('museum'); setBusy(false);
    } catch (e: any) { setError(e?.message || 'Something went wrong. Please try again.'); setShake((k) => k + 1); setBusy(false); setPhase('gate'); }
  };

  const backToGate = (signedOut: boolean) => { setBundle(null); setPhase('gate'); setBusy(false); setError(signedOut ? 'You have been signed out of this device. Please open your invitation link again.' : null); void load().then(() => { if (signedOut) setError('You have been signed out of this device. Please open your invitation link again.'); }); };

  if (phase === 'museum' && bundle) return <Museum initial={bundle} onLeave={() => backToGate(false)} onSignedOut={() => backToGate(true)} />;
  const welcome = peek?.valid ? peek.welcome ?? null : gate?.session?.welcome ?? null;
  return <Gate title={gate?.title || 'OUR LITTLE MUSEUM'} quote={gate?.quote || 'Some moments are too beautiful to leave in the past.'} subtitle={gate?.subtitle || 'A little place for our favourite memories.'}
    style={gate?.welcome_style || 'ivory'} welcome={welcome} error={error} opening={phase === 'opening'} shakeKey={shake} onOpen={open} busy={busy} />;
}

createRoot(document.getElementById('root')!).render(<App />);
