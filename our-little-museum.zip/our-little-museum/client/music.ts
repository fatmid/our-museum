// Music player: personal mode, plus "listen together" mode synchronised through the server.
import type { Net } from './net';
import type { MusicState, TrackRow } from '../shared/types';
import { store } from './api';

export interface MusicView {
  track: number | null; title: string; playing: boolean; volume: number; muted: boolean; loop: boolean; shared: boolean;
  pos: number; dur: number; needsGesture: boolean; tracks: TrackRow[]; shareRequest: string | null; sharePending: boolean;
}

export class Music {
  audio = new Audio(); tracks: TrackRow[] = []; private subs = new Set<() => void>(); view: MusicView;
  private raf = 0;
  constructor(private net: Net, defaultVolume: number) {
    const vol = Number(store.get('vol', String(defaultVolume)));
    this.audio.preload = 'none'; this.audio.volume = Math.min(1, Math.max(0, isFinite(vol) ? vol : 0.4));
    this.view = { track: null, title: '', playing: false, volume: this.audio.volume, muted: store.get('muted') === '1', loop: false, shared: false, pos: 0, dur: 0, needsGesture: false, tracks: [], shareRequest: null, sharePending: false };
    this.audio.muted = this.view.muted;
    for (const ev of ['play', 'pause', 'ended', 'loadedmetadata', 'durationchange']) this.audio.addEventListener(ev, () => this.sync());
    this.audio.addEventListener('timeupdate', () => { this.view = { ...this.view, pos: this.audio.currentTime }; this.emit(); });
    this.audio.addEventListener('ended', () => { if (!this.view.shared && !this.audio.loop) this.next(true); });
    this.unsub = net.on((m) => this.onNet(m));
  }
  private unsub: () => void;
  destroy() { this.unsub(); this.audio.pause(); this.audio.src = ''; cancelAnimationFrame(this.raf); }
  subscribe(fn: () => void) { this.subs.add(fn); return () => this.subs.delete(fn); }
  private emit() { this.subs.forEach((f) => f()); }
  private sync() { this.view = { ...this.view, playing: !this.audio.paused && !this.audio.ended, dur: isFinite(this.audio.duration) ? this.audio.duration : 0, pos: this.audio.currentTime }; this.emit(); }
  setTracks(t: TrackRow[]) { this.tracks = t; this.view = { ...this.view, tracks: t }; if (this.view.track != null && !t.find((x) => x.id === this.view.track)) { this.audio.pause(); this.view = { ...this.view, track: null, title: '', playing: false }; } this.emit(); }
  titleOf(id: number | null) { return this.tracks.find((t) => t.id === id)?.title || ''; }

  private load(id: number) {
    if (this.view.track !== id) { this.audio.src = `/api/media/${id}`; this.view = { ...this.view, track: id, title: this.titleOf(id), pos: 0, dur: 0 }; }
  }
  private async start() {
    try { await this.audio.play(); this.view = { ...this.view, needsGesture: false }; }
    catch (e: any) { if (e?.name === 'NotAllowedError') this.view = { ...this.view, needsGesture: true }; }
    this.sync();
  }
  private push(quiet = false) { if (this.view.shared) this.net.send({ t: 'music', op: 'cmd', track: this.view.track, playing: !this.audio.paused, pos: this.audio.currentTime, loop: this.view.loop, quiet }); }

  play(id: number, from = 0) { this.load(id); if (from) this.audio.currentTime = from; void this.start().then(() => this.push()); }
  resume() { if (this.view.track == null && this.tracks[0]) return this.play(this.tracks[0].id); void this.start().then(() => this.push()); }
  pause() { this.audio.pause(); this.push(); }
  toggle() { if (this.audio.paused) this.resume(); else this.pause(); }
  next(auto = false) { this.step(1, auto); }
  prev() { if (this.audio.currentTime > 4) { this.seek(0); return; } this.step(-1); }
  private step(d: number, auto = false) {
    if (!this.tracks.length) return;
    const i = this.tracks.findIndex((t) => t.id === this.view.track); const n = this.tracks[(i + d + this.tracks.length * 2) % this.tracks.length];
    if (auto && this.tracks.length === 1 && !this.audio.loop) return;
    this.play(n.id);
  }
  seek(p: number) { this.audio.currentTime = Math.max(0, p); this.sync(); this.push(true); }
  setVolume(v: number) { this.audio.volume = Math.min(1, Math.max(0, v)); store.set('vol', String(this.audio.volume)); this.view = { ...this.view, volume: this.audio.volume }; this.emit(); }
  setMuted(m: boolean) { this.audio.muted = m; store.set('muted', m ? '1' : '0'); this.view = { ...this.view, muted: m }; this.emit(); }
  setLoop(l: boolean) { this.audio.loop = l; this.view = { ...this.view, loop: l }; this.emit(); this.push(true); }

  // ---- shared listening ----
  requestShare() { this.view = { ...this.view, sharePending: true }; this.emit(); this.net.send({ t: 'music', op: 'share_req' }); setTimeout(() => { if (this.view.sharePending) { this.view = { ...this.view, sharePending: false }; this.emit(); } }, 30000); }
  answerShare(yes: boolean) { this.view = { ...this.view, shareRequest: null }; this.emit(); this.net.send({ t: 'music', op: yes ? 'share_ok' : 'share_no' }); }
  leaveShare() { this.net.send({ t: 'music', op: 'share_leave' }); }

  private apply(s: MusicState) {
    if (s.track == null) { this.audio.pause(); this.sync(); return; }
    this.load(s.track); this.audio.loop = s.loop; this.view = { ...this.view, loop: s.loop };
    const lat = s.playing ? Math.max(0, (this.net.serverNow() - s.at) / 1000) : 0;
    const want = s.pos + lat;
    if (Math.abs(this.audio.currentTime - want) > 0.8 || this.audio.paused) { try { this.audio.currentTime = want; } catch { /* metadata not ready */ this.audio.addEventListener('loadedmetadata', () => { this.audio.currentTime = want; }, { once: true }); } }
    if (s.playing) void this.start(); else { this.audio.pause(); this.sync(); }
  }
  private onNet(m: any) {
    if (m.t === 'welcome') { this.view = { ...this.view, shared: !!m.music?.shared }; this.emit(); if (m.music?.shared) this.apply(m.music); return; }
    if (m.t !== 'music') return;
    if (m.op === 'share_req') { this.view = { ...this.view, shareRequest: m.name || 'Your person' }; this.emit(); }
    else if (m.op === 'share_no') { this.view = { ...this.view, sharePending: false }; this.emit(); }
    else if (m.op === 'shared') {
      const was = this.view.shared; const wasPending = this.view.sharePending;
      this.view = { ...this.view, shared: !!m.on, sharePending: false, shareRequest: null }; this.emit();
      if (m.on && !was && wasPending) this.push(); // the person who asked shares what they are listening to
      if (m.on && !was && !wasPending && this.view.track == null && m.state?.track != null) this.apply(m.state);
    } else if (m.op === 'cmd') this.apply(m.state);
  }
}
