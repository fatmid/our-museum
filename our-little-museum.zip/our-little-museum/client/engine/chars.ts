// Procedurally drawn characters: original, vector-style chibi sprites with real animation poses.
import type { Anim, Dir, Look, Slot } from '../../shared/types';

export interface DrawOpts {
  x: number; y: number; look: Look; dir: Dir; anim: Anim; t: number; walk: number; moving: boolean;
  slot: Slot; partnerDx?: number; ring?: boolean; reduced?: boolean; alpha?: number;
}

export function shade(hex: string, amt: number): string {
  const n = parseInt(hex.slice(1), 16);
  const f = (c: number) => Math.max(0, Math.min(255, Math.round(amt >= 0 ? c + (255 - c) * amt : c * (1 + amt))));
  return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
}
function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath(); ctx.roundRect(x, y, w, h, Math.min(r, w / 2, h / 2));
}
function limb(ctx: CanvasRenderingContext2D, px: number, py: number, ang: number, len: number, w: number, color: string) {
  ctx.save(); ctx.translate(px, py); ctx.rotate(ang); ctx.fillStyle = color; rr(ctx, -w / 2, 0, w, len, w / 2); ctx.fill(); ctx.restore();
}
function ellipse(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, fill: string) {
  ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); ctx.fillStyle = fill; ctx.fill();
}

interface Pose {
  bob: number; dx: number; legL: number; legR: number; armL: number; armR: number; tilt: number; lean: number; squash: number;
  blush: number; mouth: 'smile' | 'open' | 'small' | 'o'; eyes: 'open' | 'happy' | 'closed' | 'down'; lift: number; spinX: number; kneel: boolean; sit: boolean; hug: boolean;
}
const basePose = (): Pose => ({ bob: 0, dx: 0, legL: 0, legR: 0, armL: 0.08, armR: -0.08, tilt: 0, lean: 0, squash: 1, blush: 0.25, mouth: 'smile', eyes: 'open', lift: 0, spinX: 1, kneel: false, sit: false, hug: false });

function poseFor(o: DrawOpts): Pose {
  const p = basePose(); const t = o.t; const s = Math.sin;
  const R = o.reduced ? 0.4 : 1;
  if (o.moving && o.anim === 'idle') {
    const w = o.walk; p.legL = s(w) * 0.62; p.legR = -s(w) * 0.62; p.armL = -s(w) * 0.5; p.armR = s(w) * 0.5; p.bob = -Math.abs(s(w)) * 1.4;
    return p;
  }
  switch (o.anim) {
    case 'idle': {
      p.bob = s(t * 2.2) * 0.35 * R;
      if (o.slot === 'fatima') { p.tilt = s(t * 0.9) * 0.05 * R; p.armL = 0.12 + s(t * 1.1) * 0.04; }
      if ((t * 0.37) % 4.8 > 4.62) p.eyes = 'closed';
      break;
    }
    case 'sit': p.sit = true; p.bob = s(t * 1.6) * 0.25 * R; p.armL = -0.5; p.armR = 0.5; if ((t * 0.33) % 5 > 4.8) p.eyes = 'closed'; break;
    case 'wave': { const k = s(t * 11); p.armR = -(2.5 + k * 0.45); p.armL = 0.1; p.mouth = 'open'; p.eyes = 'happy'; p.bob = s(t * 6) * 0.4; p.tilt = 0.06; break; }
    case 'heart': { p.armL = 2.7; p.armR = -2.7; p.eyes = 'happy'; p.mouth = 'open'; p.bob = s(t * 5) * 0.8 * R; p.blush = 0.55; break; }
    case 'kiss': { const k = Math.min(1, t / 0.5); p.armR = -(1.2 + 0.9 * (1 - k)) ; p.eyes = 'closed'; p.mouth = 'o'; p.blush = 0.6; p.tilt = 0.1; p.bob = s(t * 4) * 0.4; break; }
    case 'shy': { p.armL = 1.2; p.armR = -1.2; p.eyes = 'down'; p.blush = 0.95; p.tilt = 0.18 + s(t * 3) * 0.04 * R; p.dx = s(t * 2.4) * 0.8 * R; p.mouth = 'small'; break; }
    case 'jump': { const k = Math.min(1, t / 1.0); p.lift = Math.abs(s(k * Math.PI)) * 13; p.armL = 2.3; p.armR = -2.3; p.mouth = 'open'; p.eyes = 'happy'; p.legL = 0.35; p.legR = -0.35; break; }
    case 'spin': { const k = Math.min(1, t / 1.1); p.spinX = Math.cos(k * Math.PI * 2); p.lift = Math.abs(s(k * Math.PI)) * 4; p.armL = 1.5; p.armR = -1.5; p.mouth = 'open'; p.eyes = 'happy'; break; }
    case 'bow': { const k = Math.min(1, t / 1.4); p.lean = s(k * Math.PI) * 0.72; p.armL = 0.2; p.armR = -0.2; p.eyes = 'closed'; break; }
    case 'dance1': { const b = t * 5; p.dx = s(b) * 3.2 * R; p.legL = s(b) * 0.5; p.legR = s(b + Math.PI) * 0.5; p.armL = 0.5 + s(b) * 0.9; p.armR = -(0.5 + s(b + Math.PI) * 0.9); p.bob = -Math.abs(s(b)) * 2.2 * R; p.tilt = s(b) * 0.1; p.mouth = 'open'; p.eyes = 'happy'; break; }
    case 'dance2': { const k = (t % 1.6) / 1.6; p.spinX = k < 0.5 ? Math.cos((k / 0.5) * Math.PI * 2) : 1; p.lift = Math.abs(s(t * 6)) * 5 * R; p.armL = 1.9; p.armR = -1.9; p.mouth = 'open'; p.eyes = 'happy'; p.tilt = s(t * 6) * 0.08; break; }
    case 'dance3': { const b = t * 7; p.lift = Math.abs(s(b)) * 8 * R; p.armL = 2.2 + s(b) * 0.5; p.armR = -(2.2 + s(b + Math.PI) * 0.5); p.legL = s(b) * 0.4; p.legR = -s(b) * 0.4; p.mouth = 'open'; p.eyes = 'happy'; p.tilt = s(b * 0.5) * 0.12; break; }
    case 'cheer': { const b = t * 8; p.lift = Math.abs(s(b)) * 9 * R; p.armL = 2.6 + s(b) * 0.3; p.armR = -(2.6 + s(b) * 0.3); p.mouth = 'open'; p.eyes = 'happy'; p.blush = 0.6; break; }
    case 'kneel': p.kneel = true; p.armR = -1.55; p.armL = 0.15; p.mouth = 'smile'; p.bob = s(t * 2) * 0.3 * R; break;
    case 'hug': p.hug = true; p.armR = -1.45; p.armL = -1.2; p.eyes = 'closed'; p.mouth = 'smile'; p.blush = 0.7; p.bob = s(t * 3) * 0.5 * R; p.lean = 0.12; break;
    case 'photo': p.mouth = 'open'; p.eyes = 'happy'; p.armL = 0.2; p.armR = -0.2; break;
  }
  return p;
}

type View = 'front' | 'back' | 'side';

function drawHair(ctx: CanvasRenderingContext2D, style: string, c: string, view: View, behind: boolean) {
  const dark = shade(c, -0.18), cx = 0, cy = -23, r = 8.3;
  ctx.fillStyle = c;
  if (behind) { // parts drawn before the body
    if (style === 'long') {
      if (view === 'front') { rr(ctx, -8.6, -24, 17.2, 17, 5); ctx.fill(); }
      else if (view === 'back') { rr(ctx, -8.4, -26, 16.8, 20, 6); ctx.fill(); }
      else { rr(ctx, -9.4, -26, 8, 19, 4); ctx.fill(); }
    } else if (style === 'ponytail' && view !== 'front') {
      ctx.save(); ctx.translate(view === 'side' ? -9 : 0, view === 'side' ? -25 : -19); ctx.rotate(view === 'side' ? 0.5 : 0);
      rr(ctx, -2.4, 0, 4.8, 12, 2.4); ctx.fill(); ctx.restore();
    } else if (style === 'bob') {
      if (view === 'front') { rr(ctx, -9, -26, 18, 13, 5); ctx.fill(); } else { rr(ctx, -9.3, -26, view === 'side' ? 9 : 18.6, 13, 5); ctx.fill(); }
    } else if (style === 'scarf') {
      ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-9.5, -24); ctx.quadraticCurveTo(-11, -12, -6, -10); ctx.lineTo(6, -10); ctx.quadraticCurveTo(11, -12, 9.5, -24); ctx.closePath(); ctx.fill();
    }
    return;
  }
  const cap = (extra = 0) => { ctx.beginPath(); ctx.arc(cx, cy - 0.5, r + extra, Math.PI, 0); ctx.lineTo(r + extra, cy - 1.5); ctx.lineTo(-r - extra, cy - 1.5); ctx.closePath(); ctx.fill(); };
  if (view === 'back') { // back of head is all hair
    ctx.beginPath(); ctx.arc(cx, cy, r + 0.3, 0, Math.PI * 2); ctx.fill();
    if (style === 'bun') { ellipse(ctx, 0, -31.5, 3.8, 3.4, c); }
    if (style === 'messy') { ctx.fillStyle = dark; for (const x of [-4, 0, 4]) { ctx.beginPath(); ctx.moveTo(x - 2, -29); ctx.lineTo(x, -33); ctx.lineTo(x + 2, -29); ctx.fill(); } }
    if (style === 'scarf') { ctx.fillStyle = shade(c, -0.1); ctx.beginPath(); ctx.arc(0, cy, r + 1.8, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.moveTo(-9.8, -22); ctx.quadraticCurveTo(-11, -12, -6, -10); ctx.lineTo(6, -10); ctx.quadraticCurveTo(11, -12, 9.8, -22); ctx.fill(); }
    return;
  }
  const sd = view === 'side';
  switch (style) {
    case 'short': cap(); ctx.fillStyle = c; rr(ctx, -r, -29, r * 2, 4.5, 2); ctx.fill(); if (sd) { ctx.fillStyle = c; rr(ctx, -r, -26, 4, 9, 2); ctx.fill(); } break;
    case 'messy':
      cap(0.3); ctx.fillStyle = c;
      for (const [x, h] of [[-5.5, 4], [-2, 5.5], [1.5, 4.5], [5, 4]] as [number, number][]) { ctx.beginPath(); ctx.moveTo(x - 2.6, -29.5); ctx.lineTo(x + 0.3, -29.5 - h); ctx.lineTo(x + 2.6, -29.5); ctx.fill(); }
      ctx.fillStyle = dark; ctx.beginPath(); ctx.moveTo(-6.5, -25.5); ctx.lineTo(-2, -22.5); ctx.lineTo(1, -26.5); ctx.lineTo(4, -23); ctx.lineTo(6.5, -26); ctx.lineTo(6.5, -28); ctx.lineTo(-6.5, -28); ctx.fill();
      if (sd) { ctx.fillStyle = c; rr(ctx, -r, -26, 4, 9, 2); ctx.fill(); }
      break;
    case 'side': cap(0.2); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-8, -26); ctx.quadraticCurveTo(2, -22, 8.4, -23.5); ctx.lineTo(8.4, -29); ctx.lineTo(-8, -29); ctx.fill(); ctx.fillStyle = dark; ctx.beginPath(); ctx.moveTo(-8, -26); ctx.quadraticCurveTo(-1, -24.5, 2, -25.5); ctx.lineTo(-8, -27.5); ctx.fill(); if (sd) { ctx.fillStyle = c; rr(ctx, -r, -26, 4, 9, 2); ctx.fill(); } break;
    case 'long': cap(0.3); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-8, -24.5); ctx.quadraticCurveTo(-3, -28, 0, -24); ctx.quadraticCurveTo(3, -28, 8, -24.5); ctx.lineTo(8, -29); ctx.lineTo(-8, -29); ctx.fill(); if (!sd) { rr(ctx, -8.8, -26, 3, 11, 1.5); ctx.fill(); rr(ctx, 5.8, -26, 3, 11, 1.5); ctx.fill(); } break;
    case 'bun': cap(0.2); ellipse(ctx, 0, -31.8, 4, 3.6, c); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-8, -25.5); ctx.quadraticCurveTo(0, -22, 8, -25.5); ctx.lineTo(8, -29); ctx.lineTo(-8, -29); ctx.fill(); break;
    case 'ponytail': cap(0.2); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-8, -25); ctx.quadraticCurveTo(0, -21.5, 8, -25); ctx.lineTo(8, -29); ctx.lineTo(-8, -29); ctx.fill(); if (view === 'front') { rr(ctx, 7.6, -27, 3.2, 9, 1.6); ctx.fill(); } break;
    case 'bob': cap(0.3); ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(-8.2, -24.5); ctx.quadraticCurveTo(0, -21, 8.2, -24.5); ctx.lineTo(8.2, -29); ctx.lineTo(-8.2, -29); ctx.fill(); if (!sd) { rr(ctx, -9, -26, 3.4, 10, 1.7); ctx.fill(); rr(ctx, 5.6, -26, 3.4, 10, 1.7); ctx.fill(); } break;
    case 'scarf': {
      ctx.fillStyle = c; ctx.beginPath(); ctx.arc(0, cy - 0.5, r + 1.6, Math.PI, 0); ctx.lineTo(r + 1.6, -16); ctx.lineTo(-r - 1.6, -16); ctx.closePath(); ctx.fill();
      if (!sd) { rr(ctx, -9.9, -24, 3.6, 12, 1.8); ctx.fill(); rr(ctx, 6.3, -24, 3.6, 12, 1.8); ctx.fill(); }
      ctx.fillStyle = shade(c, 0.12); ctx.beginPath(); ctx.moveTo(-8, -27); ctx.quadraticCurveTo(0, -24, 8, -27); ctx.lineTo(8, -29); ctx.lineTo(-8, -29); ctx.fill();
      break;
    }
  }
}

function drawFace(ctx: CanvasRenderingContext2D, p: Pose, view: View, skin: string) {
  if (view === 'back') return;
  const ox = view === 'side' ? 3.4 : 0; const ink = '#3a2a22';
  const eyeXs = view === 'side' ? [2.6, 6.6] : [-3, 3]; const ey = -22.4;
  ctx.fillStyle = ink; ctx.strokeStyle = ink; ctx.lineWidth = 1.1; ctx.lineCap = 'round';
  for (const ex of view === 'side' ? [eyeXs[1]] : eyeXs) {
    if (p.eyes === 'open') { ellipse(ctx, ex, ey, 1.15, 1.5, ink); ellipse(ctx, ex + 0.35, ey - 0.5, 0.4, 0.4, '#fff'); }
    else if (p.eyes === 'happy') { ctx.beginPath(); ctx.arc(ex, ey + 0.6, 1.5, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); }
    else if (p.eyes === 'closed') { ctx.beginPath(); ctx.moveTo(ex - 1.3, ey + 0.3); ctx.lineTo(ex + 1.3, ey + 0.3); ctx.stroke(); }
    else { ctx.beginPath(); ctx.arc(ex, ey - 0.4, 1.5, Math.PI * 0.1, Math.PI * 0.9); ctx.stroke(); }
  }
  const bl = Math.min(1, p.blush);
  ctx.globalAlpha = 0.18 + bl * 0.5; ellipse(ctx, view === 'side' ? 5.2 : -5.2, -19.8, 1.9, 1.2, '#f08a95'); if (view !== 'side') ellipse(ctx, 5.2, -19.8, 1.9, 1.2, '#f08a95'); ctx.globalAlpha = 1;
  const mx = view === 'side' ? 5.6 : 0; ctx.fillStyle = ink; ctx.strokeStyle = ink;
  if (p.mouth === 'smile') { ctx.beginPath(); ctx.arc(mx, -19.9, 1.5, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); }
  else if (p.mouth === 'open') { ctx.beginPath(); ctx.arc(mx, -19.6, 1.6, 0, Math.PI); ctx.fill(); }
  else if (p.mouth === 'o') ellipse(ctx, mx, -19.4, 1, 1.2, '#c4585f');
  else { ctx.beginPath(); ctx.moveTo(mx - 1, -19.2); ctx.lineTo(mx + 1, -19.2); ctx.stroke(); }
  void ox; void skin;
}

function drawOutfit(ctx: CanvasRenderingContext2D, look: Look, view: View, torsoTop: number, torsoH: number, w: number) {
  const { outfit, top, bottom, accent } = look; const x = -w / 2;
  const trim = shade(top, -0.2);
  const body = () => { rr(ctx, x, torsoTop, w, torsoH, 3); ctx.fill(); };
  ctx.fillStyle = top;
  switch (outfit) {
    case 'dress': {
      ctx.beginPath(); ctx.moveTo(x, torsoTop + 1); ctx.lineTo(x + w, torsoTop + 1); ctx.lineTo(x + w + 3.2, -3.2); ctx.quadraticCurveTo(0, -1.2, x - 3.2, -3.2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = trim; ctx.fillRect(x - 2.6, -5, w + 5.2, 1.3); ctx.fillStyle = accent; if (view === 'front') ctx.fillRect(-w / 2 + 1, torsoTop + 5.2, w - 2, 1.4); break;
    }
    case 'kurta': {
      ctx.beginPath(); ctx.moveTo(x, torsoTop + 1); ctx.lineTo(x + w, torsoTop + 1); ctx.lineTo(x + w + 1.8, -5); ctx.lineTo(x - 1.8, -5); ctx.closePath(); ctx.fill();
      ctx.fillStyle = accent; if (view === 'front') { ctx.fillRect(-0.7, torsoTop + 1, 1.4, 11); for (let i = 0; i < 3; i++) ellipse(ctx, 0, torsoTop + 3 + i * 3.2, 0.7, 0.7, trim); } ctx.fillStyle = trim; ctx.fillRect(x - 1.8, -6.3, w + 3.6, 1.3); break;
    }
    case 'hoodie': body(); ctx.fillStyle = trim; if (view !== 'front') { rr(ctx, -5, torsoTop - 0.5, 10, 4, 2); ctx.fill(); } else { ctx.beginPath(); ctx.arc(0, torsoTop + 0.5, 4.6, 0, Math.PI); ctx.fill(); ctx.fillStyle = accent; ctx.fillRect(-2, torsoTop + 3, 0.9, 4); ctx.fillRect(1.1, torsoTop + 3, 0.9, 4); } ctx.fillStyle = trim; rr(ctx, x, torsoTop + torsoH - 2.4, w, 2.4, 1.2); ctx.fill(); break;
    case 'shirt': body(); ctx.fillStyle = accent; if (view === 'front') { ctx.beginPath(); ctx.moveTo(-3.2, torsoTop); ctx.lineTo(0, torsoTop + 3.5); ctx.lineTo(3.2, torsoTop); ctx.fill(); ctx.fillStyle = trim; ctx.fillRect(-0.4, torsoTop + 3, 0.8, torsoH - 3); } break;
    case 'sweater': body(); ctx.fillStyle = trim; rr(ctx, x, torsoTop + torsoH - 2.6, w, 2.6, 1.3); ctx.fill(); ctx.fillStyle = accent; ctx.globalAlpha = 0.9; ctx.fillRect(x, torsoTop + 3.2, w, 1.2); ctx.globalAlpha = 1; if (view === 'front') { ctx.fillStyle = shade(top, 0.25); rr(ctx, -3, torsoTop - 0.4, 6, 2.2, 1); ctx.fill(); } break;
    case 'overalls': { ctx.fillStyle = accent; body(); ctx.fillStyle = bottom; rr(ctx, x, torsoTop + 4.5, w, torsoH - 4.5, 2); ctx.fill(); if (view === 'front') { ctx.fillRect(x + 1, torsoTop, 2, 5); ctx.fillRect(x + w - 3, torsoTop, 2, 5); ellipse(ctx, x + 2, torsoTop + 5, 0.9, 0.9, accent); ellipse(ctx, x + w - 2, torsoTop + 5, 0.9, 0.9, accent); } break; }
    case 'cardigan': { ctx.fillStyle = accent; body(); ctx.fillStyle = top; rr(ctx, x, torsoTop, 3.4, torsoH, 1.5); ctx.fill(); rr(ctx, x + w - 3.4, torsoTop, 3.4, torsoH, 1.5); ctx.fill(); if (view !== 'front') { rr(ctx, x, torsoTop, w, torsoH, 3); ctx.fill(); } ctx.fillStyle = trim; rr(ctx, x, torsoTop + torsoH - 2, w, 2, 1); ctx.fill(); break; }
    default: body(); ctx.fillStyle = trim; ctx.fillRect(x, torsoTop + torsoH - 1.6, w, 1.6); // tee
  }
}
const longGarment = (o: string) => o === 'dress' || o === 'kurta';

export function drawChar(ctx: CanvasRenderingContext2D, o: DrawOpts) {
  const p = poseFor(o); const look = o.look;
  const view: View = o.dir === 'up' ? 'back' : o.dir === 'down' ? 'front' : 'side';
  const flip = o.dir === 'left' ? -1 : 1;
  ctx.save();
  if (o.alpha != null) ctx.globalAlpha = o.alpha;
  ctx.translate(o.x, o.y);
  // shadow
  ctx.globalAlpha = (o.alpha ?? 1) * (0.2 - Math.min(0.1, p.lift * 0.008)); ellipse(ctx, p.dx, 0.5, 8 - p.lift * 0.15, 2.6, '#2b1d17'); ctx.globalAlpha = o.alpha ?? 1;
  ctx.translate(p.dx, -p.lift + p.bob);
  let sx = flip; let v: View = view;
  if (o.anim === 'spin' || o.anim === 'dance2') { if (p.spinX < 0) v = view === 'front' ? 'back' : view === 'back' ? 'front' : view; sx *= Math.max(0.18, Math.abs(p.spinX)); }
  ctx.scale(sx, 1);
  const skin = look.skin, skinD = shade(skin, -0.12);
  const kneel = p.kneel, sit = p.sit;
  const bodyDrop = sit ? 6 : kneel ? 7 : 0;
  const sideView = v === 'side';

  // --- behind-body hair
  ctx.save(); ctx.translate(0, bodyDrop); ctx.rotate(p.tilt * 0.6); drawHair(ctx, look.hair, look.hairColor, v, true); ctx.restore();

  // --- legs
  const legC = look.bottom === look.top && longGarment(look.outfit) ? shade(look.bottom, -0.15) : look.bottom;
  const shoe = '#4a3a30';
  const leg = (px: number, ang: number, back = false) => {
    ctx.save(); ctx.translate(px, -9 + bodyDrop);
    if (sit && o.dir !== 'up') { ctx.fillStyle = legC; if (sideView) { ctx.rotate(-Math.PI / 2); rr(ctx, -2, 0, 4, 9, 2); ctx.fill(); ctx.rotate(Math.PI / 2); ctx.translate(8, 0); rr(ctx, -2, 0, 4, 5, 2); ctx.fill(); } else { rr(ctx, -2, 0, 4, 6.5, 2); ctx.fill(); } ctx.fillStyle = shoe; rr(ctx, sideView ? 0 : -2.2, 5.5, 4.6, 2.2, 1); ctx.fill(); }
    else if (kneel) {
      if (back) { ctx.translate(-1, 8.5); ctx.rotate(Math.PI / 2 + 0.05); ctx.fillStyle = legC; rr(ctx, -2, 0, 4, 9, 2); ctx.fill(); ctx.fillStyle = shoe; rr(ctx, -2, 8, 4, 2.2, 1); ctx.fill(); }
      else { ctx.translate(3, 0); ctx.rotate(-Math.PI / 2 + 0.1); ctx.fillStyle = legC; rr(ctx, -2, 0, 4, 8, 2); ctx.fill(); ctx.rotate(Math.PI / 2 - 0.1); ctx.translate(8, 0); ctx.fillStyle = legC; rr(ctx, -2, 0, 4, 8, 2); ctx.fill(); ctx.fillStyle = shoe; rr(ctx, -2, 6.5, 5, 2.2, 1); ctx.fill(); }
    } else { ctx.rotate(ang * 0.7); ctx.fillStyle = legC; rr(ctx, -2, -0.5, 4, 9.5 + (longGarment(look.outfit) ? 0 : 0), 2); ctx.fill(); ctx.fillStyle = shoe; rr(ctx, sideView ? -1.6 : -2.2, 7.2, sideView ? 5 : 4.4, 2.3, 1.1); ctx.fill(); }
    ctx.restore();
  };
  if (sideView) { leg(-0.5, p.legR, true); leg(0.8, p.legL); } else { leg(-2.6, p.legL, true); leg(2.6, p.legR); }

  // --- upper body (rotates for a bow)
  ctx.save(); ctx.translate(0, -9 + bodyDrop); ctx.rotate(p.lean); ctx.translate(0, 9 - bodyDrop);
  ctx.translate(0, bodyDrop);
  const torsoW = sideView ? 8.2 : 11.2;
  // far arm (side view)
  const armColor = look.outfit === 'tee' || look.outfit === 'overalls' ? skin : look.top;
  const sleeve = (px: number, py: number, ang: number, far = false) => {
    ctx.save(); ctx.translate(px, py); ctx.rotate(ang);
    const col = far ? shade(armColor, -0.12) : armColor; ctx.fillStyle = col; rr(ctx, -1.7, -1, 3.4, 8, 1.7); ctx.fill();
    if (armColor !== skin) { ctx.fillStyle = far ? skinD : skin; rr(ctx, -1.5, 5.6, 3, 4, 1.5); ctx.fill(); } else { ctx.fillStyle = skin; rr(ctx, -1.6, 5, 3.2, 5, 1.6); ctx.fill(); }
    ctx.restore();
  };
  const sh = -16.2;
  const armAng = (a: number) => a; // 0 = down; positive swings toward -x
  if (sideView) sleeve(-0.6, sh, p.hug ? -1.3 : armAng(p.armL), true);
  drawOutfit(ctx, look, v, -17.5, 9, torsoW);
  if (v === 'front' || v === 'back') {
    // belt line / neck
    ctx.fillStyle = skin; if (v === 'front') ellipse(ctx, 0, -17.6, 2.2, 1.2, skin);
  }
  if (sideView) {
    sleeve(0.8, sh, p.hug ? -1.45 : p.armR);
    // ring box when kneeling
    if (kneel) { const bx = 12, by = -17; ctx.fillStyle = '#6b3b3f'; rr(ctx, bx - 3, by - 1, 6, 4.2, 1); ctx.fill(); ctx.fillStyle = '#3d1f22'; ctx.fillRect(bx - 3, by + 0.6, 6, 0.8); if (o.ring) { ctx.strokeStyle = '#f0cf7a'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(bx, by - 2.2, 1.6, 0, Math.PI * 2); ctx.stroke(); ellipse(ctx, bx, by - 4.2, 1.1, 1.1, '#cfeaff'); } }
  } else {
    sleeve(-6.7, sh, armAng(p.armL)); sleeve(6.7, sh, armAng(p.armR));
  }
  // head
  ctx.save(); ctx.translate(0, -23); ctx.rotate(p.tilt); ctx.translate(0, 23);
  if (kneel) ctx.translate(0, 0);
  ellipse(ctx, 0, -23, sideView ? 7.6 : 8, 7.6, skin);
  if (sideView) { ellipse(ctx, 6.9, -22, 1.2, 1.1, skin); ellipse(ctx, -1.6, -22, 1.6, 2, skinD); }
  else { ellipse(ctx, -8, -22.5, 1.1, 1.8, skinD); ellipse(ctx, 8, -22.5, 1.1, 1.8, skinD); }
  drawFace(ctx, p, v, skin);
  drawHair(ctx, look.hair, look.hairColor, v, false);
  ctx.restore();
  ctx.restore();
  ctx.restore();
}

/** Small decorative extras used by the game layer. */
export function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color = '#e07a8c', alpha = 1) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = color;
  ctx.beginPath(); ctx.moveTo(0, 3); ctx.bezierCurveTo(-6, -1, -4, -6, 0, -3); ctx.bezierCurveTo(4, -6, 6, -1, 0, 3); ctx.fill(); ctx.restore();
}
export function drawSparkle(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color = '#fff3c4', alpha = 1) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.fillStyle = color; ctx.beginPath();
  ctx.moveTo(0, -s); ctx.quadraticCurveTo(0.2 * s, -0.2 * s, s, 0); ctx.quadraticCurveTo(0.2 * s, 0.2 * s, 0, s); ctx.quadraticCurveTo(-0.2 * s, 0.2 * s, -s, 0); ctx.quadraticCurveTo(-0.2 * s, -0.2 * s, 0, -s); ctx.fill(); ctx.restore();
}
export function drawNote(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color = '#8a6a4b', alpha = 1) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = color; ctx.strokeStyle = color; ctx.lineWidth = 0.9;
  ctx.beginPath(); ctx.ellipse(0, 3, 2, 1.5, -0.4, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.moveTo(1.8, 2.8); ctx.lineTo(1.8, -4); ctx.lineTo(4.4, -2.6); ctx.stroke(); ctx.restore();
}
