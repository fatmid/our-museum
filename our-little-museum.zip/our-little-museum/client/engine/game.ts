// The game: canvas rendering, input, local movement, remote players, effects and the glue to the WebSocket protocol.
import { ACT_MS, otherSlot, type Anim, type Dir, type IxState, type Look, type MuseumBundle, type Slot } from '../../shared/types';
import { TILE, buildWorld, blocked, moveWithCollision, roomAt, PLAYER_SPEED, dist, dirFromVec, type World, type WFrame, type WBench } from '../../shared/world';
import { drawChar, drawHeart, drawSparkle, drawNote } from './chars';
import { ImageCache, RoomCache, drawBackdrop, drawCorridors, drawBench, drawPlant, drawLamp, drawPedestal, drawRecordPlayer, drawFramePhoto, drawLighting, lampGlows, thumbUrl } from './render';
import type { Net } from '../net';

export interface Near { kind: 'frame' | 'bench' | 'record' | 'pedestal'; key: string; label: string; frame?: WFrame; bench?: WBench; seat?: number }
export interface GameUi {
  roomId: number | null; roomName: string; peerRoomId: number | null; peerOnline: boolean; peerName: string; peerDist: number;
  near: Near | null; seated: boolean; locked: boolean; anim: Anim; peerSeated: boolean; connected: boolean;
}
export interface GameCb {
  openFrame(frame: WFrame): void; openMusic(): void; pedestal(): void; toast(text: string): void; wantRefresh(): void; waved(): void;
}
interface Actor {
  slot: Slot; name: string; look: Look; x: number; y: number; d: Dir; moving: boolean; walk: number; anim: Anim; animAt: number; seat: string | null;
  online: boolean; room: number | null; tx: number; ty: number; netMoving: boolean;
  glide: { fx: number; fy: number; tx: number; ty: number; t0: number; dur: number; d: Dir } | null; fx: number;
}
interface P { k: 'heart' | 'spark' | 'note' | 'confetti'; x: number; y: number; vx: number; vy: number; life: number; max: number; s: number; c: string }
const ONE_SHOT_SEATED: Anim[] = ['wave', 'heart', 'kiss', 'shy'];
const mkActor = (slot: Slot, look: Look, name: string): Actor => ({ slot, name, look, x: 0, y: 0, d: 'down', moving: false, walk: 0, anim: 'idle', animAt: 0, seat: null, online: false, room: null, tx: 0, ty: 0, netMoving: false, glide: null, fx: 0 });
const ease = (p: number) => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);

export class Game {
  private ctx: CanvasRenderingContext2D; private dpr = 1; private W = 0; private H = 0;
  world: World; private imgs = new ImageCache(); private rooms = new RoomCache();
  me: Actor; peer: Actor; ix: IxState | null = null; ixData: any = {};
  private keys = new Set<string>(); private stick = { x: 0, y: 0 }; private blockedUi = false;
  private camx = 0; private camy = 0; private zoom = 2; private camInit = false;
  private parts: P[] = []; private time = 0; private last = 0; private raf = 0; private destroyed = false;
  private lastSend = 0; private sentMoving = false; private pendingStand = false; private fxClock = new Map<string, number>();
  private warm = 0; private met = false; private metAt = 0; private welcomed = false; private lastPeerDist = 999;
  ui: GameUi; private uiSubs = new Set<() => void>(); private offs: (() => void)[] = []; private ro: ResizeObserver | null = null;

  constructor(private canvas: HTMLCanvasElement, public bundle: MuseumBundle, private net: Net, private cb: GameCb, public reduced: boolean) {
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.world = buildWorld(bundle);
    const you = bundle.you, other = otherSlot(you);
    this.me = mkActor(you, bundle.players[you].look, bundle.players[you].name);
    this.peer = mkActor(other, bundle.players[other].look, bundle.players[other].name);
    const s = this.world.rooms.find((r) => r.row.is_entrance) || this.world.rooms[0];
    const sx = s ? s.px + 8 * TILE : 100, sy = s ? s.py + 5 * TILE : 100;
    this.me.x = this.me.tx = this.camx = sx; this.me.y = this.me.ty = this.camy = sy;
    this.ui = { roomId: null, roomName: '', peerRoomId: null, peerOnline: false, peerName: this.peer.name, peerDist: 999, near: null, seated: false, locked: false, anim: 'idle', peerSeated: false, connected: false };
    this.offs.push(net.on(this.onNet));
    const kd = (e: KeyboardEvent) => this.onKey(e, true), ku = (e: KeyboardEvent) => this.onKey(e, false);
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);
    const blur = () => { this.keys.clear(); }; window.addEventListener('blur', blur);
    this.offs.push(() => { window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); window.removeEventListener('blur', blur); });
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(canvas.parentElement || canvas);
    this.resize();
    this.raf = requestAnimationFrame(this.frame);
  }

  // ------------------------------------------------------------------ lifecycle / external API
  destroy() { this.destroyed = true; cancelAnimationFrame(this.raf); this.offs.forEach((f) => f()); this.ro?.disconnect(); }
  subscribe = (fn: () => void) => { this.uiSubs.add(fn); return () => { this.uiSubs.delete(fn); }; };
  getUi = () => this.ui;
  setBlocked(b: boolean) { this.blockedUi = b; if (b) { this.keys.clear(); this.stick = { x: 0, y: 0 }; } }
  setStick(x: number, y: number) { this.stick = { x, y }; }
  setReduced(r: boolean) { this.reduced = r; }
  setBundle(b: MuseumBundle) {
    this.bundle = b; this.world = buildWorld(b); this.rooms.clear();
    for (const [a, slot] of [[this.me, this.me.slot], [this.peer, this.peer.slot]] as [Actor, Slot][]) { a.look = b.players[slot].look; a.name = b.players[slot].name; }
    this.ui = { ...this.ui, peerName: this.peer.name };
  }
  get locked() { return !!this.ix && this.ix.stage !== 'invited' && this.ix.kind !== 'hands'; }
  private actor(s: Slot) { return s === this.me.slot ? this.me : this.peer; }

  /** Player pressed E / the interact button. */
  interact() {
    const n = this.ui.near; if (!n || this.blockedUi || this.locked) return;
    if (n.kind === 'frame' && n.frame) this.cb.openFrame(n.frame);
    else if (n.kind === 'bench') this.sit();
    else if (n.kind === 'record') this.cb.openMusic();
    else if (n.kind === 'pedestal') this.cb.pedestal();
  }
  /** Space / the context button. */
  context() {
    if (this.blockedUi || this.locked) return;
    if (this.me.seat) return this.stand();
    const n = this.ui.near; if (n?.kind === 'bench') return this.sit();
    const a = this.effAnim(this.me);
    if (a.startsWith('dance')) return this.act('idle');
    this.act('dance1');
  }
  sit() {
    const n = this.ui.near; if (!n || n.kind !== 'bench' || !n.bench || this.me.seat) return;
    this.net.send({ t: 'sit', key: n.bench.key, idx: n.seat });
  }
  stand() { if (this.me.seat) this.net.send({ t: 'stand' }); }
  act(a: Anim) {
    if (this.locked) return;
    if (this.me.seat && a !== 'idle' && !ONE_SHOT_SEATED.includes(a)) { this.cb.toast('Stand up first ♡'); return; }
    const now = this.net.serverNow();
    this.me.anim = this.me.seat && a === 'idle' ? 'sit' : a; this.me.animAt = now;
    this.net.send({ t: 'act', a });
    this.startFx(this.me, a);
  }

  // ------------------------------------------------------------------ input
  private onKey(e: KeyboardEvent, down: boolean) {
    const tg = e.target as HTMLElement | null;
    if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.tagName === 'SELECT' || tg.isContentEditable)) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const move = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd'].includes(k);
    if (!down) { this.keys.delete(k); return; }
    if (this.blockedUi) return;
    if (move) { this.keys.add(k); e.preventDefault(); return; }
    if (e.repeat) return;
    if (k === 'e') { this.interact(); e.preventDefault(); }
    else if (k === ' ') { if (tg && tg.tagName === 'BUTTON') return; this.context(); e.preventDefault(); }
  }
  private inputVec(): { x: number; y: number } {
    let x = 0, y = 0; const k = this.keys;
    if (k.has('ArrowLeft') || k.has('a')) x -= 1; if (k.has('ArrowRight') || k.has('d')) x += 1;
    if (k.has('ArrowUp') || k.has('w')) y -= 1; if (k.has('ArrowDown') || k.has('s')) y += 1;
    if (x === 0 && y === 0 && (this.stick.x || this.stick.y)) { x = this.stick.x; y = this.stick.y; }
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    return { x, y };
  }

  // ------------------------------------------------------------------ network
  private onNet = (m: any) => {
    const now = this.net.serverNow();
    switch (m.t) {
      case 'welcome': {
        this.snapActor(this.me, m.you); this.snapActor(this.peer, m.peer);
        this.peer.name = m.names?.[this.peer.slot] || this.peer.name; this.me.name = m.names?.[this.me.slot] || this.me.name;
        this.ix = m.ix || null; this.ixData = m.ix?.data || {}; if (this.ix) this.ixAnims();
        this.camInit = false; this.pendingStand = false; this.welcomed = true;
        if (m.version && m.version !== this.bundle.version) this.cb.wantRefresh();
        if (this.peer.online && !this.ix) this.wave(1400);
        break;
      }
      case 'presence': { const was = this.peer.online; this.snapActor(this.peer, m.peer); if (!was && this.peer.online) { this.cb.toast(`${this.peer.name} is here ♡`); this.wave(900); } else if (was && !this.peer.online) this.cb.toast(`${this.peer.name} stepped away ♡`); break; }
      case 'p': { const p = this.peer; p.tx = m.x; p.ty = m.y; p.d = m.d; p.netMoving = !!m.mv; p.room = m.room ?? p.room; p.online = true; if (!this.ix && m.a && m.a !== p.anim) { p.anim = m.a; p.animAt = now; } break; }
      case 'act': { const a = this.actor(m.s); a.anim = m.a; a.animAt = m.at; if (a === this.peer) this.startFx(a, m.a); break; }
      case 'act_ok': { this.me.animAt = m.at; break; }
      case 'seat': {
        const a = this.actor(m.s); a.seat = m.seat; a.netMoving = false;
        a.glide = { fx: a.x, fy: a.y, tx: m.x, ty: m.y, t0: performance.now(), dur: 280, d: m.d }; a.tx = m.x; a.ty = m.y;
        a.anim = m.seat ? 'sit' : 'idle'; a.animAt = now;
        if (a === this.me) this.pendingStand = false;
        break;
      }
      case 'correct': { this.me.x = this.me.tx = m.x; this.me.y = this.me.ty = m.y; this.me.d = m.d; this.me.glide = null; break; }
      case 'together_sit': { const b = this.world.benches.find((x) => x.key === m.key); if (b) this.burst('heart', (b.tx + 1) * TILE, b.ty * TILE + 4, 7); break; }
      case 'ix_start': {
        this.ix = m.ix; this.ixData = m.ix.data || {};
        const t = performance.now();
        for (const slot of ['fatmid', 'fatima'] as Slot[]) { const sp = m.ix.spots?.[slot]; if (!sp) continue; const a = this.actor(slot); a.seat = null; a.glide = { fx: a.x, fy: a.y, tx: sp.x, ty: sp.y, t0: t, dur: 700, d: sp.d }; a.tx = sp.x; a.ty = sp.y; a.anim = 'idle'; a.animAt = now; }
        this.pendingStand = false;
        break;
      }
      case 'ix_stage': {
        if (!this.ix || this.ix.id !== m.id) break;
        this.ix = { ...this.ix, stage: m.stage }; if (m.data) this.ixData = { ...this.ixData, ...m.data };
        this.ixAnims();
        const mid = this.mid();
        if (m.stage === 'yes') this.burst('confetti', mid.x, mid.y - 24, 26);
        if (m.stage === 'hug' || m.stage === 'play') this.burst('heart', mid.x, mid.y - 26, 5);
        if (m.stage === 'ring') this.burst('spark', this.actor(this.ix.from).x + 12, this.actor(this.ix.from).y - 20, 8);
        break;
      }
      case 'ix_end': {
        if (this.ix && this.ix.id !== m.id) break;
        this.ix = null; this.ixData = {};
        for (const a of [this.me, this.peer]) { a.anim = a.seat ? 'sit' : 'idle'; a.animAt = now; }
        break;
      }
      case 'museum_updated': this.cb.wantRefresh(); break;
    }
  };
  private snapActor(a: Actor, s: any) {
    if (!s) return;
    a.online = a === this.me ? true : !!s.online; a.x = a.tx = s.x; a.y = a.ty = s.y; a.d = s.d; a.anim = s.anim; a.animAt = s.animAt || this.net.serverNow(); a.seat = s.seat; a.room = s.room; a.glide = null; a.netMoving = false; a.moving = false;
  }
  private ixAnims() {
    const i = this.ix; if (!i) return; const A = this.actor(i.from), B = this.actor(otherSlot(i.from)); const st = i.stage; const now = this.net.serverNow();
    const set = (a: Anim, b: Anim) => { A.anim = a; B.anim = b; A.animAt = B.animAt = now; };
    if (i.kind === 'hug') { if (st === 'play') set('hug', 'hug'); }
    else if (i.kind === 'dance') { if (st === 'play') { const v = this.ixData?.variant || i.data?.variant || 1; set(`dance${v}` as Anim, `dance${v}` as Anim); } }
    else if (i.kind === 'photo') { if (['pose', 'count', 'flash'].includes(st)) set('photo', 'photo'); }
    else if (i.kind === 'propose') {
      if (['kneel', 'ring', 'msg1', 'msg2', 'ask', 'later'].includes(st)) set('kneel', 'shy'); else if (st === 'yes') set('cheer', 'cheer'); else if (st === 'hug') set('hug', 'hug');
    }
  }
  private wave(delay: number) { setTimeout(() => { if (!this.destroyed && !this.me.seat && !this.locked && this.peer.online && this.effAnim(this.me) === 'idle' && !this.me.moving) { this.act('wave'); this.cb.waved(); } }, delay); }

  // ------------------------------------------------------------------ helpers
  private mid() { return { x: (this.me.x + this.peer.x) / 2, y: (this.me.y + this.peer.y) / 2 }; }
  effAnim(a: Actor): Anim {
    const dur = ACT_MS[a.anim] || 0; const age = this.net.serverNow() - a.animAt;
    if (a.seat) return ONE_SHOT_SEATED.includes(a.anim) && age < dur + 80 ? a.anim : 'sit';
    if (dur > 0 && age > dur + 80) return 'idle';
    return a.anim;
  }
  private startFx(a: Actor, anim: Anim) {
    this.fxClock.set(a.slot, 0);
    if (anim === 'kiss') { const o = a === this.me ? this.peer : this.me; const dir = o.online && o.x !== a.x ? Math.sign(o.x - a.x) : a.d === 'left' ? -1 : 1; this.parts.push({ k: 'heart', x: a.x + dir * 8, y: a.y - 22, vx: dir * 38, vy: -18, life: 0, max: 1.4, s: 1.3, c: '#e07a8c' }); }
    if (anim === 'heart') this.burst('heart', a.x, a.y - 34, 3);
  }
  private burst(k: P['k'], x: number, y: number, n: number) {
    const cols = ['#e07a8c', '#f2b8c2', '#e9a177', '#f0cf7a', '#b8c9a8', '#d9c0dc'];
    const cnt = this.reduced ? Math.ceil(n / 3) : n;
    for (let i = 0; i < cnt && this.parts.length < 90; i++) {
      const ang = k === 'confetti' ? -Math.PI / 2 + (Math.random() - 0.5) * 2.4 : -Math.PI / 2 + (Math.random() - 0.5) * 1.2; const sp = k === 'confetti' ? 40 + Math.random() * 60 : 14 + Math.random() * 18;
      this.parts.push({ k, x: x + (Math.random() - 0.5) * 16, y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, life: 0, max: 1.6 + Math.random() * 0.9, s: 0.8 + Math.random() * 0.6, c: k === 'heart' ? ['#e07a8c', '#f2a0b0', '#d9657a'][i % 3] : cols[i % cols.length] });
    }
  }
  private emitFx(a: Actor, anim: Anim, dt: number) {
    const clk = (this.fxClock.get(a.slot) ?? 0) + dt; this.fxClock.set(a.slot, clk);
    const every = (sec: number) => { const key = a.slot + sec; const prev = this.fxClock.get(key) ?? 0; if (clk - prev > sec * (this.reduced ? 2.2 : 1)) { this.fxClock.set(key, clk); return true; } return false; };
    if (anim === 'heart' && clk < 2.4 && every(0.4)) this.burst('heart', a.x, a.y - 36, 1);
    else if (anim.startsWith('dance') && every(0.7)) this.parts.push({ k: 'note', x: a.x + (Math.random() - 0.5) * 18, y: a.y - 38, vx: (Math.random() - 0.5) * 10, vy: -16, life: 0, max: 1.6, s: 1.1, c: '#8a6a4b' });
    else if ((anim === 'spin' || anim === 'dance2') && every(0.3)) this.parts.push({ k: 'spark', x: a.x + (Math.random() - 0.5) * 22, y: a.y - 12 - Math.random() * 22, vx: 0, vy: -6, life: 0, max: 0.9, s: 3.4, c: '#fff3c4' });
    else if (anim === 'cheer' && every(0.35)) this.burst('heart', a.x, a.y - 36, 1);
    else if (anim === 'hug' && every(0.8)) this.burst('heart', a.x, a.y - 36, 1);
  }

  // ------------------------------------------------------------------ update
  private frame = (ts: number) => {
    if (this.destroyed) return;
    const dt = Math.min(0.05, this.last ? (ts - this.last) / 1000 : 0.016); this.last = ts; this.time += dt;
    this.update(dt); this.draw(); this.raf = requestAnimationFrame(this.frame);
  };

  private update(dt: number) {
    const me = this.me, peer = this.peer; const now = performance.now();
    // glides (seat transitions, interaction positioning)
    for (const a of [me, peer]) {
      const g = a.glide; if (!g) continue; const p = Math.min(1, (now - g.t0) / g.dur); const e = ease(p);
      a.x = g.fx + (g.tx - g.fx) * e; a.y = g.fy + (g.ty - g.fy) * e; a.moving = p < 1 && Math.hypot(g.tx - g.fx, g.ty - g.fy) > 6;
      if (a.moving) { a.d = dirFromVec(g.tx - g.fx, g.ty - g.fy, a.d); a.walk += dt * 9; }
      if (p >= 1) { a.glide = null; a.moving = false; a.d = g.d; a.x = g.tx; a.y = g.ty; }
    }
    // local movement
    const hands = this.ix?.kind === 'hands' && this.ix.stage === 'play' && peer.online;
    const vec = this.blockedUi || this.locked || me.glide ? { x: 0, y: 0 } : this.inputVec();
    const wantMove = vec.x !== 0 || vec.y !== 0;
    if (me.seat) {
      if (wantMove && !this.pendingStand) { this.pendingStand = true; this.net.send({ t: 'stand' }); }
      me.moving = false;
    } else if (!me.glide && !this.locked) {
      let moved = false;
      if (wantMove) {
        const step = PLAYER_SPEED * dt; const r = moveWithCollision(this.world, me.x, me.y, vec.x * step, vec.y * step);
        let nx = r.x, ny = r.y;
        if (hands && dist(nx, ny, peer.x, peer.y) > 84 && dist(nx, ny, peer.x, peer.y) > dist(me.x, me.y, peer.x, peer.y)) { nx = me.x; ny = me.y; }
        moved = Math.hypot(nx - me.x, ny - me.y) > 0.01;
        if (moved) { me.d = dirFromVec(nx - me.x, ny - me.y, me.d); me.walk += Math.hypot(nx - me.x, ny - me.y) * 0.36; }
        else if (Math.abs(vec.x) + Math.abs(vec.y) > 0) me.d = dirFromVec(vec.x, vec.y, me.d);
        me.x = nx; me.y = ny;
        if (moved && me.anim !== 'idle') { me.anim = 'idle'; me.animAt = this.net.serverNow(); }
      } else if (hands) { // follow the partner so the two walk together
        const sp = this.ix!.spots; const off = sp ? { x: sp[me.slot].x - sp[peer.slot].x, y: sp[me.slot].y - sp[peer.slot].y } : { x: -30, y: 0 };
        const gx = peer.x + off.x, gy = peer.y + off.y; const d = Math.hypot(gx - me.x, gy - me.y);
        if (d > 4) { const step = Math.min(d, PLAYER_SPEED * 1.05 * dt); const r = moveWithCollision(this.world, me.x, me.y, ((gx - me.x) / d) * step, ((gy - me.y) / d) * step); moved = Math.hypot(r.x - me.x, r.y - me.y) > 0.01; if (moved) { me.d = dirFromVec(gx - me.x, gy - me.y, me.d); me.walk += Math.hypot(r.x - me.x, r.y - me.y) * 0.36; } me.x = r.x; me.y = r.y; }
      }
      me.moving = moved;
      const t = performance.now();
      if ((moved && t - this.lastSend > 66) || (!moved && this.sentMoving)) { this.net.send({ t: 'pos', x: Math.round(me.x * 10) / 10, y: Math.round(me.y * 10) / 10, d: me.d, mv: moved ? 1 : 0 }); this.lastSend = t; this.sentMoving = moved; }
    }
    const mr = roomAt(this.world, me.x, me.y); me.room = mr?.row.id ?? me.room;
    // remote player smoothing
    if (!peer.glide && !peer.seat) {
      const dx = peer.tx - peer.x, dy = peer.ty - peer.y; const d = Math.hypot(dx, dy);
      if (d > 150) { peer.x = peer.tx; peer.y = peer.ty; peer.moving = false; }
      else { const k = 1 - Math.exp(-dt * 13); const nx = peer.x + dx * k, ny = peer.y + dy * k; const moved = Math.hypot(nx - peer.x, ny - peer.y); peer.x = nx; peer.y = ny; peer.walk += moved * 0.36; peer.moving = peer.netMoving || moved > 0.15; if (d < 0.4) { peer.x = peer.tx; peer.y = peer.ty; } if (!peer.netMoving && d < 1.5) peer.moving = false; }
    } else if (peer.seat && !peer.glide) { peer.x = peer.tx; peer.y = peer.ty; peer.moving = false; }
    // meeting jump
    const pd = peer.online ? dist(me.x, me.y, peer.x, peer.y) : 999;
    if (peer.online && pd < 64 && this.lastPeerDist > 200 && now - this.metAt > 60_000 && !this.locked && !me.seat && me.room === peer.room) { this.metAt = now; this.met = true; setTimeout(() => { if (!this.destroyed && !this.locked && !this.me.seat && this.effAnim(this.me) === 'idle' && !this.me.moving) this.act('jump'); }, 250); }
    this.lastPeerDist = pd;
    // effects
    for (const a of [me, peer]) { if (a === peer && !peer.online) continue; this.emitFx(a, this.effAnim(a), dt); }
    if (me.seat && peer.seat && me.seat.split(':')[0] === peer.seat.split(':')[0] && peer.online) { const c = (this.fxClock.get('together') ?? 0) + dt; if (c > (this.reduced ? 2.6 : 1.2)) { this.fxClock.set('together', 0); this.burst('heart', (me.x + peer.x) / 2, Math.min(me.y, peer.y) - 28, 1); } else this.fxClock.set('together', c); }
    const warmT = this.ix?.kind === 'propose' && this.ix.stage !== 'invited' ? 1 : 0; this.warm += (warmT - this.warm) * (1 - Math.exp(-dt * 1.2));
    for (const p of this.parts) { p.life += dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.k === 'confetti') p.vy += 60 * dt; else if (p.k === 'heart') p.vx += Math.sin(p.life * 4 + p.x) * 6 * dt; }
    this.parts = this.parts.filter((p) => p.life < p.max);
    this.updateCamera(dt);
    this.updateUi();
  }

  private updateCamera(dt: number) {
    const me = this.me, peer = this.peer; let tx = me.x, ty = me.y - 10, tz = this.baseZoom();
    const both = peer.online && peer.room === me.room;
    if (this.ix && this.ix.stage !== 'invited' && peer.online) { const m = this.mid(); tx = m.x; ty = m.y - 14; tz = Math.min(this.fitZoom(Math.abs(me.x - peer.x) + 130, Math.abs(me.y - peer.y) + 110), tz * 1.45); }
    else if (both) {
      const halfW = this.W / (2 * tz) - 44, halfH = this.H / (2 * tz) - 56;
      if (Math.abs(peer.x - me.x) < 2 * halfW && Math.abs(peer.y - me.y) < 2 * halfH) { tx = Math.min(Math.max(me.x, peer.x - halfW), peer.x + halfW); ty = Math.min(Math.max(me.y, peer.y - halfH), peer.y + halfH) - 10; }
    }
    if (!this.camInit) { this.camx = tx; this.camy = ty; this.zoom = tz; this.camInit = true; }
    const k = this.reduced ? 1 - Math.exp(-dt * 9) : 1 - Math.exp(-dt * 4.5);
    this.camx += (tx - this.camx) * k; this.camy += (ty - this.camy) * k; this.zoom += (tz - this.zoom) * (1 - Math.exp(-dt * 3));
  }
  private baseZoom() {
    const W = this.W, H = this.H; const tiles = W < 520 ? 8.5 : W < 900 ? 12.5 : 15.5;
    let z = W / (tiles * TILE); if (H / z < 6.5 * TILE) z = H / (6.5 * TILE);
    return Math.max(1.1, Math.min(3.4, z));
  }
  private fitZoom(w: number, h: number) { return Math.min(this.W / w, this.H / h); }

  private updateUi() {
    const me = this.me, peer = this.peer; let near: Near | null = null;
    if (!me.seat && !this.locked && !this.blockedUi) {
      let best = 1e9;
      for (const f of this.world.frames) { const d = dist(me.x, me.y, f.fx, f.fy); if (d < 52 && d < best) { best = d; near = { kind: 'frame', key: 'f' + f.id, label: 'Press E to remember ♡', frame: f }; } }
      for (const b of this.world.benches) for (let i = 0; i < b.seats.length; i++) {
        const s = b.seats[i]; if (peer.seat === `${b.key}:${i}`) continue; const d = dist(me.x, me.y, s.x, s.y) - 6;
        if (d < 56 && d < best - 4) { best = d; near = { kind: 'bench', key: `${b.key}:${i}`, label: 'SIT HERE ♡', bench: b, seat: i }; }
      }
      for (const p of this.world.props) {
        if (!p.interactive) continue; const cx = p.kind === 'record' ? p.tx * TILE + 32 : p.tx * TILE + 16, cy = p.ty * TILE + 30; const d = dist(me.x, me.y, cx, cy);
        if (d < 56 && d < best) { best = d; near = p.kind === 'record' ? { kind: 'record', key: p.key, label: 'Press E to play our songs ♪' } : { kind: 'pedestal', key: p.key, label: 'Press E to look closer ♡' }; }
      }
    }
    const cur = this.ui; const roomId = me.room; const rr = roomId != null ? this.world.roomById.get(roomId) : null;
    const pd = peer.online ? Math.round(dist(me.x, me.y, peer.x, peer.y)) : 999;
    const next: GameUi = {
      roomId, roomName: rr?.row.name || '', peerRoomId: peer.room, peerOnline: peer.online, peerName: peer.name, peerDist: pd < 400 ? Math.round(pd / 10) * 10 : 999,
      near, seated: !!me.seat, locked: this.locked, anim: this.effAnim(me), peerSeated: !!peer.seat, connected: this.net.status === 'open',
    };
    if (cur.roomId === next.roomId && cur.peerRoomId === next.peerRoomId && cur.peerOnline === next.peerOnline && cur.peerName === next.peerName && cur.peerDist === next.peerDist
      && cur.near?.key === next.near?.key && cur.seated === next.seated && cur.locked === next.locked && cur.anim === next.anim && cur.peerSeated === next.peerSeated && cur.connected === next.connected && cur.roomName === next.roomName) return;
    this.ui = next; this.uiSubs.forEach((f) => f());
  }

  // ------------------------------------------------------------------ drawing
  resize() {
    const host = this.canvas.parentElement || this.canvas; const r = host.getBoundingClientRect();
    this.dpr = Math.min(2, window.devicePixelRatio || 1); this.W = Math.max(1, Math.round(r.width)); this.H = Math.max(1, Math.round(r.height));
    this.canvas.width = Math.round(this.W * this.dpr); this.canvas.height = Math.round(this.H * this.dpr);
    this.canvas.style.width = this.W + 'px'; this.canvas.style.height = this.H + 'px';
    this.zoom = this.baseZoom();
  }
  private draw() { this.scene(this.ctx, this.W, this.H, this.dpr, this.camx, this.camy, this.zoom, true); }

  /** A clean picture of the two characters in the museum (no names, hints or HUD). Used for the shared photo moment. */
  capture(w = 960, h = 640): HTMLCanvasElement {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const c = cv.getContext('2d', { alpha: false })!;
    const m = this.peer.online ? this.mid() : { x: this.me.x, y: this.me.y };
    const spread = this.peer.online ? Math.abs(this.me.x - this.peer.x) : 0; const z = Math.min(3.6, Math.max(2.2, (w / (spread + 150))));
    this.scene(c, w, h, 1, m.x, m.y - 18, z, false); return cv;
  }

  private scene(c: CanvasRenderingContext2D, W: number, H: number, dpr: number, camx: number, camy: number, zoom: number, labels: boolean) {
    const bundle = this.bundle, world = this.world, t = this.time;
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high';
    drawBackdrop(c, W, H);
    c.save(); c.translate(W / 2, H / 2); c.scale(zoom, zoom); c.translate(-camx, -camy);
    const vx0 = camx - W / 2 / zoom - 20, vx1 = camx + W / 2 / zoom + 20, vy0 = camy - H / 2 / zoom - 20, vy1 = camy + H / 2 / zoom + 20;
    drawCorridors(c, world, bundle);
    for (const r of world.rooms) { if (r.px > vx1 || r.px + r.pw < vx0 || r.py > vy1 || r.py + r.ph < vy0) continue; c.drawImage(this.rooms.get(r, world, bundle), r.px, r.py, r.pw, r.ph); }
    const near = this.ui.near;
    for (const f of world.frames) {
      if (f.cx + 30 < vx0 || f.cx - 30 > vx1 || f.cy + 30 < vy0 || f.cy - 30 > vy1) continue;
      const img = f.row.photo_id != null ? this.imgs.get(thumbUrl(f.row.photo_id)) : null;
      drawFramePhoto(c, f, world.roomById.get(f.roomId)!, img, labels && near?.kind === 'frame' && near.frame?.id === f.id ? 0.55 + Math.sin(t * 4) * 0.2 : 0);
    }
    const items: { y: number; fn: () => void }[] = [];
    for (const b of world.benches) items.push({ y: b.ty * TILE + 22, fn: () => drawBench(c, b) });
    for (const p of world.props) {
      if (p.tx * TILE < vx0 - 80 || p.tx * TILE > vx1 + 40) continue;
      if (p.kind === 'plant') items.push({ y: p.ty * TILE + 30, fn: () => drawPlant(c, p, t) });
      else if (p.kind === 'lamp') items.push({ y: p.ty * TILE + 30, fn: () => drawLamp(c, p, t) });
      else if (p.kind === 'pedestal') items.push({ y: p.ty * TILE + 30, fn: () => drawPedestal(c, p, t) });
      else if (p.kind === 'record') items.push({ y: p.ty * TILE + 30, fn: () => drawRecordPlayer(c, p, t, this.musicPlaying) });
    }
    const actors = [this.me]; if (this.peer.online) actors.push(this.peer);
    const hands = this.ix?.kind === 'hands' && this.ix.stage === 'play' && this.peer.online;
    const close = this.peer.online && Math.abs(this.me.x - this.peer.x) < 46, rightmost = this.me.x >= this.peer.x ? this.me : this.peer; // stagger name labels so they never overlap
    for (const a of actors) items.push({ y: a.y, fn: () => this.drawActor(c, a, labels, close && a === rightmost ? -13 : 0) });
    if (hands) items.push({ y: Math.max(this.me.y, this.peer.y) + 0.5, fn: () => this.drawHands(c) });
    items.sort((a, b) => a.y - b.y); for (const it of items) it.fn();
    for (const p of this.parts) {
      const k = p.life / p.max; const al = k < 0.15 ? k / 0.15 : 1 - Math.max(0, (k - 0.6) / 0.4);
      if (p.k === 'heart') drawHeart(c, p.x, p.y, p.s * (0.9 + k * 0.5), p.c, al); else if (p.k === 'spark') drawSparkle(c, p.x, p.y, p.s * (1 - k * 0.5), p.c, al);
      else if (p.k === 'note') drawNote(c, p.x, p.y, p.s, p.c, al);
      else { c.save(); c.globalAlpha = al; c.translate(p.x, p.y); c.rotate(p.life * 5); c.fillStyle = p.c; c.fillRect(-1.6, -0.9, 3.2, 1.8); c.restore(); }
    }
    c.restore();
    drawLighting(c, W * dpr, H * dpr, bundle.settings.environment, lampGlows(world), camx, camy, zoom * dpr, t, this.warm);
  }
  musicPlaying = false;

  private drawActor(c: CanvasRenderingContext2D, a: Actor, labels: boolean, labelLift = 0) {
    const anim = this.effAnim(a); const idle = anim === 'idle' || anim === 'sit';
    const tt = idle ? this.time : Math.max(0, (this.net.serverNow() - a.animAt) / 1000);
    const ring = !!this.ix && this.ix.kind === 'propose' && a.slot === this.ix.from && ['ring', 'msg1', 'msg2', 'ask', 'later', 'hug'].includes(this.ix.stage);
    drawChar(c, { x: a.x, y: a.y, look: a.look, dir: a.d, anim, t: tt, walk: a.walk, moving: a.moving, slot: a.slot, ring, reduced: this.reduced });
    if (labels) {
      const y = a.y - (anim === 'kneel' ? 38 : 48) - (anim === 'sit' ? -4 : 0) + labelLift; c.save(); c.font = '600 8px system-ui, sans-serif'; c.textAlign = 'center';
      const w = c.measureText(a.name).width + 10; c.fillStyle = 'rgba(58,44,34,.62)'; c.beginPath(); c.roundRect(a.x - w / 2, y - 8, w, 12, 6); c.fill(); c.fillStyle = '#fbf4e6'; c.fillText(a.name, a.x, y + 0.5); c.restore();
    }
  }
  private drawHands(c: CanvasRenderingContext2D) {
    const L = this.me.x <= this.peer.x ? this.me : this.peer, R = L === this.me ? this.peer : this.me; const y = (L.y + R.y) / 2 - 9;
    c.save(); c.strokeStyle = L.look.skin; c.lineWidth = 3; c.lineCap = 'round'; c.beginPath(); c.moveTo(L.x + 6, y); c.lineTo(R.x - 6, y); c.stroke();
    c.fillStyle = '#f0b6b0'; c.beginPath(); c.arc((L.x + R.x) / 2, y, 1.9, 0, 7); c.fill(); c.restore();
    if (!this.reduced && Math.random() < 0.012) this.burst('heart', (L.x + R.x) / 2, y - 12, 1);
  }
}
