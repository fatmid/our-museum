// World rendering: pre-rendered room backgrounds + dynamic props, photos and lighting.
import type { MuseumBundle, RoomRow } from '../../shared/types';
import { TILE, FLOOR, ROOM_W, ROOM_H, type World, type WRoom, type WFrame, type WBench, type WProp } from '../../shared/world';
import { shade } from './chars';

const S = 2; // pre-render scale
export const FRAME_W = 42, FRAME_H = 38;

export class ImageCache {
  private map = new Map<string, HTMLImageElement | 'loading' | 'error'>();
  onLoad: () => void = () => {};
  get(url: string): HTMLImageElement | null {
    const v = this.map.get(url);
    if (v instanceof HTMLImageElement) return v;
    if (!v) {
      this.map.set(url, 'loading');
      const img = new Image(); img.decoding = 'async';
      img.onload = () => { this.map.set(url, img); this.onLoad(); };
      img.onerror = () => { this.map.set(url, 'error'); };
      img.src = url;
    }
    return null;
  }
  has(url: string) { return this.map.get(url) instanceof HTMLImageElement; }
}
export const thumbUrl = (id: number) => `/api/media/${id}?v=thumb`;
export const fullUrl = (id: number) => `/api/media/${id}`;

function rr(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) { c.beginPath(); c.roundRect(x, y, w, h, r); }
function ell(c: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, f: string) { c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); c.fillStyle = f; c.fill(); }

// ---------------------------------------------------------------- room backgrounds
export class RoomCache {
  private canv = new Map<number, HTMLCanvasElement>();
  clear() { this.canv.clear(); }
  get(w: WRoom, world: World, bundle: MuseumBundle): HTMLCanvasElement {
    let c = this.canv.get(w.row.id);
    if (!c) { c = renderRoom(w, world, bundle); this.canv.set(w.row.id, c); }
    return c;
  }
}

function floorPattern(c: CanvasRenderingContext2D, row: RoomRow) {
  const x0 = FLOOR.x0 * TILE, y0 = FLOOR.y0 * TILE, w = (FLOOR.x1 - FLOOR.x0 + 1) * TILE, h = (FLOOR.y1 - FLOOR.y0 + 1) * TILE;
  const base = row.floor_color; c.fillStyle = base; c.fillRect(x0, y0, w, h);
  c.save(); c.beginPath(); c.rect(x0, y0, w, h); c.clip();
  const pat = row.floor_pattern;
  if (pat === 'planks') {
    for (let y = y0, i = 0; y < y0 + h; y += 16, i++) {
      for (let x = x0 - ((i * 53) % 96); x < x0 + w; x += 96) { c.fillStyle = i % 2 ? shade(base, -0.04) : shade(base, 0.03); c.fillRect(x, y, 95, 15); c.fillStyle = shade(base, -0.12); c.fillRect(x + 95, y, 1, 16); }
      c.fillStyle = shade(base, -0.1); c.fillRect(x0, y + 15, w, 1);
    }
  } else if (pat === 'checker') {
    for (let y = 0; y < h / TILE; y++) for (let x = 0; x < w / TILE; x++) { c.fillStyle = (x + y) % 2 ? shade(base, -0.07) : shade(base, 0.06); c.fillRect(x0 + x * TILE, y0 + y * TILE, TILE, TILE); }
  } else if (pat === 'tiles') {
    for (let y = 0; y < h / TILE; y++) for (let x = 0; x < w / TILE; x++) { c.fillStyle = shade(base, ((x * 7 + y * 3) % 5) * 0.012); c.fillRect(x0 + x * TILE + 1, y0 + y * TILE + 1, TILE - 2, TILE - 2); }
    c.fillStyle = shade(base, -0.14); for (let x = 0; x <= w; x += TILE) c.fillRect(x0 + x, y0, 1, h); for (let y = 0; y <= h; y += TILE) c.fillRect(x0, y0 + y, w, 1);
  } else { c.fillStyle = shade(base, 0.04); for (let i = 0; i < 40; i++) c.fillRect(x0 + ((i * 97) % w), y0 + ((i * 53) % h), 14, 1); }
  c.restore();
}

function wallFace(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string, flipped: boolean) {
  const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, shade(color, flipped ? -0.06 : 0.05)); g.addColorStop(1, shade(color, flipped ? 0.04 : -0.05));
  c.fillStyle = g; c.fillRect(x, y, w, h);
  // wainscot
  const wy = flipped ? y + 6 : y + 38, wh = flipped ? 20 : 24; c.fillStyle = shade(color, -0.07); c.fillRect(x, wy, w, wh);
  c.fillStyle = shade(color, 0.14); c.fillRect(x, flipped ? wy + wh - 1 : wy, w, 1.4);
}

function renderRoom(w: WRoom, world: World, bundle: MuseumBundle): HTMLCanvasElement {
  const cv = document.createElement('canvas'); cv.width = ROOM_W * TILE * S; cv.height = ROOM_H * TILE * S;
  const c = cv.getContext('2d')!; c.scale(S, S);
  const r = w.row; const W = ROOM_W * TILE, H = ROOM_H * TILE;
  const wc = r.wall_color;
  // base: side-wall colour everywhere, then floor + faces on top
  c.fillStyle = shade(wc, -0.16); c.fillRect(0, 0, W, H);
  floorPattern(c, r);
  wallFace(c, 0, 0, W, 64, wc, false);
  wallFace(c, 0, 9 * TILE, W, 64, wc, true);
  // crown moulding + baseboards
  c.fillStyle = shade(wc, 0.2); c.fillRect(0, 0, W, 4); c.fillStyle = shade(wc, -0.22); c.fillRect(0, 4, W, 1.2);
  c.fillStyle = shade(wc, -0.28); c.fillRect(0, 62, W, 2.2); c.fillStyle = shade(wc, -0.28); c.fillRect(0, 9 * TILE, W, 2.2);
  c.fillStyle = shade(wc, 0.2); c.fillRect(0, H - 4, W, 4);
  // side walls (top faces)
  for (const sx of [0, W - TILE]) { const g = c.createLinearGradient(sx, 0, sx + TILE, 0); g.addColorStop(0, shade(wc, sx ? -0.28 : -0.12)); g.addColorStop(1, shade(wc, sx ? -0.12 : -0.28)); c.fillStyle = g; c.fillRect(sx, 64, TILE, 224); }
  // soft shadow on the floor under walls
  let g = c.createLinearGradient(0, 64, 0, 86); g.addColorStop(0, 'rgba(60,40,25,.22)'); g.addColorStop(1, 'rgba(60,40,25,0)'); c.fillStyle = g; c.fillRect(TILE, 64, W - 2 * TILE, 22);
  g = c.createLinearGradient(0, 9 * TILE, 0, 9 * TILE - 16); g.addColorStop(0, 'rgba(60,40,25,.2)'); g.addColorStop(1, 'rgba(60,40,25,0)'); c.fillStyle = g; c.fillRect(TILE, 9 * TILE - 16, W - 2 * TILE, 16);
  for (const sx of [TILE, W - TILE - 12]) { g = c.createLinearGradient(sx, 0, sx + (sx === TILE ? 12 : 12), 0); g.addColorStop(sx === TILE ? 0 : 1, 'rgba(60,40,25,.18)'); g.addColorStop(sx === TILE ? 1 : 0, 'rgba(60,40,25,0)'); c.fillStyle = g; c.fillRect(sx, 64, 12, 224); }

  decor(c, w, bundle);

  // frames (bodies; photos are drawn live)
  for (const f of world.frames) if (f.roomId === r.id) drawFrameBody(c, f, (f.cx - w.px), (f.cy - w.py));

  // door openings: punch through the walls so the corridors show
  const openN = w.doors.n, openS = w.doors.s, openE = w.doors.e, openW = w.doors.w;
  c.save(); c.globalCompositeOperation = 'destination-out';
  if (openN) c.fillRect(7 * TILE, 0, 2 * TILE, 2 * TILE);
  if (openS) c.fillRect(7 * TILE, 9 * TILE, 2 * TILE, 2 * TILE);
  if (openE) c.fillRect(15 * TILE, 4 * TILE, TILE, 3 * TILE);
  if (openW) c.fillRect(0, 4 * TILE, TILE, 3 * TILE);
  c.restore();
  const jamb = shade(wc, -0.34), lintel = shade(wc, 0.22);
  if (openN) { c.fillStyle = jamb; c.fillRect(7 * TILE - 4, 0, 4, 64); c.fillRect(9 * TILE, 0, 4, 64); c.fillStyle = lintel; rr(c, 7 * TILE - 5, 0, 2 * TILE + 10, 8, 3); c.fill(); }
  if (openS) { c.fillStyle = jamb; c.fillRect(7 * TILE - 4, 9 * TILE, 4, 64); c.fillRect(9 * TILE, 9 * TILE, 4, 64); c.fillStyle = lintel; rr(c, 7 * TILE - 5, H - 8, 2 * TILE + 10, 8, 3); c.fill(); }
  if (openE) { c.fillStyle = jamb; c.fillRect(15 * TILE, 4 * TILE - 4, TILE, 4); c.fillRect(15 * TILE, 7 * TILE, TILE, 4); }
  if (openW) { c.fillStyle = jamb; c.fillRect(0, 4 * TILE - 4, TILE, 4); c.fillRect(0, 7 * TILE, TILE, 4); }
  return cv;
}

function drawFrameBody(c: CanvasRenderingContext2D, f: WFrame, cx: number, cy: number) {
  const x = cx - FRAME_W / 2, y = cy - FRAME_H / 2;
  c.fillStyle = 'rgba(40,25,15,.25)'; rr(c, x + 1.5, y + 3, FRAME_W, FRAME_H, 2); c.fill();
  const g = c.createLinearGradient(x, y, x + FRAME_W, y + FRAME_H); g.addColorStop(0, '#b8895a'); g.addColorStop(0.5, '#e0bd86'); g.addColorStop(1, '#9a6c42');
  c.fillStyle = g; rr(c, x, y, FRAME_W, FRAME_H, 2); c.fill();
  c.fillStyle = '#f7f1e4'; c.fillRect(x + 3, y + 3, FRAME_W - 6, FRAME_H - 6);
  c.fillStyle = '#efe5d2'; c.fillRect(x + 4.5, y + 4.5, FRAME_W - 9, FRAME_H - 9);
  if (f.wall === 'north') { c.fillStyle = '#c9a56b'; rr(c, cx - 6, y + FRAME_H + 1.5, 12, 3, 1); c.fill(); }
}

function decor(c: CanvasRenderingContext2D, w: WRoom, bundle: MuseumBundle) {
  const r = w.row; const W = ROOM_W * TILE; const d = r.decor;
  const rug = (x: number, y: number, rw: number, rh: number, col: string, round = false) => {
    c.save(); c.fillStyle = 'rgba(60,40,25,.15)'; if (round) { c.beginPath(); c.ellipse(x + rw / 2, y + rh / 2 + 2, rw / 2, rh / 2, 0, 0, 7); c.fill(); } else { rr(c, x + 1, y + 3, rw, rh, 4); c.fill(); }
    c.fillStyle = col; if (round) { c.beginPath(); c.ellipse(x + rw / 2, y + rh / 2, rw / 2, rh / 2, 0, 0, 7); c.fill(); c.strokeStyle = shade(col, 0.35); c.lineWidth = 1.5; c.beginPath(); c.ellipse(x + rw / 2, y + rh / 2, rw / 2 - 6, rh / 2 - 6, 0, 0, 7); c.stroke(); }
    else { rr(c, x, y, rw, rh, 4); c.fill(); c.strokeStyle = shade(col, 0.35); c.lineWidth = 1.5; rr(c, x + 6, y + 6, rw - 12, rh - 12, 3); c.stroke(); c.strokeStyle = shade(col, -0.12); c.setLineDash([2, 3]); rr(c, x + 11, y + 11, rw - 22, rh - 22, 2); c.stroke(); }
    c.restore();
  };
  if (d === 'rug') rug(120, 124, 272, 108, shade('#d9a49c', 0.0));
  if (d === 'entrance') {
    rug(214, 188, 84, 54, '#b99a7a');
    // sign plaque
    c.fillStyle = 'rgba(40,25,15,.25)'; rr(c, 206, 12, 100, 34, 3); c.fill();
    const g = c.createLinearGradient(0, 10, 0, 44); g.addColorStop(0, '#7a5538'); g.addColorStop(1, '#5a3d28'); c.fillStyle = g; rr(c, 204, 9, 104, 34, 3); c.fill();
    c.strokeStyle = '#e0bd86'; c.lineWidth = 1; rr(c, 207, 12, 98, 28, 2); c.stroke();
    c.fillStyle = '#f4e6c8'; c.textAlign = 'center'; c.font = 'bold 8.5px Georgia, serif'; c.fillText(bundle.settings.title.length > 22 ? 'OUR LITTLE MUSEUM' : bundle.settings.title, 256, 25); c.font = '6px Georgia, serif'; c.fillStyle = '#e0bd86'; c.fillText('♡  welcome  ♡', 256, 35);
    // coat hooks
    c.fillStyle = '#7a5538'; c.fillRect(60, 24, 52, 4); for (const x of [68, 86, 104]) { c.fillStyle = '#c9a56b'; c.beginPath(); c.arc(x, 31, 2, 0, 7); c.fill(); }
    c.fillStyle = '#d98c9b'; rr(c, 83, 32, 8, 14, 3); c.fill();
  }
  if (d === 'bunting') {
    c.strokeStyle = '#8a6a4b'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(40, 8); c.quadraticCurveTo(256, 22, 472, 8); c.stroke();
    const cols = ['#e9b7b0', '#f4e6c8', '#b8c9a8', '#d9c0dc', '#f0d49a'];
    for (let i = 0; i < 17; i++) { const t = (i + 0.5) / 17; const x = 40 + t * 432; const y = 8 + 14 * 4 * t * (1 - t) * 0.5 * 1.0; c.fillStyle = cols[i % 5]; c.beginPath(); c.moveTo(x - 6, y); c.lineTo(x + 6, y); c.lineTo(x, y + 10); c.fill(); }
  }
  if (d === 'window') {
    const x = 232, y = 9; const sky = c.createLinearGradient(0, y, 0, y + 36); sky.addColorStop(0, '#bcdcec'); sky.addColorStop(1, '#f8e8c8');
    c.fillStyle = '#e8dcc4'; rr(c, x - 3, y - 3, 54, 44, 3); c.fill(); c.fillStyle = sky; c.beginPath(); c.moveTo(x, y + 36); c.lineTo(x, y + 12); c.quadraticCurveTo(x + 24, y - 6, x + 48, y + 12); c.lineTo(x + 48, y + 36); c.fill();
    c.fillStyle = '#9fb88c'; c.beginPath(); c.moveTo(x, y + 36); c.quadraticCurveTo(x + 14, y + 22, x + 26, y + 30); c.quadraticCurveTo(x + 38, y + 24, x + 48, y + 34); c.lineTo(x + 48, y + 36); c.fill();
    c.strokeStyle = '#e8dcc4'; c.lineWidth = 2; c.beginPath(); c.moveTo(x + 24, y + 4); c.lineTo(x + 24, y + 36); c.moveTo(x, y + 22); c.lineTo(x + 48, y + 22); c.stroke(); c.fillStyle = '#d3c4a6'; c.fillRect(x - 5, y + 38, 58, 3);
    c.save(); c.globalAlpha = 0.16; c.fillStyle = '#fff6d8'; c.beginPath(); c.moveTo(x, 64); c.lineTo(x + 48, 64); c.lineTo(x + 90, 150); c.lineTo(x + 20, 150); c.fill(); c.restore();
  }
  if (d === 'songs') {
    for (const x of [58, W - 58]) { ell(c, x, 30, 14, 14, '#2b2320'); ell(c, x, 30, 5, 5, '#d98c9b'); c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 0.6; for (const rr_ of [8, 10.5, 12.5]) { c.beginPath(); c.arc(x, 30, rr_, 0, 7); c.stroke(); } }
    c.fillStyle = '#8a6a4b'; c.font = '14px serif'; c.textAlign = 'center'; c.fillText('♪', 120, 34); c.fillText('♫', 392, 34);
    rug(112, 132, 200, 100, '#b79ba8', true);
  }
  if (d === 'promise') {
    c.strokeStyle = '#8aa17c'; c.lineWidth = 3; c.beginPath(); c.ellipse(256, 28, 22, 18, 0, 0, 7); c.stroke(); c.strokeStyle = '#a9be9a'; c.lineWidth = 1.5; c.beginPath(); c.ellipse(256, 28, 22, 18, 0.3, 0, 7); c.stroke();
    for (let i = 0; i < 10; i++) { const a = (i / 10) * 7; ell(c, 256 + Math.cos(a) * 22, 28 + Math.sin(a) * 18, 2.6, 1.6, i % 2 ? '#e9b7b0' : '#d98c9b'); }
    c.fillStyle = '#d98c9b'; c.font = '14px serif'; c.textAlign = 'center'; c.fillText('♡', 256, 33);
    rug(168, 124, 176, 110, '#d4959f', true);
  }
}

// ---------------------------------------------------------------- corridors & backdrop
export function drawBackdrop(c: CanvasRenderingContext2D, w: number, h: number) {
  const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#2c231e'); g.addColorStop(1, '#3a2d26'); c.fillStyle = g; c.fillRect(0, 0, w, h);
}
export function drawCorridors(c: CanvasRenderingContext2D, world: World, bundle: MuseumBundle) {
  for (const d of world.doors) {
    const x = d.x0 * TILE, y = d.y0 * TILE, w = (d.x1 - d.x0 + 1) * TILE, h = (d.y1 - d.y0 + 1) * TILE;
    const ra = world.roomById.get(d.a)!, rb = world.roomById.get(d.b)!;
    const floor = shade(ra.row.floor_color, -0.05);
    if (d.orient === 'h') {
      c.fillStyle = shade(ra.row.wall_color, -0.12); c.fillRect(x, y - TILE, w, TILE);
      c.fillStyle = shade(ra.row.wall_color, -0.3); c.fillRect(x, y + h, w, TILE);
      c.fillStyle = floor; c.fillRect(x, y, w, h);
      c.fillStyle = shade(ra.row.wall_color, -0.28); c.fillRect(x, y - 3, w, 3);
      const g = c.createLinearGradient(0, y, 0, y + 14); g.addColorStop(0, 'rgba(60,40,25,.22)'); g.addColorStop(1, 'rgba(60,40,25,0)'); c.fillStyle = g; c.fillRect(x, y, w, 14);
      c.fillStyle = '#c9a07c'; c.globalAlpha = 0.55; rr(c, x - 24, y + 22, w + 48, 52, 4); c.fill(); c.globalAlpha = 1; c.strokeStyle = '#e9d3b8'; c.lineWidth = 1.2; rr(c, x - 20, y + 26, w + 40, 44, 3); c.stroke();
    } else {
      c.fillStyle = shade(rb.row.wall_color, -0.2); c.fillRect(x - TILE, y, TILE, h); c.fillRect(x + w, y, TILE, h);
      c.fillStyle = floor; c.fillRect(x, y, w, h);
      for (const sx of [x, x + w - 14]) { const g = c.createLinearGradient(sx, 0, sx + 14, 0); g.addColorStop(sx === x ? 0 : 1, 'rgba(60,40,25,.22)'); g.addColorStop(sx === x ? 1 : 0, 'rgba(60,40,25,0)'); c.fillStyle = g; c.fillRect(sx, y, 14, h); }
      c.fillStyle = '#c9a07c'; c.globalAlpha = 0.55; rr(c, x + 10, y - 6, w - 20, h + 12, 4); c.fill(); c.globalAlpha = 1; c.strokeStyle = '#e9d3b8'; c.lineWidth = 1.2; rr(c, x + 14, y - 2, w - 28, h + 4, 3); c.stroke();
    }
  }
  void bundle;
}

// ---------------------------------------------------------------- dynamic props
const BENCH: Record<string, { top: string; edge: string; leg: string; cushion?: string }> = {
  oak: { top: '#c8a173', edge: '#8f6a45', leg: '#6f4f33' }, walnut: { top: '#8a6040', edge: '#5e4029', leg: '#4a3220' },
  cushion: { top: '#8f6a45', edge: '#6f4f33', leg: '#5a3f2a', cushion: '#e8b9b2' }, white: { top: '#f3eee4', edge: '#c9bfae', leg: '#a89d8b' },
};
export function drawBench(c: CanvasRenderingContext2D, b: WBench) {
  const s = BENCH[b.style] || BENCH.oak; const x = b.tx * TILE + 1, y = b.ty * TILE + 9, w = 2 * TILE - 2;
  c.fillStyle = 'rgba(40,25,15,.22)'; c.beginPath(); c.ellipse(x + w / 2, y + 24, w / 2 + 1, 5, 0, 0, 7); c.fill();
  c.fillStyle = s.leg; c.fillRect(x + 4, y + 11, 4, 12); c.fillRect(x + w - 8, y + 11, 4, 12);
  c.fillStyle = s.edge; rr(c, x, y + 4, w, 11, 3); c.fill();
  c.fillStyle = s.top; rr(c, x, y, w, 10, 3); c.fill();
  if (s.cushion) { c.fillStyle = s.cushion; rr(c, x + 3, y - 2, w - 6, 9, 4); c.fill(); c.fillStyle = 'rgba(255,255,255,.35)'; rr(c, x + 6, y - 1, w - 12, 2.2, 1); c.fill(); }
  else { c.fillStyle = 'rgba(255,255,255,.22)'; c.fillRect(x + 3, y + 1, w - 6, 1.5); }
}

export function drawPlant(c: CanvasRenderingContext2D, p: WProp, t: number) {
  const x = p.tx * TILE + 16, y = p.ty * TILE + 30; const sway = Math.sin(t * 1.3 + p.tx) * 0.8;
  c.fillStyle = 'rgba(40,25,15,.2)'; c.beginPath(); c.ellipse(x, y, 11, 3.5, 0, 0, 7); c.fill();
  const pot = (col: string, h = 11) => { c.fillStyle = col; c.beginPath(); c.moveTo(x - 7, y - h); c.lineTo(x + 7, y - h); c.lineTo(x + 5, y); c.lineTo(x - 5, y); c.fill(); c.fillStyle = shade(col, 0.2); c.fillRect(x - 8, y - h - 1.5, 16, 3); };
  const leaf = (lx: number, ly: number, ang: number, len: number, col: string, wd = 4) => { c.save(); c.translate(lx, ly); c.rotate(ang + sway * 0.02); c.fillStyle = col; c.beginPath(); c.ellipse(0, -len / 2, wd, len / 2, 0, 0, 7); c.fill(); c.restore(); };
  switch (p.style) {
    case 'monstera': pot('#c9a07c'); for (const [a, l] of [[-1.1, 15], [-0.5, 19], [0, 21], [0.5, 18], [1.1, 14]] as [number, number][]) leaf(x, y - 11, a, l, '#5f8a5a', 5); c.strokeStyle = '#4a6f47'; c.lineWidth = 0.8; for (const a of [-0.5, 0, 0.5]) { c.beginPath(); c.moveTo(x, y - 11); c.lineTo(x + Math.sin(a) * 16, y - 11 - Math.cos(a) * 16); c.stroke(); } break;
    case 'tulips': pot('#e3c9b0'); for (const [dx, h, col] of [[-4, 17, '#e48ba0'], [0, 22, '#f2b8c2'], [4, 16, '#e9a177']] as [number, number, string][]) { c.strokeStyle = '#6f9a68'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x + dx, y - 11); c.lineTo(x + dx + sway * 0.3, y - 11 - h); c.stroke(); c.fillStyle = col; c.beginPath(); c.ellipse(x + dx + sway * 0.3, y - 13 - h, 2.8, 3.8, 0, 0, 7); c.fill(); } leaf(x - 3, y - 11, -0.5, 12, '#6f9a68', 2); leaf(x + 3, y - 11, 0.5, 11, '#6f9a68', 2); break;
    case 'olive': pot('#d8c3a5', 12); c.strokeStyle = '#7a5a3e'; c.lineWidth = 1.8; c.beginPath(); c.moveTo(x, y - 12); c.lineTo(x + sway * 0.2, y - 24); c.stroke(); for (let i = 0; i < 9; i++) { const a = i * 0.9; ell(c, x + Math.cos(a) * 8 + sway * 0.3, y - 26 + Math.sin(a * 1.3) * 6, 5, 2.2, i % 2 ? '#8aa17c' : '#a3b890'); } break;
    default: pot('#b9886a'); for (const [a, l] of [[-1.2, 13], [-0.7, 17], [-0.25, 20], [0.25, 19], [0.7, 16], [1.2, 12]] as [number, number][]) leaf(x, y - 11, a, l, '#7aa06f', 3);
  }
}

export function drawLamp(c: CanvasRenderingContext2D, p: WProp, t: number) {
  const x = p.tx * TILE + 16, y = p.ty * TILE + 30;
  c.fillStyle = 'rgba(40,25,15,.2)'; c.beginPath(); c.ellipse(x, y, 9, 3, 0, 0, 7); c.fill();
  if (p.style === 'candle') {
    c.fillStyle = '#c9a56b'; rr(c, x - 6, y - 5, 12, 5, 2); c.fill(); c.fillStyle = '#f6efe0'; rr(c, x - 3, y - 17, 6, 13, 1.5); c.fill();
    const f = 1 + Math.sin(t * 9 + p.tx) * 0.12; c.fillStyle = '#ffd56b'; c.beginPath(); c.ellipse(x, y - 21, 2 * f, 3.4 * f, 0, 0, 7); c.fill(); c.fillStyle = '#fff6c9'; c.beginPath(); c.ellipse(x, y - 20.5, 1, 2, 0, 0, 7); c.fill();
  } else {
    c.fillStyle = '#7a5538'; c.fillRect(x - 5, y - 3, 10, 3); c.fillRect(x - 1, y - 30, 2, 28);
    c.fillStyle = '#f6e3b4'; c.beginPath(); c.moveTo(x - 8, y - 24); c.lineTo(x + 8, y - 24); c.lineTo(x + 5, y - 35); c.lineTo(x - 5, y - 35); c.fill(); c.fillStyle = 'rgba(255,255,255,.4)'; c.fillRect(x - 6, y - 33, 3, 8);
  }
}
export function lampGlows(world: World): { x: number; y: number; r: number }[] {
  const out: { x: number; y: number; r: number }[] = [];
  for (const p of world.props) if (p.kind === 'lamp') out.push({ x: p.tx * TILE + 16, y: p.ty * TILE + (p.style === 'candle' ? 10 : 0) - 2, r: p.style === 'candle' ? 52 : 86 });
  for (const p of world.props) if (p.kind === 'pedestal') out.push({ x: p.tx * TILE + 16, y: p.ty * TILE + 4, r: 70 });
  return out;
}

export function drawPedestal(c: CanvasRenderingContext2D, p: WProp, t: number) {
  const x = p.tx * TILE + 16, y = p.ty * TILE + 30;
  c.fillStyle = 'rgba(40,25,15,.22)'; c.beginPath(); c.ellipse(x, y, 13, 4, 0, 0, 7); c.fill();
  const g = c.createLinearGradient(x - 11, 0, x + 11, 0); g.addColorStop(0, '#e9e1d4'); g.addColorStop(0.5, '#fbf8f2'); g.addColorStop(1, '#d4cab9'); c.fillStyle = g; rr(c, x - 11, y - 20, 22, 20, 2); c.fill();
  c.fillStyle = '#c9bfae'; c.fillRect(x - 12, y - 22, 24, 3);
  c.fillStyle = '#6b3b3f'; rr(c, x - 5, y - 28, 10, 6, 1.5); c.fill(); c.fillStyle = '#3d1f22'; c.fillRect(x - 5, y - 25.6, 10, 0.9);
  const sp = (Math.sin(t * 3) + 1) / 2; c.strokeStyle = '#f0cf7a'; c.lineWidth = 1.2; c.beginPath(); c.arc(x, y - 31, 2.4, 0, 7); c.stroke(); ell(c, x, y - 34.2, 1.6, 1.6, '#e4f3ff');
  c.save(); c.globalAlpha = 0.25 + sp * 0.25; c.strokeStyle = '#fff'; c.lineWidth = 1; c.beginPath(); c.moveTo(x - 5, y - 36 - sp); c.lineTo(x + 5, y - 36 - sp); c.moveTo(x, y - 41 - sp); c.lineTo(x, y - 31 - sp); c.stroke(); c.restore();
  c.fillStyle = 'rgba(210,235,250,.28)'; rr(c, x - 8, y - 38, 16, 17, 6); c.fill(); c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 0.8; rr(c, x - 8, y - 38, 16, 17, 6); c.stroke();
}
export function drawRecordPlayer(c: CanvasRenderingContext2D, p: WProp, t: number, playing: boolean) {
  const x = p.tx * TILE, y = p.ty * TILE + 30;
  c.fillStyle = 'rgba(40,25,15,.22)'; c.beginPath(); c.ellipse(x + 32, y, 36, 5, 0, 0, 7); c.fill();
  c.fillStyle = '#6f4f33'; c.fillRect(x + 6, y - 14, 4, 14); c.fillRect(x + 54, y - 14, 4, 14);
  c.fillStyle = '#8a6040'; rr(c, x + 2, y - 26, 60, 14, 3); c.fill(); c.fillStyle = '#a77c56'; rr(c, x + 2, y - 26, 60, 4, 3); c.fill();
  ell(c, x + 28, y - 20, 13, 5, '#241d1a'); ell(c, x + 28, y - 20, 4, 1.6, '#d98c9b');
  c.save(); c.translate(x + 28, y - 20); c.scale(1, 0.38); c.rotate(playing ? t * 3 : 0); c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(0, 0); c.lineTo(11, 0); c.stroke(); c.restore();
  c.strokeStyle = '#d4c3a8'; c.lineWidth = 1.3; c.beginPath(); c.moveTo(x + 50, y - 24); c.lineTo(x + 38, playing ? y - 21 : y - 23); c.stroke();
  c.fillStyle = '#d98c9b'; c.fillRect(x + 44, y - 23, 4, 2);
}

// ---------------------------------------------------------------- photos & lighting
export function drawFramePhoto(c: CanvasRenderingContext2D, f: WFrame, w: WRoom, img: HTMLImageElement | null, glow: number) {
  const cx = f.cx, cy = f.cy; const ix = cx - FRAME_W / 2 + 4.5, iy = cy - FRAME_H / 2 + 4.5, iw = FRAME_W - 9, ih = FRAME_H - 9;
  c.save(); c.beginPath(); c.rect(ix, iy, iw, ih); c.clip();
  if (img) {
    const s = Math.min(iw / img.naturalWidth, ih / img.naturalHeight); const dw = img.naturalWidth * s, dh = img.naturalHeight * s;
    c.fillStyle = '#eadfca'; c.fillRect(ix, iy, iw, ih); c.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
  } else { c.fillStyle = '#eadfca'; c.fillRect(ix, iy, iw, ih); c.fillStyle = '#e4b4ac'; c.font = '11px serif'; c.textAlign = 'center'; c.fillText('♡', cx, cy + 4); }
  c.restore();
  if (glow > 0.01) { c.save(); c.globalAlpha = glow; c.strokeStyle = '#ffe9a8'; c.lineWidth = 2; rr(c, cx - FRAME_W / 2 - 2, cy - FRAME_H / 2 - 2, FRAME_W + 4, FRAME_H + 4, 3); c.stroke(); c.globalAlpha = glow * 0.25; c.fillStyle = '#ffe9a8'; rr(c, cx - FRAME_W / 2 - 6, cy - FRAME_H / 2 - 6, FRAME_W + 12, FRAME_H + 12, 6); c.fill(); c.restore(); }
  void w;
}

export function drawLighting(c: CanvasRenderingContext2D, sw: number, sh: number, env: string, glows: { x: number; y: number; r: number }[], camx: number, camy: number, zoom: number, t: number, extraWarm: number) {
  // screen-space: tint + vignette
  c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
  if (env === 'evening') { c.fillStyle = 'rgba(48,36,84,.30)'; c.fillRect(0, 0, sw, sh); }
  else if (env === 'warm') { c.fillStyle = 'rgba(255,214,160,.06)'; c.fillRect(0, 0, sw, sh); }
  if (extraWarm > 0) { c.fillStyle = `rgba(255,190,140,${0.14 * extraWarm})`; c.fillRect(0, 0, sw, sh); }
  const vg = c.createRadialGradient(sw / 2, sh / 2, Math.min(sw, sh) * 0.35, sw / 2, sh / 2, Math.max(sw, sh) * 0.75);
  vg.addColorStop(0, 'rgba(50,30,18,0)'); vg.addColorStop(1, env === 'bright' ? 'rgba(50,30,18,.12)' : 'rgba(50,30,18,.28)'); c.fillStyle = vg; c.fillRect(0, 0, sw, sh);
  c.globalCompositeOperation = 'lighter';
  for (const g of glows) {
    const sx = (g.x - camx) * zoom + sw / 2, sy = (g.y - camy) * zoom + sh / 2, rad = g.r * zoom * (1 + Math.sin(t * 2.3 + g.x) * 0.03);
    if (sx < -rad || sy < -rad || sx > sw + rad || sy > sh + rad) continue;
    const gr = c.createRadialGradient(sx, sy, 0, sx, sy, rad); const a = env === 'evening' ? 0.34 : 0.17;
    gr.addColorStop(0, `rgba(255,214,150,${a})`); gr.addColorStop(1, 'rgba(255,214,150,0)'); c.fillStyle = gr; c.fillRect(sx - rad, sy - rad, rad * 2, rad * 2);
  }
  c.restore();
}
