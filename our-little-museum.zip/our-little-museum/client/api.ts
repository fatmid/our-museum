export class ApiError extends Error { constructor(public status: number, message: string) { super(message); } }
export async function api<T = any>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const res = await fetch(path, {
    method: opts.method || (opts.body !== undefined ? 'POST' : 'GET'),
    headers: { 'x-olm': '1', ...(opts.body !== undefined ? { 'content-type': 'application/json' } : {}) },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin', cache: 'no-store',
  });
  let data: any = null; try { data = await res.json(); } catch { /* empty */ }
  if (!res.ok) throw new ApiError(res.status, data?.error || 'Something went wrong. Please try again.');
  return data as T;
}
export const mediaUrl = (id: number, thumb = false) => `/api/media/${id}${thumb ? '?v=thumb' : ''}`;
export const store = {
  get(k: string, d: string | null = null): string | null { try { return localStorage.getItem('olm.' + k) ?? d; } catch { return d; } },
  set(k: string, v: string) { try { localStorage.setItem('olm.' + k, v); } catch { /* private mode */ } },
};
