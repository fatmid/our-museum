// WebSocket connection with automatic reconnection, clock sync and a tiny pub/sub.
export type NetStatus = 'connecting' | 'open' | 'reconnecting' | 'replaced' | 'signedout';
type Fn = (m: any) => void;

export class Net {
  status: NetStatus = 'connecting';
  offset = 0; rtt = 0; opened = false;
  private ws: WebSocket | null = null; private subs = new Set<Fn>(); private statusSubs = new Set<(s: NetStatus) => void>();
  private tries = 0; private timer: any = null; private pingTimer: any = null; private stopped = false; private everOpen = false;

  constructor() {
    window.addEventListener('online', this.nudge); document.addEventListener('visibilitychange', this.nudge);
  }
  private nudge = () => { if (this.stopped || this.status === 'replaced' || this.status === 'signedout') return; if (!this.ws || this.ws.readyState > 1) { clearTimeout(this.timer); this.connect(); } };
  on(fn: Fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  onStatus(fn: (s: NetStatus) => void) { this.statusSubs.add(fn); return () => this.statusSubs.delete(fn); }
  private setStatus(s: NetStatus) { if (this.status === s) return; this.status = s; this.statusSubs.forEach((f) => f(s)); }
  serverNow() { return Date.now() + this.offset; }
  send(m: any) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(m)); }

  connect() {
    if (this.stopped) return;
    if (this.ws && this.ws.readyState <= 1) return;
    this.setStatus(this.everOpen ? 'reconnecting' : 'connecting');
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/ws`); this.ws = ws; let opened = false;
    ws.onopen = () => { opened = true; this.everOpen = true; this.tries = 0; this.setStatus('open'); this.ping(); clearInterval(this.pingTimer); this.pingTimer = setInterval(() => this.ping(), 4000); };
    ws.onmessage = (e) => {
      let m: any; try { m = JSON.parse(e.data); } catch { return; }
      if (m.t === 'pong') { const now = Date.now(); this.rtt = now - m.c; this.offset = m.s + this.rtt / 2 - now; return; }
      if (m.t === 'welcome') this.offset = m.now - Date.now();
      if (m.t === 'replaced') { this.setStatus('replaced'); }
      if (m.t === 'kicked') { this.setStatus('signedout'); }
      this.subs.forEach((f) => f(m));
    };
    ws.onclose = () => {
      clearInterval(this.pingTimer);
      if (this.ws !== ws) return;
      this.ws = null;
      if (this.stopped || this.status === 'replaced' || this.status === 'signedout') return;
      this.setStatus('reconnecting'); this.tries++;
      const delay = Math.min(8000, 400 * Math.pow(1.6, this.tries - 1)) + Math.random() * 300;
      this.timer = setTimeout(async () => {
        if (!opened && this.tries >= 2) { // upgrade was refused: are we still signed in?
          try { const r = await fetch('/api/gate', { credentials: 'same-origin', cache: 'no-store' }); const g = await r.json(); if (!g.session) { this.setStatus('signedout'); this.subs.forEach((f) => f({ t: 'kicked', reason: 'signedout' })); return; } } catch { /* offline */ }
        }
        this.connect();
      }, delay);
    };
    ws.onerror = () => { /* onclose follows */ };
  }
  /** Used after being replaced by another window. */
  resume() { this.stopped = false; this.status = 'reconnecting'; this.tries = 0; this.connect(); }
  private ping() { this.send({ t: 'ping', c: Date.now() }); }
  close() { this.stopped = true; clearTimeout(this.timer); clearInterval(this.pingTimer); window.removeEventListener('online', this.nudge); document.removeEventListener('visibilitychange', this.nudge); try { this.ws?.close(); } catch { /* */ } this.ws = null; }
}
