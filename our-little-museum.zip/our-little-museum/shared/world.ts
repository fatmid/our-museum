// Museum geometry, shared by server (movement validation) and client (rendering, collision, pathing).
import type { RoomRow, ConnRow, FrameRow, FurnRow, Dir } from './types';

export const TILE = 32;
export const ROOM_W = 16; // tiles, incl. walls
export const ROOM_H = 11;
export const GAP = 3; // corridor length in tiles
export const CELL_W = ROOM_W + GAP;
export const CELL_H = ROOM_H + GAP;
export const FLOOR = { x0: 1, x1: 14, y0: 2, y1: 8 }; // inclusive, room-local tiles
export const NS_DOOR_COLS = [7, 8];
export const EW_DOOR_ROWS = [4, 5, 6];
export const PLAYER_SPEED = 105; // px / s
/** Wall slots for picture frames, in tiles from the room's left edge (benches are 2 tiles wide, centred on the slot). */
export const SLOT_CENTERS = [3, 6, 10, 13];

export interface WorldInput { rooms: RoomRow[]; connections: ConnRow[]; frames: FrameRow[]; furniture: FurnRow[] }

export interface WRoom { row: RoomRow; ox: number; oy: number; px: number; py: number; pw: number; ph: number; doors: { n: boolean; s: boolean; e: boolean; w: boolean } }
export interface WFrame { id: number; roomId: number; wall: 'north' | 'south'; slot: number; cx: number; cy: number; fx: number; fy: number; row: FrameRow; benchKey: string | null }
export interface WSeat { x: number; y: number; dir: Dir }
export interface WBench { key: string; roomId: number; tx: number; ty: number; style: string; facing: 'n' | 's'; seats: WSeat[]; frameId: number | null }
export interface WProp { key: string; kind: 'plant' | 'lamp' | 'pedestal' | 'record'; style: string; roomId: number; tx: number; ty: number; interactive: boolean }
export interface WDoor { a: number; b: number; orient: 'h' | 'v'; x0: number; y0: number; x1: number; y1: number }
export interface World {
  w: number; h: number; solid: Uint8Array;
  rooms: WRoom[]; roomById: Map<number, WRoom>;
  doors: WDoor[]; frames: WFrame[]; benches: WBench[]; props: WProp[];
}

export function buildWorld(inp: WorldInput): World {
  const visible = inp.rooms.filter((r) => !r.hidden);
  const rooms: WRoom[] = visible.map((row) => ({
    row, ox: row.gx * CELL_W, oy: row.gy * CELL_H,
    px: row.gx * CELL_W * TILE, py: row.gy * CELL_H * TILE, pw: ROOM_W * TILE, ph: ROOM_H * TILE,
    doors: { n: false, s: false, e: false, w: false },
  }));
  const roomById = new Map(rooms.map((r) => [r.row.id, r]));
  let maxGx = 0, maxGy = 0;
  for (const r of rooms) { maxGx = Math.max(maxGx, r.row.gx); maxGy = Math.max(maxGy, r.row.gy); }
  const w = Math.max(1, (maxGx + 1) * CELL_W - GAP);
  const h = Math.max(1, (maxGy + 1) * CELL_H - GAP);
  const solid = new Uint8Array(w * h).fill(1);
  const set = (x: number, y: number, v: number) => { if (x >= 0 && y >= 0 && x < w && y < h) solid[y * w + x] = v; };

  for (const r of rooms) for (let y = FLOOR.y0; y <= FLOOR.y1; y++) for (let x = FLOOR.x0; x <= FLOOR.x1; x++) set(r.ox + x, r.oy + y, 0);

  const doors: WDoor[] = [];
  for (const c of inp.connections) {
    if (!c.enabled) continue;
    let a = roomById.get(c.a_room_id), b = roomById.get(c.b_room_id);
    if (!a || !b) continue;
    const dx = b.row.gx - a.row.gx, dy = b.row.gy - a.row.gy;
    if (Math.abs(dx) + Math.abs(dy) !== 1) continue;
    if (dx === -1 || dy === -1) { const t = a; a = b; b = t; }
    if (a.row.gy === b.row.gy) {
      for (const r of EW_DOOR_ROWS) for (let x = a.ox + ROOM_W - 1; x <= b.ox; x++) set(x, a.oy + r, 0);
      a.doors.e = true; b.doors.w = true;
      doors.push({ a: a.row.id, b: b.row.id, orient: 'h', x0: a.ox + ROOM_W - 1, y0: a.oy + EW_DOOR_ROWS[0], x1: b.ox, y1: a.oy + EW_DOOR_ROWS[EW_DOOR_ROWS.length - 1] });
    } else {
      for (const cc of NS_DOOR_COLS) for (let y = a.oy + FLOOR.y1 + 1; y <= b.oy + 1; y++) set(a.ox + cc, y, 0);
      a.doors.s = true; b.doors.n = true;
      doors.push({ a: a.row.id, b: b.row.id, orient: 'v', x0: a.ox + NS_DOOR_COLS[0], y0: a.oy + FLOOR.y1 + 1, x1: a.ox + NS_DOOR_COLS[NS_DOOR_COLS.length - 1], y1: b.oy + 1 });
    }
  }

  const frames: WFrame[] = [], benches: WBench[] = [], props: WProp[] = [];
  for (const r of rooms) {
    for (const wall of ['north', 'south'] as const) {
      const list = inp.frames
        .filter((f) => f.room_id === r.row.id && f.wall === wall && !f.hidden)
        .sort((a, b) => a.sort_order - b.sort_order || a.id - b.id)
        .slice(0, SLOT_CENTERS.length);
      list.forEach((f, i) => {
        const c = SLOT_CENTERS[i];
        const cx = (r.ox + c) * TILE;
        const cy = wall === 'north' ? r.oy * TILE + 30 : (r.oy + 9) * TILE + 34;
        const fy = wall === 'north' ? (r.oy + 2) * TILE + 16 : (r.oy + 8) * TILE + 16;
        frames.push({ id: f.id, roomId: r.row.id, wall, slot: i, cx, cy, fx: cx, fy, row: f, benchKey: f.has_bench ? `f${f.id}` : null });
        if (f.has_bench) {
          const ty = wall === 'north' ? r.oy + 3 : r.oy + 7;
          addBench(benches, solid, w, h, { key: `f${f.id}`, roomId: r.row.id, tx: r.ox + c - 1, ty, style: f.bench_style || 'oak', facing: wall === 'north' ? 'n' : 's', frameId: f.id });
        }
      });
    }
    for (const f of inp.furniture) {
      if (f.room_id !== r.row.id) continue;
      if (f.kind === 'bench') {
        addBench(benches, solid, w, h, { key: `b${f.id}`, roomId: r.row.id, tx: r.ox + f.tx, ty: r.oy + f.ty, style: f.style || 'oak', facing: f.facing === 's' ? 's' : 'n', frameId: null });
      } else {
        props.push({ key: `p${f.id}`, kind: f.kind === 'lamp' ? 'lamp' : 'plant', style: f.style, roomId: r.row.id, tx: r.ox + f.tx, ty: r.oy + f.ty, interactive: false });
        set(r.ox + f.tx, r.oy + f.ty, 1);
      }
    }
    if (r.row.decor === 'promise') {
      props.push({ key: `ped${r.row.id}`, kind: 'pedestal', style: '', roomId: r.row.id, tx: r.ox + 7, ty: r.oy + 5, interactive: true });
      set(r.ox + 7, r.oy + 5, 1);
    }
    if (r.row.decor === 'songs') {
      props.push({ key: `rec${r.row.id}`, kind: 'record', style: '', roomId: r.row.id, tx: r.ox + 12, ty: r.oy + 7, interactive: true });
      set(r.ox + 12, r.oy + 7, 1); set(r.ox + 13, r.oy + 7, 1);
    }
  }
  return { w, h, solid, rooms, roomById, doors, frames, benches, props };
}

function addBench(list: WBench[], solid: Uint8Array, w: number, h: number, b: Omit<WBench, 'seats'>) {
  const seats: WSeat[] = [0, 1].map((i) => ({ x: (b.tx + 0.5 + i) * TILE, y: (b.ty + 0.5) * TILE + 7, dir: b.facing === 'n' ? 'up' : 'down' }));
  list.push({ ...b, seats });
  for (const x of [b.tx, b.tx + 1]) if (x >= 0 && b.ty >= 0 && x < w && b.ty < h) solid[b.ty * w + x] = 1;
}

export function tileSolid(world: World, tx: number, ty: number): boolean {
  if (tx < 0 || ty < 0 || tx >= world.w || ty >= world.h) return true;
  return world.solid[ty * world.w + tx] === 1;
}
/** Feet-box collision test. (x,y) is the character's feet position. */
export function blocked(world: World, x: number, y: number): boolean {
  const l = Math.floor((x - 7) / TILE), r = Math.floor((x + 7) / TILE);
  const t = Math.floor((y - 6) / TILE), b = Math.floor((y + 2) / TILE);
  return tileSolid(world, l, t) || tileSolid(world, r, t) || tileSolid(world, l, b) || tileSolid(world, r, b);
}
export function moveWithCollision(world: World, x: number, y: number, dx: number, dy: number): { x: number; y: number } {
  let nx = x, ny = y;
  if (dx !== 0 && !blocked(world, x + dx, y)) nx = x + dx;
  if (dy !== 0 && !blocked(world, nx, y + dy)) ny = y + dy;
  return { x: nx, y: ny };
}
export function roomAt(world: World, x: number, y: number): WRoom | null {
  for (const r of world.rooms) if (x >= r.px && x < r.px + r.pw && y >= r.py && y < r.py + r.ph) return r;
  return null;
}
export function nearestWalkable(world: World, x: number, y: number): { x: number; y: number } {
  if (!blocked(world, x, y)) return { x, y };
  for (let rad = 4; rad < 400; rad += 4) for (let a = 0; a < 16; a++) {
    const px = x + Math.cos((a / 16) * Math.PI * 2) * rad, py = y + Math.sin((a / 16) * Math.PI * 2) * rad;
    if (!blocked(world, px, py)) return { x: px, y: py };
  }
  const r = world.rooms[0];
  return r ? { x: r.px + 8 * TILE, y: r.py + 5 * TILE } : { x, y };
}
export function spawnFor(world: World, roomId: number | null, tx: number, ty: number): { x: number; y: number } {
  const room = (roomId != null && world.roomById.get(roomId)) || world.rooms.find((r) => r.row.is_entrance) || world.rooms[0];
  if (!room) return { x: 100, y: 100 };
  return nearestWalkable(world, room.px + (tx + 0.5) * TILE, room.py + (ty + 0.5) * TILE);
}
export function dirFromVec(dx: number, dy: number, prev: Dir): Dir {
  if (dx === 0 && dy === 0) return prev;
  if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? 'right' : 'left';
  return dy > 0 ? 'down' : 'up';
}

/** Two standing spots next to each other. */
export function pairSpots(world: World, a: { x: number; y: number }, mode: 'anchor' | 'center', prefer: 1 | -1 = 1, gap = 34): { a: { x: number; y: number; d: Dir }; b: { x: number; y: number; d: Dir } } {
  const ok = (ax: number, ay: number, bx: number, by: number) => !blocked(world, ax, ay) && !blocked(world, bx, by);
  const out = (ax: number, ay: number, bx: number, by: number) => ({
    a: { x: ax, y: ay, d: (bx >= ax ? 'right' : 'left') as Dir }, b: { x: bx, y: by, d: (bx >= ax ? 'left' : 'right') as Dir },
  });
  const make = (s: number, dy: number): [number, number, number, number] =>
    mode === 'anchor' ? [a.x, a.y, a.x + gap * s, a.y + dy] : [a.x - (gap / 2) * s, a.y + dy, a.x + (gap / 2) * s, a.y + dy];
  for (const dy of [0, -24, 24, -40, 40]) for (const s of [prefer, -prefer]) { const c = make(s, dy); if (ok(...c)) return out(...c); }
  const w = nearestWalkable(world, a.x, a.y);
  return out(w.x, w.y, w.x + 1, w.y);
}

/** BFS over tiles then line-of-sight smoothing. Returns pixel waypoints (excluding the start). */
export function findPath(world: World, sx: number, sy: number, tx: number, ty: number): { x: number; y: number }[] | null {
  const W = world.w, H = world.h;
  const s = { x: Math.floor(sx / TILE), y: Math.floor(sy / TILE) };
  let t = { x: Math.floor(tx / TILE), y: Math.floor(ty / TILE) };
  if (tileSolid(world, t.x, t.y)) {
    let best: { x: number; y: number } | null = null, bd = 1e9;
    for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
      if (tileSolid(world, t.x + dx, t.y + dy)) continue;
      const d = dx * dx + dy * dy; if (d < bd) { bd = d; best = { x: t.x + dx, y: t.y + dy }; }
    }
    if (!best) return null; t = best;
  }
  if (s.x < 0 || s.y < 0 || s.x >= W || s.y >= H) return null;
  const prev = new Int32Array(W * H).fill(-2);
  const q: number[] = [s.y * W + s.x]; prev[q[0]] = -1;
  const goal = t.y * W + t.x;
  for (let qi = 0; qi < q.length; qi++) {
    const cur = q[qi]; if (cur === goal) break;
    const cx = cur % W, cy = (cur / W) | 0;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = cx + dx, ny = cy + dy;
      if (tileSolid(world, nx, ny)) continue;
      const ni = ny * W + nx; if (prev[ni] !== -2) continue;
      prev[ni] = cur; q.push(ni);
    }
  }
  if (prev[goal] === -2) return null;
  const tiles: { x: number; y: number }[] = [];
  for (let c = goal; c !== -1; c = prev[c]) tiles.push({ x: (c % W) * TILE + TILE / 2, y: ((c / W) | 0) * TILE + TILE / 2 + 2 });
  tiles.reverse();
  const los = (a: { x: number; y: number }, b: { x: number; y: number }) => {
    const n = Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 4);
    for (let i = 1; i <= n; i++) if (blocked(world, a.x + ((b.x - a.x) * i) / n, a.y + ((b.y - a.y) * i) / n)) return false;
    return true;
  };
  const out: { x: number; y: number }[] = [];
  let cur = { x: sx, y: sy }, i = 0;
  while (i < tiles.length) {
    let j = tiles.length - 1;
    while (j > i && !los(cur, tiles[j])) j--;
    out.push(tiles[j]); cur = tiles[j]; i = j + 1;
  }
  return out;
}
export const dist = (ax: number, ay: number, bx: number, by: number) => Math.hypot(ax - bx, ay - by);
