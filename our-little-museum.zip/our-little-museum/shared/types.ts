// Types and constants shared by the server and the browser client.
export type Slot = 'fatmid' | 'fatima';
export const SLOTS: Slot[] = ['fatmid', 'fatima'];
export const otherSlot = (s: Slot): Slot => (s === 'fatmid' ? 'fatima' : 'fatmid');
export const isSlot = (s: unknown): s is Slot => s === 'fatmid' || s === 'fatima';

export type Dir = 'down' | 'up' | 'left' | 'right';
export const DIRS: Dir[] = ['down', 'up', 'left', 'right'];

export type Anim =
  | 'idle' | 'sit' | 'dance1' | 'dance2' | 'dance3' | 'wave' | 'heart' | 'kiss'
  | 'shy' | 'jump' | 'spin' | 'bow' | 'cheer' | 'kneel' | 'hug' | 'photo';

export const FREE_ACTS: Anim[] = ['dance1', 'dance2', 'dance3', 'wave', 'heart', 'kiss', 'shy', 'jump', 'spin', 'bow'];
/** Duration in ms of one-shot animations. 0 = loops until cancelled. */
export const ACT_MS: Record<string, number> = {
  dance1: 0, dance2: 0, dance3: 0, wave: 1800, heart: 2400, kiss: 2000, shy: 2600, jump: 1000, spin: 1100, bow: 1400,
  cheer: 0, kneel: 0, hug: 0, photo: 0, sit: 0, idle: 0,
};

export interface Look { hair: string; hairColor: string; skin: string; outfit: string; top: string; bottom: string; accent: string }
export const HAIR_STYLES = ['short', 'messy', 'side', 'long', 'bun', 'ponytail', 'bob', 'scarf'] as const;
export const OUTFITS = ['tee', 'hoodie', 'shirt', 'sweater', 'dress', 'kurta', 'overalls', 'cardigan'] as const;
export const HAIR_COLORS = ['#2b1d17', '#4a3022', '#7a4a2a', '#b07a45', '#d9b25f', '#8c8c92', '#7b2d3b', '#24344d'];
export const SKIN_TONES = ['#f6d5b8', '#efc29b', '#dba87b', '#c38b5e', '#a46d44', '#7b4d30'];
export const OUTFIT_COLORS = ['#8fa8c8', '#7a96a8', '#d98c9b', '#e9b7b0', '#b9886a', '#8aa17c', '#c9b27c', '#6e5a7a', '#f1ece2', '#3f4a5c', '#a14a52', '#e3c27b'];

export const DEFAULT_LOOKS: Record<Slot, Look> = {
  fatmid: { hair: 'messy', hairColor: '#2b1d17', skin: '#efc29b', outfit: 'sweater', top: '#7a96a8', bottom: '#3f4a5c', accent: '#f1ece2' },
  fatima: { hair: 'long', hairColor: '#3a2419', skin: '#efc29b', outfit: 'dress', top: '#e9b7b0', bottom: '#e9b7b0', accent: '#f1ece2' },
};

export const ROOM_DECORS = ['none', 'entrance', 'rug', 'bunting', 'window', 'songs', 'promise'] as const;
export type RoomDecor = (typeof ROOM_DECORS)[number];
export const FLOOR_PATTERNS = ['plain', 'checker', 'planks', 'tiles'] as const;
export const BENCH_STYLES = ['oak', 'walnut', 'cushion', 'white'] as const;
export const PLANT_STYLES = ['fern', 'monstera', 'tulips', 'olive'] as const;
export const LAMP_STYLES = ['floor', 'candle'] as const;

export interface RoomRow {
  id: number; name: string; description: string; sort_order: number; gx: number; gy: number;
  wall_color: string; floor_color: string; floor_pattern: string; decor: string;
  music_track_id: number | null; hidden: number; is_entrance: number;
}
export interface ConnRow { id: number; a_room_id: number; b_room_id: number; enabled: number }
export interface FrameRow {
  id: number; room_id: number | null; wall: 'north' | 'south'; sort_order: number;
  title: string; caption: string; date: string; memory: string;
  photo_id: number | null; audio_id: number | null; has_bench: number; bench_style: string; hidden: number;
}
export interface FurnRow { id: number; room_id: number; kind: 'bench' | 'plant' | 'lamp'; style: string; tx: number; ty: number; facing: 'n' | 's' }
export interface TrackRow { id: number; title: string }
export interface MessageRow { id: number; text: string; room_id: number | null; sender: string; enabled: number }
export interface TimelineRow {
  id: number; date: string; title: string; caption: string; story: string;
  photo_id: number | null; audio_id: number | null; hidden: number; sort_order: number;
}
export interface NoteRow { id: number; from_slot: Slot; to_slot: Slot; text: string; created_at: number; read_at: number | null }

export interface Features {
  sharedViewing: boolean; autoJoinView: boolean; proposal: boolean; hugs: boolean; handHolding: boolean;
  danceTogether: boolean; photoMoment: boolean; timeline: boolean; notes: boolean; sharedMusic: boolean;
  randomMessages: boolean; minimap: boolean;
}
export const DEFAULT_FEATURES: Features = {
  sharedViewing: true, autoJoinView: false, proposal: true, hugs: true, handHolding: true,
  danceTogether: true, photoMoment: true, timeline: true, notes: true, sharedMusic: true,
  randomMessages: true, minimap: true,
};

export interface PublicSettings {
  title: string; quote: string; subtitle: string; welcome_fatmid: string; welcome_fatima: string;
  proposal_line1: string; proposal_line2: string; proposal_yes: string; proposal_hug: string; proposal_later: string;
  proposal_yes_reply: string; proposal_hug_reply: string; proposal_later_reply: string;
  features: Features; notes_visibility: 'recipient' | 'both'; show_sender: boolean;
  environment: 'warm' | 'evening' | 'bright'; welcome_style: 'ivory' | 'blush' | 'night';
  default_volume: number; proposal_track_id: number | null;
}
export interface PlayerInfo { slot: Slot; name: string; look: Look; spawn_room_id: number | null; spawn_tx: number; spawn_ty: number }

export interface MuseumBundle {
  version: number; you: Slot; settings: PublicSettings; players: Record<Slot, PlayerInfo>;
  rooms: RoomRow[]; connections: ConnRow[]; frames: FrameRow[]; furniture: FurnRow[]; tracks: TrackRow[];
  messages: MessageRow[]; timeline: TimelineRow[]; last: { x: number; y: number } | null;
}

export type IxKind = 'hug' | 'hands' | 'dance' | 'photo' | 'propose';
export interface PeerState {
  slot: Slot; online: boolean; x: number; y: number; d: Dir; mv: 0 | 1; anim: Anim; animAt: number;
  seat: string | null; room: number | null; viewing: number | null;
}
export interface IxState { id: string; kind: IxKind; from: Slot; to: Slot; stage: string; data?: any; spots?: Record<Slot, { x: number; y: number; d: Dir }> }
export interface MusicState { shared: boolean; track: number | null; playing: boolean; pos: number; at: number; loop: boolean; by: Slot | null }
export const MAX_NOTE_LEN = 280;
