# Museum content

There is no admin website. Everything in the museum comes from this folder.

```
content/
  content.json   describes the photos, songs, timeline, messages and text
  photos/        drop photos here (JPG, PNG, WebP, HEIC ...)
  songs/         drop songs here (MP3, M4A, OGG, WAV, FLAC ...)
```

While the server is running it notices changes within about 10 seconds, re-imports, and both players' museums update
without a restart. If `content.json` has a typo, the museum keeps its previous content and the server log says what is wrong.
Check without changing anything: `node dist/cli.js check`.

Photos are resized and re-saved on import, which strips EXIF data such as GPS location. Your originals stay in this folder,
so keep this folder (and any git repository that contains it) **private**.

## Rooms

Rooms are numbered in walking order: 1 The Beginning, 2 Our First Memories, 3 The Little Things, 4 Our Favourite Days,
5 Our Songs, 6 The Quiet Corner, 7 The Promise Room. Use the number or the exact room name.
Each wall holds 4 frames, so a room holds 8. A full wall overflows onto the other wall; a full room skips the photo with a warning.

## content.json

Every section is optional.

```json
{
  "settings": { "welcome_fatima": "Welcome home, Fatima ♡", "features": { "autoJoinView": false } },
  "players":  { "fatima": { "name": "Fatima Athar", "look": { "hair": "long", "outfit": "dress" } } },
  "rooms":    { "1": { "song": "Our Song" }, "2": { "description": "Where it all began." } },
  "songs":    [ { "file": "our_song.mp3", "title": "Our Song" } ],
  "photos": [
    {
      "file": "first-day.jpg",
      "title": "The first day",
      "caption": "One short line under the frame",
      "date": "2024-02-14",
      "memory": "An optional longer story, shown when the photo is opened.",
      "room": 2,
      "wall": "north",
      "bench": true,
      "benchStyle": "oak",
      "song": "Our Song"
    }
  ],
  "timeline": [ { "date": "2024-02-14", "title": "Hello", "caption": "…", "story": "…", "photo": "first-day.jpg", "song": "Our Song" } ],
  "messages": { "add": ["A new note.", { "text": "A note for one room.", "room": 6 }], "keepDefaults": true }
}
```

- **photos**: only `file` is required. `room` defaults to room 2. `wall` is `north` or `south`. `bench` puts a bench in front of the frame (`benchStyle`: oak, walnut, cushion, white). `hidden: true` keeps an entry without showing it. Frames appear in the order listed.
- **songs**: every file in `songs/` appears in the music player automatically; its title is the file name with underscores turned into spaces. Add a `songs` entry only to choose a nicer title.
- **song** (on a photo, a room, a timeline entry, or `settings.proposal_song`) is a title or file name from `songs/`.
- **timeline** is shown in the order listed. Dates are shown as written.
- **messages**: about 110 notes are built in. `add` appends yours; `"keepDefaults": false` turns the built-in ones off.
- **settings** keys: `title`, `quote`, `subtitle`, `welcome_fatmid`, `welcome_fatima`, `proposal_line1`, `proposal_line2`, `proposal_yes`, `proposal_hug`, `proposal_later`, their `*_reply` versions, `notes_visibility` (`recipient` or `both`), `show_sender`, `environment` (`warm`, `evening`, `bright`), `welcome_style` (`ivory`, `blush`, `night`), `default_volume` (0 to 1), and `features` switches (`sharedViewing`, `autoJoinView`, `proposal`, `hugs`, `handHolding`, `danceTogether`, `photoMoment`, `timeline`, `notes`, `sharedMusic`, `randomMessages`, `minimap`).
