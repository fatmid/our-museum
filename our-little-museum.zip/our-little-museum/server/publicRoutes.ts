import { get as httpGet, post, patch, json, readJson, HttpError, send } from './http.ts';
import { all, get, run } from './db.ts';
import { createSession, setSessionCookie, clearCookie, requirePlayer, PLAYER_COOKIE, playerFromReq } from './auth.ts';
import { parseInviteToken, rateLimit, cleanText, sha256, parseCookies } from './security.ts';
import { buildBundle, loadSettings, loadPlayers, bumpVersion } from './bundle.ts';
import { serveMedia } from './media.ts';
import { HAIR_STYLES, OUTFITS, MAX_NOTE_LEN, otherSlot } from '../shared/types.ts';
import type { Slot, Look } from '../shared/types.ts';
import { notifyMuseumChanged, pushNote } from './realtime.ts';

export function checkInvite(token: unknown) {
  const id = parseInviteToken(token);
  if (!id) return null;
  const inv = get<any>('SELECT * FROM invitations WHERE id = ?', id);
  if (!inv || inv.revoked_at) return null;
  if (inv.expires_at && inv.expires_at < Date.now()) return null;
  if (inv.max_uses && inv.uses >= inv.max_uses) return null;
  return inv;
}
const welcomeFor = (slot: Slot) => { const s = loadSettings(); return slot === 'fatima' ? s.welcome_fatima : s.welcome_fatmid; };

export function registerPublicRoutes() {
  httpGet('/robots.txt', (c) => send(c.res, 200, 'User-agent: *\nDisallow: /\n', { 'content-type': 'text/plain' }));

  // Public gate info: generic text only, nothing private.
  httpGet('/api/gate', (c) => {
    const s = loadSettings(); const p = playerFromReq(c.req); const names = loadPlayers();
    json(c.res, 200, { title: s.title, quote: s.quote, subtitle: s.subtitle, welcome_style: s.welcome_style,
      session: p ? { slot: p.slot, name: names[p.slot]?.name, welcome: welcomeFor(p.slot) } : null });
  });
  httpGet('/api/invite/peek', (c) => {
    if (!rateLimit('peek:' + c.ip, 30, 60_000)) throw new HttpError(429, 'Too many requests');
    const inv = checkInvite(c.url.searchParams.get('token'));
    if (!inv) return json(c.res, 200, { valid: false });
    json(c.res, 200, { valid: true, name: loadPlayers()[inv.player_slot as Slot]?.name, welcome: welcomeFor(inv.player_slot) });
  });
  post('/api/invite/redeem', async (c) => {
    if (!rateLimit('redeem:' + c.ip, 15, 10 * 60_000)) throw new HttpError(429, 'Too many attempts. Please wait a few minutes.');
    const body = await readJson(c);
    const inv = checkInvite(body.token);
    if (!inv) throw new HttpError(403, 'This invitation is not valid any more. Please ask for a new one.');
    const old = parseCookies(c.req.headers.cookie)[PLAYER_COOKIE];
    if (old) run('DELETE FROM sessions WHERE token_hash = ?', sha256(old));
    const { token, maxAge } = createSession({ slot: inv.player_slot, invitationId: inv.id, ua: String(c.req.headers['user-agent'] || '') });
    run('UPDATE invitations SET uses = uses + 1, last_used_at = ? WHERE id = ?', Date.now(), inv.id);
    setSessionCookie(c, PLAYER_COOKIE, token, maxAge);
    json(c.res, 200, { slot: inv.player_slot, name: loadPlayers()[inv.player_slot as Slot]?.name, welcome: welcomeFor(inv.player_slot) });
  });
  post('/api/logout', (c) => {
    const tok = parseCookies(c.req.headers.cookie)[PLAYER_COOKIE];
    if (tok) run('DELETE FROM sessions WHERE token_hash = ?', sha256(tok));
    clearCookie(c, PLAYER_COOKIE);
    json(c.res, 200, { ok: true });
  });
  httpGet('/api/museum', (c) => json(c.res, 200, buildBundle(requirePlayer(c).slot)));
  httpGet('/api/media/:id', (c) => {
    requirePlayer(c);
    const id = Number(c.params.id);
    if (!Number.isInteger(id)) throw new HttpError(404, 'Not found');
    serveMedia(c.req, c.res, id, c.url.searchParams.get('v') || 'full');
  });

  post('/api/notes', async (c) => {
    const p = requirePlayer(c);
    if (!loadSettings().features.notes) throw new HttpError(403, 'Notes are switched off.');
    if (!rateLimit('note:' + p.slot, 12, 60_000)) throw new HttpError(429, 'Slow down a little ♡');
    const text = cleanText((await readJson(c, 8 * 1024)).text, MAX_NOTE_LEN);
    if (!text) throw new HttpError(400, 'Please write something first.');
    const to = otherSlot(p.slot); const now = Date.now();
    const r = run('INSERT INTO notes (from_slot, to_slot, text, created_at) VALUES (?,?,?,?)', p.slot, to, text, now);
    const note = { id: Number(r.lastInsertRowid), from_slot: p.slot, to_slot: to, text, created_at: now, read_at: null };
    pushNote(note); json(c.res, 200, note);
  });
  httpGet('/api/notes', (c) => {
    const p = requirePlayer(c);
    const rows = loadSettings().notes_visibility === 'both'
      ? all('SELECT * FROM notes ORDER BY created_at DESC LIMIT 200')
      : all('SELECT * FROM notes WHERE to_slot = ? ORDER BY created_at DESC LIMIT 200', p.slot);
    json(c.res, 200, rows);
  });
  post('/api/notes/read', (c) => { const p = requirePlayer(c); run('UPDATE notes SET read_at = ? WHERE to_slot = ? AND read_at IS NULL', Date.now(), p.slot); json(c.res, 200, { ok: true }); });

  // A player may change their own look.
  patch('/api/me/look', async (c) => {
    const p = requirePlayer(c); const b = await readJson(c, 4 * 1024);
    const hex = (v: any) => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : null);
    const cur = loadPlayers()[p.slot].look;
    const next: Look = {
      hair: (HAIR_STYLES as readonly string[]).includes(b.hair) ? b.hair : cur.hair,
      outfit: (OUTFITS as readonly string[]).includes(b.outfit) ? b.outfit : cur.outfit,
      hairColor: hex(b.hairColor) || cur.hairColor, skin: hex(b.skin) || cur.skin,
      top: hex(b.top) || cur.top, bottom: hex(b.bottom) || cur.bottom, accent: hex(b.accent) || cur.accent,
    };
    run('UPDATE players SET look = ? WHERE slot = ?', JSON.stringify(next), p.slot);
    bumpVersion(); notifyMuseumChanged();
    json(c.res, 200, next);
  });
}
