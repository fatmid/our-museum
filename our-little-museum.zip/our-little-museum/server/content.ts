// Imports photos, songs and text from the content/ folder (see content/README.md). This replaces an admin panel:
// edit content/content.json, drop files in content/photos and content/songs, and the museum updates itself.
import fs from 'node:fs';
import path from 'node:path';
import { CONTENT_DIR } from './config.ts';
import { all, get, run, tx, getSetting, setSetting } from './db.ts';
import { sha256, cleanText } from './security.ts';
import { savePhoto, saveAudio, deleteMediaFiles, sniffAudio } from './media.ts';
import { DEFAULT_SETTINGS } from './seed.ts';
import { HAIR_STYLES, OUTFITS, BENCH_STYLES, DEFAULT_FEATURES } from '../shared/types.ts';
import { SLOT_CENTERS } from '../shared/world.ts';

const PHOTO_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.heic', '.heif', '.avif', '.tif', '.tiff']);
const AUDIO_EXT = new Set(['.mp3', '.m4a', '.aac', '.ogg', '.oga', '.wav', '.flac']);

function listFiles(dir: string, base = dir, out: string[] = []): string[] {
  let ents: fs.Dirent[] = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of ents) {
    if (e.name.startsWith('.')) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) listFiles(p, base, out); else out.push(path.relative(base, p));
  }
  return out;
}
/** Cheap fingerprint of the content folder, used to notice edits while the server is running. */
export function contentSignature(): string {
  const parts: string[] = [];
  for (const rel of listFiles(CONTENT_DIR).sort()) {
    try { const st = fs.statSync(path.join(CONTENT_DIR, rel)); parts.push(`${rel}:${st.size}:${Math.floor(st.mtimeMs)}`); } catch { /* vanished */ }
  }
  return sha256(parts.join('|'));
}

function resolveFile(ref: unknown, folders: string[]): string | null {
  if (typeof ref !== 'string' || !ref.trim()) return null;
  for (const f of ['', ...folders]) {
    const full = path.resolve(CONTENT_DIR, f, ref.trim());
    if (full !== CONTENT_DIR && !full.startsWith(CONTENT_DIR + path.sep)) continue; // never leave content/
    try { if (fs.statSync(full).isFile()) return full; } catch { /* try next */ }
  }
  return null;
}
const prettyName = (file: string) => path.basename(file, path.extname(file)).replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
const hex = (v: any) => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : null);

let busy = false;
export async function syncContent(): Promise<{ ok: boolean; warnings: string[]; summary: string }> {
  if (busy) return { ok: false, warnings: [], summary: 'sync already running' };
  busy = true;
  const warnings: string[] = [];
  const warn = (m: string) => { warnings.push(m); console.warn('[content] ' + m); };
  try {
    const mp = path.join(CONTENT_DIR, 'content.json');
    let manifest: any = {};
    if (fs.existsSync(mp)) {
      try { manifest = JSON.parse(fs.readFileSync(mp, 'utf8')); }
      catch (e: any) { warn(`content.json is not valid JSON (${e.message}). Keeping the museum as it was.`); return { ok: false, warnings, summary: 'invalid content.json' }; }
    }
    if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) manifest = {};

    // ----- 1. import media (photos + songs), skipping files that were already imported unchanged -----
    const existing = new Map<string, { id: number; kind: string }>();
    for (const m of all<any>('SELECT id, kind, src_hash FROM media WHERE src_hash IS NOT NULL')) existing.set(m.src_hash, { id: m.id, kind: m.kind });
    const used = new Set<string>();
    const photoIds = new Map<string, number>(); // absolute path -> media id
    const songIds = new Map<string, number>();
    const songTitles = new Map<string, string>(); // lower-case title or basename -> abs path
    const songTitleOf = new Map<string, string>();

    // songs: declared + everything in content/songs
    const declared: { abs: string; title: string }[] = [];
    for (const s of Array.isArray(manifest.songs) ? manifest.songs : []) {
      const abs = resolveFile(typeof s === 'string' ? s : s?.file, ['songs']);
      if (!abs) { warn(`song not found: ${typeof s === 'string' ? s : s?.file}`); continue; }
      declared.push({ abs, title: cleanText(typeof s === 'object' && s?.title ? s.title : prettyName(abs), 120) });
    }
    for (const rel of listFiles(path.join(CONTENT_DIR, 'songs'))) {
      const abs = path.join(CONTENT_DIR, 'songs', rel);
      if (AUDIO_EXT.has(path.extname(abs).toLowerCase()) && !declared.find((d) => d.abs === abs)) declared.push({ abs, title: cleanText(prettyName(abs), 120) });
    }
    for (const d of declared) {
      songTitleOf.set(d.abs, d.title);
      songTitles.set(d.title.toLowerCase(), d.abs); songTitles.set(path.basename(d.abs).toLowerCase(), d.abs);
    }
    const songRef = (ref: unknown): string | null => {
      if (typeof ref !== 'string' || !ref.trim()) return null;
      const byName = songTitles.get(ref.trim().toLowerCase()); if (byName) return byName;
      const abs = resolveFile(ref, ['songs']);
      if (abs) { if (!songTitleOf.has(abs)) { songTitleOf.set(abs, cleanText(prettyName(abs), 120)); declared.push({ abs, title: songTitleOf.get(abs)! }); } return abs; }
      warn(`song not found: ${ref}`); return null;
    };
    const photoRef = (ref: unknown): string | null => {
      if (ref == null || ref === '') return null;
      const abs = resolveFile(ref, ['photos']);
      if (!abs) { warn(`photo not found: ${ref}`); return null; }
      return abs;
    };

    const photos: any[] = Array.isArray(manifest.photos) ? manifest.photos : [];
    const timeline: any[] = Array.isArray(manifest.timeline) ? manifest.timeline : [];
    const roomsCfg = manifest.rooms && typeof manifest.rooms === 'object' ? manifest.rooms : {};
    const settingsCfg = manifest.settings && typeof manifest.settings === 'object' ? manifest.settings : {};

    const photoAbs = new Map<any, string | null>(); // manifest entry -> abs path
    for (const p of photos) photoAbs.set(p, photoRef(p?.file));
    for (const t of timeline) photoAbs.set(t, photoRef(t?.photo));
    const songAbs = new Map<any, string | null>();
    for (const p of photos) songAbs.set(p, songRef(p?.song));
    for (const t of timeline) songAbs.set(t, songRef(t?.song));
    for (const [k, v] of Object.entries<any>(roomsCfg)) songAbs.set(v, songRef(v?.song));
    const proposalSong = songRef(settingsCfg.proposal_song);

    const importOne = async (abs: string, kind: 'photo' | 'audio', title: string) => {
      const buf = fs.readFileSync(abs);
      const h = sha256(buf) + ':' + kind; used.add(h);
      const found = existing.get(h);
      if (found) { if (kind === 'audio') run('UPDATE media SET title = ? WHERE id = ?', title, found.id); return found.id; }
      try {
        const id = kind === 'photo' ? await savePhoto(buf, title, h) : saveAudio(buf, title, h);
        existing.set(h, { id, kind }); return id;
      } catch (e: any) { warn(`${path.relative(CONTENT_DIR, abs)}: ${e.message}`); return null; }
    };
    for (const abs of new Set([...photoAbs.values()].filter(Boolean) as string[])) {
      if (!PHOTO_EXT.has(path.extname(abs).toLowerCase())) warn(`${path.basename(abs)} does not look like a photo, trying anyway`);
      const id = await importOne(abs, 'photo', cleanText(prettyName(abs), 120)); if (id != null) photoIds.set(abs, id);
    }
    for (const d of declared) { const id = await importOne(d.abs, 'audio', d.title); if (id != null) songIds.set(d.abs, id); }
    const sid = (abs: string | null) => (abs ? songIds.get(abs) ?? null : null);
    const pid = (abs: string | null) => (abs ? photoIds.get(abs) ?? null : null);

    // ----- 2. apply everything in one transaction -----
    const rooms = all<any>('SELECT * FROM rooms ORDER BY sort_order, id');
    const findRoom = (ref: any) => {
      if (typeof ref === 'number' || (typeof ref === 'string' && /^\d+$/.test(ref.trim()))) return rooms[Number(ref) - 1] || null;
      if (typeof ref === 'string') return rooms.find((r) => r.name.toLowerCase() === ref.trim().toLowerCase()) || null;
      return null;
    };
    let nFrames = 0, nTimeline = 0, nMsgs = 0;
    tx(() => {
      // rooms
      run('UPDATE rooms SET music_track_id = NULL');
      for (const [key, cfg] of Object.entries<any>(roomsCfg)) {
        const r = findRoom(key); if (!r || !cfg || typeof cfg !== 'object') { warn(`rooms: unknown room "${key}"`); continue; }
        if (typeof cfg.name === 'string' && cleanText(cfg.name, 60)) run('UPDATE rooms SET name = ? WHERE id = ?', cleanText(cfg.name, 60), r.id);
        if (typeof cfg.description === 'string') run('UPDATE rooms SET description = ? WHERE id = ?', cleanText(cfg.description, 300), r.id);
        const s = sid(songAbs.get(cfg) ?? null); if (s != null) run('UPDATE rooms SET music_track_id = ? WHERE id = ?', s, r.id);
        if (hex(cfg.wall_color)) run('UPDATE rooms SET wall_color = ? WHERE id = ?', hex(cfg.wall_color), r.id);
        if (hex(cfg.floor_color)) run('UPDATE rooms SET floor_color = ? WHERE id = ?', hex(cfg.floor_color), r.id);
      }
      // settings
      const enums: Record<string, string[]> = { notes_visibility: ['recipient', 'both'], environment: ['warm', 'evening', 'bright'], welcome_style: ['ivory', 'blush', 'night'] };
      for (const [k, def] of Object.entries<any>(DEFAULT_SETTINGS)) {
        if (!(k in settingsCfg) || k === 'proposal_track_id') continue;
        const v = settingsCfg[k];
        if (k === 'features') { if (v && typeof v === 'object') { const cur = getSetting<any>('features', DEFAULT_FEATURES); const nf = { ...DEFAULT_FEATURES, ...cur }; for (const fk of Object.keys(DEFAULT_FEATURES)) if (typeof v[fk] === 'boolean') (nf as any)[fk] = v[fk]; setSetting('features', nf); } continue; }
        if (enums[k]) { if (enums[k].includes(v)) setSetting(k, v); else warn(`settings.${k}: choose one of ${enums[k].join(', ')}`); continue; }
        if (typeof def === 'string') setSetting(k, cleanText(v, 400));
        else if (typeof def === 'boolean') setSetting(k, !!v);
        else if (k === 'default_volume') { const n = Number(v); if (n >= 0 && n <= 1) setSetting(k, n); }
      }
      setSetting('proposal_track_id', sid(proposalSong));
      // players
      const players = manifest.players && typeof manifest.players === 'object' ? manifest.players : {};
      const phash = sha256(JSON.stringify(players));
      const lookChanged = getSetting('content_players_hash', '') !== phash;
      for (const slot of ['fatmid', 'fatima'] as const) {
        const p = players[slot]; if (!p || typeof p !== 'object') continue;
        if (typeof p.name === 'string' && cleanText(p.name, 40)) run('UPDATE players SET display_name = ? WHERE slot = ?', cleanText(p.name, 40), slot);
        if (lookChanged && p.look && typeof p.look === 'object') {
          const cur = JSON.parse(get<any>('SELECT look FROM players WHERE slot = ?', slot)!.look); const l = p.look;
          const next = {
            ...cur,
            hair: (HAIR_STYLES as readonly string[]).includes(l.hair) ? l.hair : cur.hair, outfit: (OUTFITS as readonly string[]).includes(l.outfit) ? l.outfit : cur.outfit,
            hairColor: hex(l.hairColor) || cur.hairColor, skin: hex(l.skin) || cur.skin, top: hex(l.top) || cur.top, bottom: hex(l.bottom) || cur.bottom, accent: hex(l.accent) || cur.accent,
          };
          run('UPDATE players SET look = ? WHERE slot = ?', JSON.stringify(next), slot);
        }
      }
      setSetting('content_players_hash', phash);

      // frames
      run('DELETE FROM frames');
      const counts = new Map<string, number>();
      const defaultRoom = rooms[1] || rooms[0];
      photos.forEach((p, i) => {
        const abs = photoAbs.get(p); const photoId = pid(abs ?? null);
        if (photoId == null) { warn(`photos[${i}]: skipped (no usable photo file)`); return; }
        const room = p.room != null ? findRoom(p.room) : defaultRoom;
        if (!room) { warn(`photos[${i}] "${p.file}": unknown room "${p.room}", skipped`); return; }
        let wall: 'north' | 'south' = p.wall === 'south' ? 'south' : p.wall === 'north' ? 'north' : 'north';
        const other = wall === 'north' ? 'south' : 'north';
        const n = (w: string) => counts.get(`${room.id}:${w}`) || 0;
        if (n(wall) >= SLOT_CENTERS.length) {
          if (n(other) >= SLOT_CENTERS.length) { warn(`"${room.name}" is full (${SLOT_CENTERS.length * 2} frames). ${p.file} was skipped. Put it in another room.`); return; }
          if (p.wall) warn(`photos[${i}]: the ${wall} wall of "${room.name}" is full, using the ${other} wall`);
          wall = other;
        }
        counts.set(`${room.id}:${wall}`, n(wall) + 1);
        const bench = !!p.bench;
        const style = (BENCH_STYLES as readonly string[]).includes(p.benchStyle) ? p.benchStyle : 'oak';
        run('INSERT INTO frames (room_id, wall, sort_order, title, caption, date, memory, photo_id, audio_id, has_bench, bench_style, hidden, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
          room.id, wall, i, cleanText(p.title, 80), cleanText(p.caption, 200), cleanText(p.date, 40), cleanText(p.memory, 2000), photoId, sid(songAbs.get(p) ?? null), bench ? 1 : 0, style, p.hidden ? 1 : 0, Date.now());
        nFrames++;
      });
      // timeline
      run('DELETE FROM timeline');
      timeline.forEach((t, i) => {
        if (!t || typeof t !== 'object') return;
        run('INSERT INTO timeline (date, title, caption, story, photo_id, audio_id, hidden, sort_order) VALUES (?,?,?,?,?,?,?,?)',
          cleanText(t.date, 40), cleanText(t.title, 100), cleanText(t.caption, 240), cleanText(t.story, 3000), pid(photoAbs.get(t) ?? null), sid(songAbs.get(t) ?? null), t.hidden ? 1 : 0, i);
        nTimeline++;
      });
      // messages
      run('DELETE FROM messages WHERE managed = 1');
      const mcfg = manifest.messages && typeof manifest.messages === 'object' && !Array.isArray(manifest.messages) ? manifest.messages : { add: manifest.messages };
      run('UPDATE messages SET enabled = ? WHERE managed = 0', mcfg.keepDefaults === false ? 0 : 1);
      for (const m of Array.isArray(mcfg.add) ? mcfg.add : []) {
        const text = cleanText(typeof m === 'string' ? m : m?.text, 240); if (!text) continue;
        const room = typeof m === 'object' && m?.room != null ? findRoom(m.room) : null;
        run('INSERT INTO messages (text, room_id, sender, enabled, managed) VALUES (?,?,?,1,1)', text, room?.id ?? null, cleanText(typeof m === 'object' ? m?.from ?? 'Fatmid' : 'Fatmid', 40), );
        nMsgs++;
      }
      // forget media that is no longer in content/
      for (const m of all<any>('SELECT id, src_hash FROM media WHERE src_hash IS NOT NULL')) {
        if (!used.has(m.src_hash)) { deleteMediaFiles(m.id); run('DELETE FROM media WHERE id = ?', m.id); }
      }
    });
    const summary = `${nFrames} photo frame(s), ${songIds.size} song(s), ${nTimeline} timeline entr${nTimeline === 1 ? 'y' : 'ies'}, ${nMsgs} extra message(s)`;
    console.log(`[content] imported ${summary}${warnings.length ? `, ${warnings.length} warning(s)` : ''}`);
    return { ok: true, warnings, summary };
  } finally { busy = false; }
}

/** Polls the content folder; when something changes it re-imports and calls onChange (which tells connected players). */
export function watchContent(onChange: () => void) {
  let last = contentSignature();
  setInterval(async () => {
    const sig = contentSignature(); if (sig === last) return;
    await new Promise((r) => setTimeout(r, 1500)); // let a copy in progress finish
    const settled = contentSignature(); if (settled !== sig) return; // still changing; next tick
    last = sig;
    const r = await syncContent(); if (r.ok) onChange();
  }, 5000).unref();
}
void sniffAudio;
