import { DatabaseSync, type StatementSync } from 'node:sqlite';
import path from 'node:path';
import { DATA_DIR } from './config.ts';
import init001 from './migrations/001_init.sql';

export const db = new DatabaseSync(path.join(DATA_DIR, 'museum.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA synchronous = NORMAL;');

const MIGRATIONS: { id: number; sql: string }[] = [{ id: 1, sql: init001 }];
export function migrate() {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (id INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
  const done = new Set((db.prepare('SELECT id FROM schema_migrations').all() as any[]).map((r) => r.id));
  for (const m of MIGRATIONS) {
    if (done.has(m.id)) continue;
    db.exec('BEGIN');
    try {
      db.exec(m.sql);
      db.prepare('INSERT INTO schema_migrations (id, applied_at) VALUES (?, ?)').run(m.id, Date.now());
      db.exec('COMMIT'); console.log(`[db] applied migration ${m.id}`);
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  }
}
const cache = new Map<string, StatementSync>();
const stmt = (sql: string) => { let s = cache.get(sql); if (!s) { s = db.prepare(sql); cache.set(sql, s); } return s; };
export const all = <T = any>(sql: string, ...p: any[]): T[] => stmt(sql).all(...p) as T[];
export const get = <T = any>(sql: string, ...p: any[]): T | undefined => stmt(sql).get(...p) as T | undefined;
export const run = (sql: string, ...p: any[]) => stmt(sql).run(...p);
export function tx<T>(fn: () => T): T {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}
export function getSetting<T>(key: string, fallback: T): T {
  const r = get<{ value: string }>('SELECT value FROM settings WHERE key = ?', key);
  if (!r) return fallback;
  try { return JSON.parse(r.value) as T; } catch { return fallback; }
}
export function setSetting(key: string, value: unknown) {
  run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, JSON.stringify(value));
}
