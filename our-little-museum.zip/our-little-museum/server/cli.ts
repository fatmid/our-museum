// Command-line tool for the person running the museum. No web admin exists on purpose.
//   node dist/cli.js invite fatima         create an invitation link + QR code for Fatima
//   node dist/cli.js invite fatmid         the same for Fatmid
//   node dist/cli.js list                  show invitations
//   node dist/cli.js revoke <id>|all       revoke an invitation (and sign that device out)
//   node dist/cli.js qr <url>              make a QR code for any URL
//   node dist/cli.js check                 validate content/content.json without changing anything
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { PUBLIC_URL, DATA_DIR, CONTENT_DIR } from './config.ts';
import { migrate, all, get, run } from './db.ts';
import { seedIfEmpty } from './seed.ts';
import { makeInviteToken } from './security.ts';
import { makeQr, qrPng, qrSvg, qrTerminal } from './qr.ts';
import { isSlot } from '../shared/types.ts';

migrate(); seedIfEmpty();
const [cmd, ...rest] = process.argv.slice(2);
const flag = (name: string) => { const i = rest.indexOf('--' + name); return i >= 0 ? rest[i + 1] : undefined; };
const outDir = path.join(DATA_DIR, 'invites');

function status(i: any) { return i.revoked_at ? 'revoked' : i.expires_at && i.expires_at < Date.now() ? 'expired' : i.max_uses && i.uses >= i.max_uses ? 'used up' : 'active'; }
const fmt = (t: number | null) => (t ? new Date(t).toISOString().slice(0, 16).replace('T', ' ') : '—');

switch (cmd) {
  case 'invite': {
    const slot = rest[0];
    if (!isSlot(slot)) { console.error('Usage: invite <fatmid|fatima> [--days 14 | --days forever] [--max-uses N] [--label text]'); process.exit(1); }
    const daysArg = flag('days'); const days = daysArg === 'forever' ? null : Number(daysArg ?? 30);
    if (days !== null && !(days > 0 && days <= 3650)) { console.error('--days must be 1-3650 or "forever"'); process.exit(1); }
    const id = crypto.randomBytes(8).toString('hex');
    run('INSERT INTO invitations (id, player_slot, label, created_at, expires_at, max_uses) VALUES (?,?,?,?,?,?)', id, slot, (flag('label') || '').slice(0, 60), Date.now(), days ? Date.now() + days * 86_400_000 : null, flag('max-uses') ? Number(flag('max-uses')) : null);
    const url = `${PUBLIC_URL}/?invite=${makeInviteToken(id)}`;
    const qr = makeQr(url);
    fs.mkdirSync(outDir, { recursive: true });
    const base = path.join(outDir, `invite-${slot}-${id}`);
    fs.writeFileSync(base + '.png', qrPng(qr)); fs.writeFileSync(base + '.svg', qrSvg(qr));
    console.log(`\nInvitation for ${slot} (${days ? `valid ${days} days` : 'never expires'}), id ${id}\n\n${url}\n\n${qrTerminal(qr)}\nQR image saved: ${base}.png  (and .svg)\nDatabase used: ${DATA_DIR}`);
    if (PUBLIC_URL.startsWith('http://localhost')) console.log('\nNote: PUBLIC_URL is not set, so this link only works on this computer. Set PUBLIC_URL to your https address first.');
    console.log('Treat this link like a key: anyone who opens it becomes ' + slot + '. Revoke it with:  revoke ' + id);
    break;
  }
  case 'list': {
    const rows = all<any>('SELECT * FROM invitations ORDER BY created_at DESC');
    if (!rows.length) console.log('No invitations yet. Create one with: invite fatima');
    for (const i of rows) console.log(`${i.id}  ${i.player_slot.padEnd(6)}  ${status(i).padEnd(8)}  created ${fmt(i.created_at)}  expires ${fmt(i.expires_at)}  uses ${i.uses}  last used ${fmt(i.last_used_at)}  ${i.label}`);
    break;
  }
  case 'revoke': {
    const target = rest[0];
    if (!target) { console.error('Usage: revoke <invitation id>|all'); process.exit(1); }
    const rows = target === 'all' ? all<any>('SELECT id FROM invitations WHERE revoked_at IS NULL') : all<any>('SELECT id FROM invitations WHERE id = ?', target);
    if (!rows.length) { console.error('No matching invitation.'); process.exit(1); }
    for (const r of rows) { run('UPDATE invitations SET revoked_at = ? WHERE id = ?', Date.now(), r.id); run('DELETE FROM sessions WHERE invitation_id = ?', r.id); }
    console.log(`Revoked ${rows.length} invitation(s). Devices using them are signed out within about 15 seconds.`);
    break;
  }
  case 'qr': {
    if (!rest[0]) { console.error('Usage: qr <url>'); process.exit(1); }
    let qr; try { qr = makeQr(rest[0]); } catch (e: any) { console.error(e.message); process.exit(1); }
    fs.mkdirSync(outDir, { recursive: true });
    const f = path.join(outDir, 'qr-' + crypto.randomBytes(3).toString('hex') + '.png'); fs.writeFileSync(f, qrPng(qr));
    console.log(qrTerminal(qr) + '\nSaved ' + f); break;
  }
  case 'check': {
    const { syncContent } = await import('./content.ts');
    console.log('Importing content from ' + CONTENT_DIR + ' into ' + DATA_DIR + ' …');
    const r = await syncContent(); console.log(r.ok ? 'OK: ' + r.summary : 'Problem: ' + r.summary);
    process.exit(r.ok ? 0 : 1);
  }
  default:
    console.log('Commands: invite <fatmid|fatima> | list | revoke <id|all> | qr <url> | check');
    void get;
}
