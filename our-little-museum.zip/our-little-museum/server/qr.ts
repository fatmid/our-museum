// Minimal QR code encoder (byte mode, error-correction level M, versions 1-10 => up to 213 bytes). No dependencies.
import zlib from 'node:zlib';

const EXP = new Uint8Array(512), LOG = new Uint8Array(256);
{ let x = 1; for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; } for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]; }
const gmul = (a: number, b: number) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
function rsGen(n: number): number[] {
  let g = [1];
  for (let i = 0; i < n; i++) { const next = new Array(g.length + 1).fill(0); for (let j = 0; j < g.length; j++) { next[j] ^= g[j]; next[j + 1] ^= gmul(g[j], EXP[i]); } g = next; }
  return g;
}
function rsEncode(data: number[], n: number): number[] {
  const g = rsGen(n); const res = new Array(n).fill(0);
  for (const d of data) { const f = d ^ res.shift()!; res.push(0); if (f) for (let i = 0; i < n; i++) res[i] ^= gmul(g[i + 1], f); }
  return res;
}
// level M: [ecc codewords per block, blocks of size1, size1, blocks of size2, size2]
const M_TABLE: Record<number, [number, number, number, number, number]> = {
  1: [10, 1, 16, 0, 0], 2: [16, 1, 28, 0, 0], 3: [26, 1, 44, 0, 0], 4: [18, 2, 32, 0, 0], 5: [24, 2, 43, 0, 0],
  6: [16, 4, 27, 0, 0], 7: [18, 4, 31, 0, 0], 8: [22, 2, 38, 2, 39], 9: [22, 3, 36, 2, 37], 10: [26, 4, 43, 1, 44],
};
const ALIGN: Record<number, number[]> = { 1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50] };

function bch(value: number, poly: number, bits: number): number {
  let v = value << bits; const top = 31 - Math.clz32(poly);
  for (let i = 31 - Math.clz32(v); i >= top; i--) if ((v >> i) & 1) v ^= poly << (i - top);
  return v;
}

export function makeQr(text: string): boolean[][] {
  const bytes = [...Buffer.from(text, 'utf8')];
  let ver = 0;
  for (let v = 1; v <= 10; v++) { const t = M_TABLE[v]; const data = t[1] * t[2] + t[3] * t[4]; const cap = v < 10 ? data - 2 : data - 3; if (bytes.length <= cap) { ver = v; break; } }
  if (!ver) throw new Error('Text is too long for this QR encoder (max 213 bytes).');
  const [ecc, n1, d1, n2, d2] = M_TABLE[ver]; const totalData = n1 * d1 + n2 * d2;
  // bit stream
  const bits: number[] = []; const put = (v: number, n: number) => { for (let i = n - 1; i >= 0; i--) bits.push((v >> i) & 1); };
  put(4, 4); put(bytes.length, ver < 10 ? 8 : 16); for (const b of bytes) put(b, 8);
  put(0, Math.min(4, totalData * 8 - bits.length)); while (bits.length % 8) bits.push(0);
  const cw: number[] = []; for (let i = 0; i < bits.length; i += 8) cw.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let pad = 0xec; cw.length < totalData; pad ^= 0xec ^ 0x11) cw.push(pad);
  // blocks + interleave
  const blocks: { d: number[]; e: number[] }[] = []; let pos = 0;
  for (let i = 0; i < n1 + n2; i++) { const len = i < n1 ? d1 : d2; const d = cw.slice(pos, pos + len); pos += len; blocks.push({ d, e: rsEncode(d, ecc) }); }
  const final: number[] = [];
  for (let i = 0; i < Math.max(d1, d2); i++) for (const b of blocks) if (i < b.d.length) final.push(b.d[i]);
  for (let i = 0; i < ecc; i++) for (const b of blocks) final.push(b.e[i]);
  const dbits: number[] = []; for (const c of final) for (let i = 7; i >= 0; i--) dbits.push((c >> i) & 1);

  const size = 17 + 4 * ver;
  const mod: (0 | 1)[][] = Array.from({ length: size }, () => new Array(size).fill(0));
  const fn: boolean[][] = Array.from({ length: size }, () => new Array(size).fill(false));
  const setF = (x: number, y: number, v: number) => { if (x >= 0 && y >= 0 && x < size && y < size) { mod[y][x] = v ? 1 : 0; fn[y][x] = true; } };
  const finder = (cx: number, cy: number) => { for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)); setF(cx + dx, cy + dy, d !== 4 && d !== 2 ? 1 : 0); } };
  finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
  for (let i = 8; i < size - 8; i++) { setF(i, 6, i % 2 === 0 ? 1 : 0); setF(6, i, i % 2 === 0 ? 1 : 0); }
  const al = ALIGN[ver];
  for (const ay of al) for (const ax of al) {
    if ((ax === 6 && ay === 6) || (ax === 6 && ay === al[al.length - 1]) || (ax === al[al.length - 1] && ay === 6)) continue;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setF(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1 ? 1 : 0);
  }
  setF(8, size - 8, 1); // dark module
  for (let i = 0; i < 9; i++) { if (!fn[8][i]) setF(i, 8, 0); if (!fn[i][8]) setF(8, i, 0); } // reserve format areas
  for (let i = 0; i < 8; i++) { setF(size - 1 - i, 8, 0); setF(8, size - 1 - i, 0); }
  setF(8, size - 8, 1);
  if (ver >= 7) { const vi = (ver << 12) | bch(ver, 0x1f25, 12); for (let i = 0; i < 18; i++) { const bit = (vi >> i) & 1; setF(Math.floor(i / 3), size - 11 + (i % 3), bit); setF(size - 11 + (i % 3), Math.floor(i / 3), bit); } }
  // zigzag data placement
  const place = (): { x: number; y: number }[] => {
    const cells: { x: number; y: number }[] = []; let up = true;
    for (let x = size - 1; x > 0; x -= 2) {
      if (x === 6) x--;
      for (let i = 0; i < size; i++) { const y = up ? size - 1 - i : i; for (const xx of [x, x - 1]) if (!fn[y][xx]) cells.push({ x: xx, y }); }
      up = !up;
    }
    return cells;
  };
  const cells = place();
  const masks = [(x: number, y: number) => (x + y) % 2 === 0, (_x: number, y: number) => y % 2 === 0, (x: number) => x % 3 === 0, (x: number, y: number) => (x + y) % 3 === 0,
    (x: number, y: number) => (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0, (x: number, y: number) => ((x * y) % 2) + ((x * y) % 3) === 0,
    (x: number, y: number) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x: number, y: number) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0];
  const build = (mask: number) => {
    const m = mod.map((r) => r.slice());
    cells.forEach((c, i) => { const bit = dbits[i] ?? 0; m[c.y][c.x] = ((bit ^ (masks[mask](c.x, c.y) ? 1 : 0)) as 0 | 1); });
    const fmt = (((0 << 3) | mask) << 10 | bch((0 << 3) | mask, 0x537, 10)) ^ 0x5412; // level M = 00
    const f = (i: number) => (fmt >> i) & 1;
    for (let i = 0; i <= 5; i++) m[i][8] = f(i) as 0 | 1; m[7][8] = f(6) as 0 | 1; m[8][8] = f(7) as 0 | 1; m[8][7] = f(8) as 0 | 1;
    for (let i = 9; i < 15; i++) m[8][14 - i] = f(i) as 0 | 1;
    for (let i = 0; i < 8; i++) m[8][size - 1 - i] = f(i) as 0 | 1;
    for (let i = 8; i < 15; i++) m[size - 15 + i][8] = f(i) as 0 | 1;
    m[size - 8][8] = 1;
    return m;
  };
  const penalty = (m: (0 | 1)[][]) => {
    let p = 0;
    for (let pass = 0; pass < 2; pass++) for (let a = 0; a < size; a++) {
      let run = 1;
      for (let b = 1; b < size; b++) {
        const cur = pass ? m[b][a] : m[a][b], prev = pass ? m[b - 1][a] : m[a][b - 1];
        if (cur === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1;
      }
    }
    for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
    const pat = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], rev = [...pat].reverse();
    for (let pass = 0; pass < 2; pass++) for (let a = 0; a < size; a++) for (let b = 0; b <= size - 11; b++) {
      let m1 = true, m2 = true;
      for (let k = 0; k < 11; k++) { const v = pass ? m[b + k][a] : m[a][b + k]; if (v !== pat[k]) m1 = false; if (v !== rev[k]) m2 = false; }
      if (m1) p += 40; if (m2) p += 40;
    }
    let dark = 0; for (const r of m) for (const v of r) dark += v;
    p += Math.floor(Math.abs((dark * 100) / (size * size) - 50) / 5) * 10;
    return p;
  };
  let best = build(0), bp = penalty(best);
  for (let k = 1; k < 8; k++) { const m = build(k); const p = penalty(m); if (p < bp) { bp = p; best = m; } }
  return best.map((r) => r.map((v) => v === 1));
}

export function qrSvg(m: boolean[][], px = 8, quiet = 4): string {
  const n = m.length + quiet * 2; let d = '';
  m.forEach((row, y) => { let x = 0; while (x < row.length) { if (row[x]) { let e = x; while (e < row.length && row[e]) e++; d += `M${x + quiet} ${y + quiet}h${e - x}v1h-${e - x}z`; x = e; } else x++; } });
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${n}" width="${n * px}" height="${n * px}" shape-rendering="crispEdges"><rect width="${n}" height="${n}" fill="#fff"/><path d="${d}" fill="#2b1d17"/></svg>`;
}
export function qrPng(m: boolean[][], px = 10, quiet = 4): Buffer {
  const n = (m.length + quiet * 2) * px; const raw = Buffer.alloc((n + 1) * n, 255);
  for (let y = 0; y < n; y++) {
    raw[y * (n + 1)] = 0;
    for (let x = 0; x < n; x++) { const mx = Math.floor(x / px) - quiet, my = Math.floor(y / px) - quiet; raw[y * (n + 1) + 1 + x] = m[my]?.[mx] ? 0x1d : 255; }
  }
  const chunk = (type: string, data: Buffer) => { const b = Buffer.alloc(12 + data.length); b.writeUInt32BE(data.length, 0); b.write(type, 4, 'latin1'); data.copy(b, 8); b.writeUInt32BE(zlib.crc32(b.subarray(4, 8 + data.length)) >>> 0, 8 + data.length); return b; };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(n, 0); ihdr.writeUInt32BE(n, 4); ihdr[8] = 8; ihdr[9] = 0;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
export function qrTerminal(m: boolean[][]): string {
  const q = 2, n = m.length + q * 2; const at = (x: number, y: number) => !!m[y - q]?.[x - q];
  let out = '';
  for (let y = 0; y < n; y += 2) { for (let x = 0; x < n; x++) { const t = at(x, y), b = at(x, y + 1); out += t && b ? '█' : t ? '▀' : b ? '▄' : ' '; } out += '\n'; }
  return out;
}
