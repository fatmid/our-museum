import { get, run, tx, setSetting, getSetting } from './db.ts';
import { DEFAULT_FEATURES, DEFAULT_LOOKS } from '../shared/types.ts';
import type { PublicSettings } from '../shared/types.ts';
import { SEED_MESSAGES } from './messages-seed.ts';

export const DEFAULT_SETTINGS: PublicSettings = {
  title: 'OUR LITTLE MUSEUM',
  quote: 'Some moments are too beautiful to leave in the past.',
  subtitle: 'A little place for our favourite memories.',
  welcome_fatmid: 'Welcome back, Fatmid ♡',
  welcome_fatima: 'Welcome home, Fatima ♡',
  proposal_line1: 'Fatima Athar, if I could collect every beautiful moment of my life and place it in one room, you would still be my favourite part of it.',
  proposal_line2: 'Will you keep making beautiful memories with me? ♡',
  proposal_yes: 'YES, MY LOVE ♡',
  proposal_hug: 'HUG FIRST! 🥹',
  proposal_later: 'NOT YET, LET ME THINK ♡',
  proposal_yes_reply: 'Then let us keep collecting them, together. ♡',
  proposal_hug_reply: 'Come here, you. ♡',
  proposal_later_reply: 'Take all the time you like. The museum will wait. ♡',
  features: DEFAULT_FEATURES,
  notes_visibility: 'recipient',
  show_sender: true,
  environment: 'warm',
  welcome_style: 'ivory',
  default_volume: 0.4,
  proposal_track_id: null,
};

const ROOMS = [
  { name: 'The Beginning', description: 'A small entrance hall. Every story starts at a door.', gx: 0, gy: 0, wall: '#f3ead8', floor: '#e9dcc3', pat: 'tiles', decor: 'entrance', ent: 1 },
  { name: 'Our First Memories', description: 'Where it all began.', gx: 1, gy: 0, wall: '#f1e6d6', floor: '#e6d5bc', pat: 'planks', decor: 'rug', ent: 0 },
  { name: 'The Little Things', description: 'Small moments, quietly meaningful.', gx: 2, gy: 0, wall: '#f4e4dc', floor: '#ead9c8', pat: 'checker', decor: 'rug', ent: 0 },
  { name: 'Our Favourite Days', description: 'Celebrations and happy days.', gx: 3, gy: 0, wall: '#f5ecd2', floor: '#e8d6b4', pat: 'planks', decor: 'bunting', ent: 0 },
  { name: 'Our Songs', description: 'The music that belongs to us.', gx: 3, gy: 1, wall: '#ede4dc', floor: '#d8c4b0', pat: 'planks', decor: 'songs', ent: 0 },
  { name: 'The Quiet Corner', description: 'Benches, warm light and a beautiful view.', gx: 2, gy: 1, wall: '#e9eadb', floor: '#e3d8c1', pat: 'plain', decor: 'window', ent: 0 },
  { name: 'The Promise Room', description: 'For the questions that matter.', gx: 1, gy: 1, wall: '#f3e0dc', floor: '#e9d3c8', pat: 'tiles', decor: 'promise', ent: 0 },
];

export function seedIfEmpty() {
  tx(() => {
    if (!get('SELECT 1 AS x FROM rooms LIMIT 1')) {
      const ids: number[] = [];
      ROOMS.forEach((r, i) => {
        const res = run('INSERT INTO rooms (name, description, sort_order, gx, gy, wall_color, floor_color, floor_pattern, decor, is_entrance) VALUES (?,?,?,?,?,?,?,?,?,?)',
          r.name, r.description, i, r.gx, r.gy, r.wall, r.floor, r.pat, r.decor, r.ent);
        ids.push(Number(res.lastInsertRowid));
      });
      for (const [a, b] of [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6]]) run('INSERT INTO connections (a_room_id, b_room_id) VALUES (?,?)', ids[a], ids[b]);
      const plants = ['fern', 'monstera', 'tulips', 'olive'];
      ids.forEach((id, i) => {
        run("INSERT INTO furniture (room_id, kind, style, tx, ty) VALUES (?, 'plant', ?, 1, 2)", id, plants[i % 4]);
        run("INSERT INTO furniture (room_id, kind, style, tx, ty) VALUES (?, 'plant', ?, 14, 8)", id, plants[(i + 1) % 4]);
        run("INSERT INTO furniture (room_id, kind, style, tx, ty) VALUES (?, 'lamp', 'floor', 14, 2)", id);
        run("INSERT INTO furniture (room_id, kind, style, tx, ty) VALUES (?, 'plant', ?, 1, 8)", id, plants[(i + 2) % 4]);
      });
      run("INSERT INTO furniture (room_id, kind, style, tx, ty, facing) VALUES (?, 'bench', 'cushion', 4, 3, 'n')", ids[5]);
      run("INSERT INTO furniture (room_id, kind, style, tx, ty, facing) VALUES (?, 'bench', 'cushion', 10, 3, 'n')", ids[5]);
      run("INSERT INTO furniture (room_id, kind, style, tx, ty, facing) VALUES (?, 'bench', 'walnut', 11, 7, 's')", ids[0]);
      for (const [text, room] of SEED_MESSAGES) run('INSERT INTO messages (text, room_id, sender) VALUES (?,?,?)', text, room ? ids[room - 1] : null, 'Fatmid');
    }
    if (!get('SELECT 1 AS x FROM players LIMIT 1')) {
      const entrance = get<{ id: number }>('SELECT id FROM rooms WHERE is_entrance = 1')!;
      run('INSERT INTO players (slot, display_name, look, spawn_room_id, spawn_tx, spawn_ty) VALUES (?,?,?,?,?,?)', 'fatmid', 'Fatmid', JSON.stringify(DEFAULT_LOOKS.fatmid), entrance.id, 6, 5);
      run('INSERT INTO players (slot, display_name, look, spawn_room_id, spawn_tx, spawn_ty) VALUES (?,?,?,?,?,?)', 'fatima', 'Fatima Athar', JSON.stringify(DEFAULT_LOOKS.fatima), entrance.id, 8, 5);
    }
    for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) if (!get('SELECT 1 AS x FROM settings WHERE key = ?', k)) setSetting(k, v);
    setSetting('features', { ...DEFAULT_FEATURES, ...getSetting('features', DEFAULT_FEATURES) });
  });
}
