import crypto from 'node:crypto';
import { SECRET } from './config.ts';

export const sha256 = (s: string | Buffer) => crypto.createHash('sha256').update(s).digest('hex');
export const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a), bb = Buffer.from(b);
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

// invitation tokens: "<id>.<hmac>"; the hmac is derived from SECRET, never stored
const hmac = (s: string) => crypto.createHmac('sha256', SECRET).update(s).digest('base64url').slice(0, 32);
export const makeInviteToken = (id: string) => `${id}.${hmac('invite:' + id)}`;
export function parseInviteToken(token: unknown): string | null {
  if (typeof token !== 'string' || token.length > 80) return null;
  const [id, sig] = token.split('.');
  if (!id || !sig || !/^[a-f0-9]{16}$/.test(id)) return null;
  return safeEqual(sig, hmac('invite:' + id)) ? id : null;
}

// in-memory sliding-window rate limiter (single instance)
const buckets = new Map<string, number[]>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { buckets.set(key, arr); return false; }
  arr.push(now); buckets.set(key, arr);
  if (buckets.size > 5000) for (const [k, v] of buckets) if (!v.length || now - v[v.length - 1] > windowMs * 2) buckets.delete(k);
  return true;
}

export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('='); if (i < 0) continue;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore bad cookie */ }
  }
  return out;
}
export const cookie = (name: string, value: string, o: { maxAge: number; secure: boolean }) =>
  `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${o.maxAge}${o.secure ? '; Secure' : ''}`;

/** Strips control characters and anything tag-like. The client also only ever renders text, never HTML. */
export function cleanText(input: unknown, max: number): string {
  if (typeof input !== 'string') return '';
  return input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').replace(/<[^>]*>?/g, '').replace(/[<>]/g, '').trim().slice(0, max);
}
