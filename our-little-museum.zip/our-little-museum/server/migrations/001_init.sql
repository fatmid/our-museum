-- Our Little Museum — schema. There is no admin account: content comes from the content/ folder.
CREATE TABLE players (
  slot TEXT PRIMARY KEY CHECK (slot IN ('fatmid','fatima')),
  display_name TEXT NOT NULL,
  look TEXT NOT NULL,
  spawn_room_id INTEGER,
  spawn_tx INTEGER NOT NULL DEFAULT 8,
  spawn_ty INTEGER NOT NULL DEFAULT 5,
  last_x REAL, last_y REAL, last_seen INTEGER
);

-- Invitation links. The secret part of a link is an HMAC of `id` and is never stored.
CREATE TABLE invitations (
  id TEXT PRIMARY KEY,
  player_slot TEXT NOT NULL CHECK (player_slot IN ('fatmid','fatima')),
  label TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  expires_at INTEGER,
  revoked_at INTEGER,
  max_uses INTEGER,
  uses INTEGER NOT NULL DEFAULT 0,
  last_used_at INTEGER
);

CREATE TABLE sessions (
  id INTEGER PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL CHECK (kind IN ('player')),
  player_slot TEXT NOT NULL,
  invitation_id TEXT REFERENCES invitations(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  user_agent TEXT
);
CREATE INDEX idx_sessions_invitation ON sessions(invitation_id);

CREATE TABLE media (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('photo','audio')),
  title TEXT NOT NULL DEFAULT '',
  file TEXT NOT NULL,
  thumb TEXT,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  width INTEGER, height INTEGER,
  src_hash TEXT,
  created_at INTEGER NOT NULL
);

CREATE TABLE rooms (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  gx INTEGER NOT NULL,
  gy INTEGER NOT NULL,
  wall_color TEXT NOT NULL DEFAULT '#f3ead8',
  floor_color TEXT NOT NULL DEFAULT '#e9dcc3',
  floor_pattern TEXT NOT NULL DEFAULT 'planks',
  decor TEXT NOT NULL DEFAULT 'none',
  music_track_id INTEGER REFERENCES media(id) ON DELETE SET NULL,
  hidden INTEGER NOT NULL DEFAULT 0,
  is_entrance INTEGER NOT NULL DEFAULT 0,
  UNIQUE (gx, gy)
);

CREATE TABLE connections (
  id INTEGER PRIMARY KEY,
  a_room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  b_room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  enabled INTEGER NOT NULL DEFAULT 1,
  UNIQUE (a_room_id, b_room_id)
);

CREATE TABLE frames (
  id INTEGER PRIMARY KEY,
  room_id INTEGER REFERENCES rooms(id) ON DELETE SET NULL,
  wall TEXT NOT NULL DEFAULT 'north' CHECK (wall IN ('north','south')),
  sort_order INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL DEFAULT '',
  caption TEXT NOT NULL DEFAULT '',
  date TEXT NOT NULL DEFAULT '',
  memory TEXT NOT NULL DEFAULT '',
  photo_id INTEGER REFERENCES media(id) ON DELETE SET NULL,
  audio_id INTEGER REFERENCES media(id) ON DELETE SET NULL,
  has_bench INTEGER NOT NULL DEFAULT 0,
  bench_style TEXT NOT NULL DEFAULT 'oak',
  hidden INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_frames_room ON frames(room_id, wall, sort_order);

CREATE TABLE furniture (
  id INTEGER PRIMARY KEY,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('bench','plant','lamp')),
  style TEXT NOT NULL DEFAULT '',
  tx INTEGER NOT NULL,
  ty INTEGER NOT NULL,
  facing TEXT NOT NULL DEFAULT 'n' CHECK (facing IN ('n','s'))
);
CREATE INDEX idx_furniture_room ON furniture(room_id);

CREATE TABLE messages (
  id INTEGER PRIMARY KEY,
  text TEXT NOT NULL,
  room_id INTEGER REFERENCES rooms(id) ON DELETE CASCADE,
  sender TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  managed INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE timeline (
  id INTEGER PRIMARY KEY,
  date TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL DEFAULT '',
  caption TEXT NOT NULL DEFAULT '',
  story TEXT NOT NULL DEFAULT '',
  photo_id INTEGER REFERENCES media(id) ON DELETE SET NULL,
  audio_id INTEGER REFERENCES media(id) ON DELETE SET NULL,
  hidden INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE notes (
  id INTEGER PRIMARY KEY,
  from_slot TEXT NOT NULL CHECK (from_slot IN ('fatmid','fatima')),
  to_slot TEXT NOT NULL CHECK (to_slot IN ('fatmid','fatima')),
  text TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  read_at INTEGER
);
CREATE INDEX idx_notes_to ON notes(to_slot, created_at);

CREATE TABLE interactions (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  from_slot TEXT NOT NULL,
  to_slot TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  resolved_at INTEGER
);

CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
