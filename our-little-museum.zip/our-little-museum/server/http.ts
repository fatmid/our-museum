import type { IncomingMessage, ServerResponse } from 'node:http';
import { PUBLIC_URL, TRUST_PROXY, PRODUCTION } from './config.ts';
import { rateLimit } from './security.ts';

export interface Ctx { req: IncomingMessage; res: ServerResponse; url: URL; params: Record<string, string>; ip: string; secure: boolean }
export type Handler = (c: Ctx) => Promise<void> | void;
export class HttpError extends Error { constructor(public status: number, message: string) { super(message); } }

interface Route { method: string; re: RegExp; keys: string[]; handler: Handler }
const routes: Route[] = [];
export function route(method: string, path: string, handler: Handler) {
  const keys: string[] = [];
  const re = new RegExp('^' + path.replace(/:[a-zA-Z]+/g, (m) => { keys.push(m.slice(1)); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler });
}
export const get = (p: string, h: Handler) => route('GET', p, h);
export const post = (p: string, h: Handler) => route('POST', p, h);
export const patch = (p: string, h: Handler) => route('PATCH', p, h);

export function clientIp(req: IncomingMessage): string {
  if (TRUST_PROXY) {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
    if (xf.length) return xf[xf.length - 1];
  }
  return req.socket.remoteAddress || 'unknown';
}
export function isSecure(req: IncomingMessage): boolean {
  if (PUBLIC_URL.startsWith('https://')) return true;
  if (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https') return true;
  return !!(req.socket as any).encrypted;
}
export function send(res: ServerResponse, status: number, body: string | Buffer, headers: Record<string, string> = {}) { res.writeHead(status, headers); res.end(body); }
export function json(res: ServerResponse, status: number, data: unknown, headers: Record<string, string> = {}) {
  send(res, status, JSON.stringify(data), { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers });
}
export async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  if (Number(req.headers['content-length'] || 0) > limit) throw new HttpError(413, 'Request too large');
  const chunks: Buffer[] = []; let size = 0;
  for await (const chunk of req) { size += (chunk as Buffer).length; if (size > limit) throw new HttpError(413, 'Request too large'); chunks.push(chunk as Buffer); }
  return Buffer.concat(chunks);
}
export async function readJson<T = any>(c: Ctx, limit = 16 * 1024): Promise<T> {
  const buf = await readBody(c.req, limit);
  if (!buf.length) return {} as T;
  try { return JSON.parse(buf.toString('utf8')) as T; } catch { throw new HttpError(400, 'Invalid JSON'); }
}
export function securityHeaders(res: ServerResponse, secure: boolean) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' ws: wss:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  if (secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}
/** Same-origin check for state-changing requests (on top of SameSite=Strict cookies). */
function csrfOk(req: IncomingMessage): boolean {
  if (req.method === 'GET' || req.method === 'HEAD') return true;
  if (req.headers['x-olm'] !== '1') return false;
  const origin = req.headers.origin;
  if (origin) { try { return new URL(origin).host === req.headers.host; } catch { return false; } }
  return true;
}
export async function dispatch(req: IncomingMessage, res: ServerResponse, url: URL): Promise<boolean> {
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.re.exec(url.pathname); if (!m) continue;
    const params: Record<string, string> = {};
    r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
    const ip = clientIp(req);
    const c: Ctx = { req, res, url, params, ip, secure: isSecure(req) };
    try {
      if (!rateLimit('g:' + ip, 600, 60_000)) throw new HttpError(429, 'Too many requests');
      if (!csrfOk(req)) throw new HttpError(403, 'Forbidden');
      await r.handler(c);
    } catch (e: any) {
      if (e instanceof HttpError) { if (!res.headersSent) json(res, e.status, { error: e.message }); }
      else { console.error('[http] error', req.method, url.pathname, PRODUCTION ? e?.message : e); if (!res.headersSent) json(res, 500, { error: 'Something went wrong' }); }
    }
    return true;
  }
  return false;
}
