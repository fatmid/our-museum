// Real-time multiplayer: presence, movement validation, seats, shared viewing, couple interactions, music sync.
import type { Server as HttpServer, IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import crypto from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';
import { get, run } from './db.ts';
import { playerFromReq, type PlayerAuth } from './auth.ts';
import { loadPlayers, loadSettings, loadWorldInput, version } from './bundle.ts';
import { rateLimit } from './security.ts';
import { buildWorld, blocked, roomAt, spawnFor, pairSpots, nearestWalkable, dist, PLAYER_SPEED, type World } from '../shared/world.ts';
import { DIRS, DEFAULT_FEATURES, FREE_ACTS, otherSlot, type Anim, type Dir, type IxKind, type MusicState, type PeerState, type Slot, type Features } from '../shared/types.ts';

interface Rt {
  slot: Slot; ws: WebSocket | null; sessionId: number | null; online: boolean;
  x: number; y: number; d: Dir; mv: 0 | 1; anim: Anim; animAt: number; seat: string | null; room: number | null; viewing: number | null;
  lastPos: number; budget: number; grace: number; lastAct: number; dirty: boolean; alive: boolean; init: boolean; bucket: number; bucketAt: number;
}
interface Ix { id: string; kind: IxKind; from: Slot; to: Slot; stage: string; data: any; timers: NodeJS.Timeout[]; spots?: Record<Slot, { x: number; y: number; d: Dir }> }

const mk = (slot: Slot): Rt => ({ slot, ws: null, sessionId: null, online: false, x: 0, y: 0, d: 'down', mv: 0, anim: 'idle', animAt: 0, seat: null, room: null, viewing: null, lastPos: 0, budget: 260, grace: 0, lastAct: 0, dirty: false, alive: true, init: false, bucket: 120, bucketAt: Date.now() });
const rt: Record<Slot, Rt> = { fatmid: mk('fatmid'), fatima: mk('fatima') };
let world: World = buildWorld({ rooms: [], connections: [], frames: [], furniture: [] });
let features: Features = { ...DEFAULT_FEATURES };
let ix: Ix | null = null;
let music: MusicState = { shared: false, track: null, playing: false, pos: 0, at: 0, loop: false, by: null };
const SLOT_LIST: Slot[] = ['fatmid', 'fatima'];
const names = () => { const p = loadPlayers(); return { fatmid: p.fatmid?.name || 'Fatmid', fatima: p.fatima?.name || 'Fatima Athar' }; };

const send = (slot: Slot, msg: any) => { const w = rt[slot].ws; if (w && w.readyState === WebSocket.OPEN) w.send(JSON.stringify(msg)); };
const both = (msg: any) => { send('fatmid', msg); send('fatima', msg); };
const snap = (s: Slot): PeerState => { const r = rt[s]; return { slot: s, online: r.online, x: r.x, y: r.y, d: r.d, mv: r.mv, anim: r.anim, animAt: r.animAt, seat: r.seat, room: r.room, viewing: r.viewing }; };
const ixSummary = () => (ix ? { id: ix.id, kind: ix.kind, from: ix.from, to: ix.to, stage: ix.stage, data: ix.data, spots: ix.spots } : null);

export function rebuildWorld() {
  world = buildWorld(loadWorldInput());
  features = loadSettings().features;
  for (const s of SLOT_LIST) {
    const r = rt[s]; if (!r.init) continue;
    if (r.seat) {
      const [key, idx] = r.seat.split(':'); const b = world.benches.find((b) => b.key === key);
      if (!b || !b.seats[Number(idx)]) {
        r.seat = null; r.anim = 'idle'; r.dirty = true; const p = nearestWalkable(world, r.x, r.y); r.x = p.x; r.y = p.y; r.grace = Date.now() + 2000;
        both({ t: 'seat', s, seat: null, x: r.x, y: r.y, d: r.d });
      }
    } else if (blocked(world, r.x, r.y)) {
      const p = nearestWalkable(world, r.x, r.y); r.x = p.x; r.y = p.y; r.grace = Date.now() + 2000; send(s, { t: 'correct', x: r.x, y: r.y, d: r.d });
    }
    r.room = roomAt(world, r.x, r.y)?.row.id ?? r.room;
    if (r.viewing && !world.frames.find((f) => f.id === r.viewing)) { r.viewing = null; send(s, { t: 'view_closed' }); }
  }
}
export function notifyMuseumChanged() { rebuildWorld(); both({ t: 'museum_updated', version }); }
export function pushNote(note: any) { send(note.to_slot, { t: 'note', note }); }
export function kickSlot(slot: Slot, reason: string) { const w = rt[slot].ws; if (w) { try { w.send(JSON.stringify({ t: 'kicked', reason })); } catch { /* */ } w.close(4003, reason); } }
function persist(s: Slot) { const r = rt[s]; if (!r.init) return; run('UPDATE players SET last_x = ?, last_y = ?, last_seen = ? WHERE slot = ?', r.x, r.y, Date.now(), s); r.dirty = false; }

export function attachRealtime(server: HttpServer) {
  rebuildWorld();
  const wss = new WebSocketServer({ noServer: true, maxPayload: 8 * 1024, perMessageDeflate: false });
  server.on('upgrade', (req: IncomingMessage, socket: Duplex, head: Buffer) => {
    const reject = (code: number, msg: string) => { socket.write(`HTTP/1.1 ${code} ${msg}\r\nConnection: close\r\n\r\n`); socket.destroy(); };
    let url: URL; try { url = new URL(req.url || '/', 'http://x'); } catch { return reject(400, 'Bad Request'); }
    if (url.pathname !== '/ws') return reject(404, 'Not Found');
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) return reject(403, 'Forbidden'); } catch { return reject(403, 'Forbidden'); } }
    const auth = playerFromReq(req);
    if (!auth) return reject(401, 'Unauthorized');
    if (!rateLimit('ws:' + (req.socket.remoteAddress || ''), 60, 60_000)) return reject(429, 'Too Many Requests');
    wss.handleUpgrade(req, socket, head, (ws) => onConnect(ws, auth));
  });
  setInterval(() => {
    for (const s of SLOT_LIST) {
      const r = rt[s]; if (!r.ws) continue;
      if (!r.alive) { r.ws.terminate(); continue; }
      r.alive = false; try { r.ws.ping(); } catch { /* */ }
      if (r.sessionId != null) { // revocation check: the session row disappears when an invitation is revoked
        const ok = get<any>('SELECT 1 AS x FROM sessions s LEFT JOIN invitations i ON i.id = s.invitation_id WHERE s.id = ? AND s.expires_at > ? AND i.revoked_at IS NULL', r.sessionId, Date.now());
        if (!ok) kickSlot(s, 'revoked');
      }
    }
  }, 15_000).unref();
  setInterval(() => { for (const s of SLOT_LIST) if (rt[s].dirty) persist(s); }, 10_000).unref();
}

function initPlayer(r: Rt) {
  const p = loadPlayers()[r.slot];
  const row = get<any>('SELECT last_x, last_y FROM players WHERE slot = ?', r.slot);
  let pos = row && row.last_x != null ? { x: row.last_x as number, y: row.last_y as number } : spawnFor(world, p?.spawn_room_id ?? null, p?.spawn_tx ?? 8, p?.spawn_ty ?? 5);
  if (blocked(world, pos.x, pos.y)) pos = spawnFor(world, p?.spawn_room_id ?? null, p?.spawn_tx ?? 8, p?.spawn_ty ?? 5);
  r.x = pos.x; r.y = pos.y; r.d = 'down'; r.anim = 'idle'; r.seat = null; r.init = true;
  r.room = roomAt(world, r.x, r.y)?.row.id ?? null;
}

function onConnect(ws: WebSocket, auth: PlayerAuth) {
  const slot = auth.slot; const r = rt[slot];
  if (r.ws && r.ws !== ws) { try { r.ws.send(JSON.stringify({ t: 'replaced' })); } catch { /* */ } r.ws.close(4001, 'replaced'); }
  if (!r.init) initPlayer(r);
  r.ws = ws; r.sessionId = auth.sessionId; r.online = true; r.alive = true; r.mv = 0; r.lastPos = Date.now(); r.budget = 260;
  ws.on('pong', () => { r.alive = true; });
  ws.on('message', (data: any, isBinary: boolean) => { if (isBinary || r.ws !== ws) return; r.alive = true; onMessage(slot, data.toString()); });
  ws.on('close', () => onDisconnect(slot, ws));
  ws.on('error', () => { /* handled by close */ });
  const o = otherSlot(slot);
  send(slot, { t: 'welcome', slot, you: snap(slot), peer: snap(o), ix: ixSummary(), music, now: Date.now(), version, names: names() });
  send(o, { t: 'presence', peer: snap(slot) });
}

function onDisconnect(slot: Slot, ws: WebSocket) {
  const r = rt[slot];
  if (r.ws !== ws) return;
  r.ws = null; r.online = false; r.mv = 0; persist(slot);
  if (ix && (ix.from === slot || ix.to === slot)) endIx('left');
  if (music.shared) { music = { ...music, shared: false }; send(otherSlot(slot), { t: 'music', op: 'shared', on: false, state: music }); }
  if (r.viewing != null) { r.viewing = null; send(otherSlot(slot), { t: 'together_view', frame: null }); }
  send(otherSlot(slot), { t: 'presence', peer: snap(slot) });
}

const num = (v: any, lo = -1e6, hi = 1e6) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : null);

function onMessage(slot: Slot, raw: string) {
  const r = rt[slot]; const o = otherSlot(slot); const now = Date.now();
  r.bucket = Math.min(120, r.bucket + ((now - r.bucketAt) / 1000) * 60); r.bucketAt = now;
  if (r.bucket < 1) return; r.bucket -= 1;
  let m: any; try { m = JSON.parse(raw); } catch { return; }
  if (!m || typeof m.t !== 'string') return;
  switch (m.t) {
    case 'ping': return send(slot, { t: 'pong', c: num(m.c, 0, 1e15), s: now });
    case 'pos': {
      if (r.seat) return;
      const x = num(m.x, 0, world.w * 32), y = num(m.y, 0, world.h * 32);
      if (x == null || y == null || !DIRS.includes(m.d)) return;
      const dt = Math.max(30, now - r.lastPos); r.lastPos = now;
      r.budget = Math.min(260, r.budget + (dt / 1000) * PLAYER_SPEED * 1.6);
      const d = dist(x, y, r.x, r.y); const free = now < r.grace;
      if (!free && (blocked(world, x, y) || d > r.budget + 4)) { send(slot, { t: 'correct', x: r.x, y: r.y, d: r.d }); r.budget = 260; return; }
      if (!free) r.budget -= d;
      r.x = x; r.y = y; r.d = m.d; r.mv = m.mv ? 1 : 0; r.dirty = true;
      if (r.mv && r.anim !== 'idle' && !(ix && ix.kind === 'hands' && (ix.from === slot || ix.to === slot))) r.anim = 'idle';
      const room = roomAt(world, x, y)?.row.id ?? null; if (room != null) r.room = room;
      send(o, { t: 'p', s: slot, x, y, d: r.d, mv: r.mv, a: r.anim, room: r.room });
      return;
    }
    case 'act': {
      const a = m.a as Anim;
      if (a !== 'idle' && !FREE_ACTS.includes(a)) return;
      if (ix && (ix.from === slot || ix.to === slot) && ix.stage !== 'invited') return;
      if (now - r.lastAct < 250) return; r.lastAct = now;
      if (r.seat && a !== 'idle' && !['wave', 'heart', 'kiss', 'shy'].includes(a)) return;
      r.anim = r.seat && a === 'idle' ? 'sit' : a; r.animAt = now; r.mv = 0;
      send(o, { t: 'act', s: slot, a: r.anim, at: now }); send(slot, { t: 'act_ok', a: r.anim, at: now });
      return;
    }
    case 'sit': {
      if (ix && ix.stage !== 'invited') return send(slot, { t: 'notice', text: 'Let this moment finish first ♡' });
      if (r.seat) return;
      const b = world.benches.find((b) => b.key === m.key); const idx = Number(m.idx); const seat = b?.seats[idx];
      if (!b || !seat) return send(slot, { t: 'notice', text: 'There is no seat there.' });
      if (dist(r.x, r.y, seat.x, seat.y) > 80) return send(slot, { t: 'notice', text: 'Come a little closer to the bench first.' });
      if (rt[o].seat === `${b.key}:${idx}`) return send(slot, { t: 'notice', text: 'That seat is taken, try the other side ♡' });
      r.seat = `${b.key}:${idx}`; r.x = seat.x; r.y = seat.y; r.d = seat.dir; r.anim = 'sit'; r.mv = 0; r.animAt = now; r.dirty = true; r.grace = now + 1500; r.lastPos = now;
      both({ t: 'seat', s: slot, seat: r.seat, x: r.x, y: r.y, d: r.d });
      if (rt[o].seat && rt[o].seat!.split(':')[0] === b.key) both({ t: 'together_sit', key: b.key });
      return;
    }
    case 'stand': {
      if (!r.seat) return;
      const [key, idx] = r.seat.split(':'); const seat = world.benches.find((b) => b.key === key)?.seats[Number(idx)];
      let p = { x: r.x, y: r.y };
      if (seat) {
        const fwd = seat.dir === 'up' ? -1 : 1;
        const cands = [{ x: seat.x, y: seat.y + fwd * 26 }, { x: seat.x, y: seat.y - fwd * 26 }, { x: seat.x + 30, y: seat.y + fwd * 26 }, { x: seat.x - 30, y: seat.y + fwd * 26 }];
        p = cands.find((c) => !blocked(world, c.x, c.y)) || nearestWalkable(world, seat.x, seat.y);
      } else p = nearestWalkable(world, r.x, r.y);
      r.seat = null; r.x = p.x; r.y = p.y; r.anim = 'idle'; r.mv = 0; r.grace = now + 1500; r.lastPos = now; r.dirty = true;
      both({ t: 'seat', s: slot, seat: null, x: r.x, y: r.y, d: r.d });
      return;
    }
    case 'view': {
      const fid = m.frame == null ? null : Number(m.frame);
      if (fid != null && !world.frames.find((f) => f.id === fid)) return;
      r.viewing = fid;
      if (fid == null) { both({ t: 'together_view', frame: null }); send(o, { t: 'peer_view', s: slot, frame: null }); return; }
      if (!features.sharedViewing || !rt[o].online) return;
      if (rt[o].viewing === fid) { both({ t: 'together_view', frame: fid }); return; }
      send(o, { t: 'peer_view', s: slot, frame: fid, name: names()[slot] });
      return;
    }
    case 'invite': return startInvite(slot, m);
    case 'reply': {
      if (!ix || ix.id !== m.id || ix.stage !== 'invited' || ix.to !== slot) return;
      return m.accept ? beginIx() : endIx('declined');
    }
    case 'choice': {
      if (!ix || ix.kind !== 'propose' || ix.id !== m.id || ix.stage !== 'ask' || ix.to !== slot) return;
      const c = Number(m.choice); if (![0, 1, 2].includes(c)) return;
      return proposalChoice(c);
    }
    case 'end_ix': {
      if (!ix || (ix.from !== slot && ix.to !== slot)) return;
      if (ix.stage === 'invited') return endIx(ix.from === slot ? 'cancelled' : 'declined');
      return endIx(ix.kind === 'propose' ? 'closed' : 'ended');
    }
    case 'music': return onMusic(slot, m);
  }
}

// ---------------- couple interactions ----------------
const INVITE_RANGE = 250;
const INVITABLE: IxKind[] = ['hug', 'hands', 'dance', 'photo', 'propose'];

function startInvite(from: Slot, m: any) {
  const to = otherSlot(from); const kind = m.kind as IxKind; const n = names();
  if (!INVITABLE.includes(kind)) return;
  const feat: Record<IxKind, boolean> = { hug: features.hugs, hands: features.handHolding, dance: features.danceTogether, photo: features.photoMoment, propose: features.proposal };
  if (!feat[kind]) return send(from, { t: 'notice', text: 'That is switched off right now.' });
  if (kind === 'propose' && from !== 'fatmid') return send(from, { t: 'notice', text: 'That one is only for Fatmid to ask ♡' });
  if (!rt[to].online) return send(from, { t: 'notice', text: `${n[to]} is away at the moment ♡` });
  if (ix) return send(from, { t: 'notice', text: 'Hold on, something sweet is already happening ♡' });
  if (dist(rt[from].x, rt[from].y, rt[to].x, rt[to].y) > INVITE_RANGE) return send(from, { t: 'notice', text: `Walk a little closer to ${n[to]} first ♡`, code: 'far' });
  const data: any = {};
  if (kind === 'dance') data.variant = [1, 2, 3].includes(Number(m.data?.variant)) ? Number(m.data.variant) : 1;
  if (kind === 'photo') data.frame = typeof m.data?.frame === 'string' ? String(m.data.frame).slice(0, 20) : 'classic';
  ix = { id: crypto.randomBytes(6).toString('hex'), kind, from, to, stage: 'invited', data, timers: [] };
  run('INSERT INTO interactions (id, kind, from_slot, to_slot, status, created_at) VALUES (?,?,?,?,?,?)', ix.id, kind, from, to, 'invited', Date.now());
  send(to, { t: 'ix_invite', id: ix.id, kind, from, data });
  send(from, { t: 'ix_invite_sent', id: ix.id, kind });
  ix.timers.push(setTimeout(() => { if (ix && ix.stage === 'invited') endIx('expired'); }, 45_000));
}
function later(ms: number, fn: () => void) { const cur = ix; const t = setTimeout(() => { if (ix === cur && ix) fn(); }, ms); ix?.timers.push(t); }
function setStage(stage: string, data?: any, extra?: Record<string, any>) {
  if (!ix) return; ix.stage = stage; if (data !== undefined) ix.data = { ...ix.data, ...data };
  both({ t: 'ix_stage', id: ix.id, stage, data, ...extra });
}
const setAnims = (a: Anim, b: Anim) => { if (!ix) return; rt[ix.from].anim = a; rt[ix.to].anim = b; rt[ix.from].animAt = rt[ix.to].animAt = Date.now(); };

function beginIx() {
  if (!ix) return; const i = ix; const { from, to, kind } = i; const now = Date.now();
  for (const s of [from, to]) { rt[s].seat = null; rt[s].mv = 0; }
  const A = rt[from], B = rt[to]; const sign: 1 | -1 = B.x >= A.x ? 1 : -1;
  let spots;
  if (kind === 'hug') spots = pairSpots(world, A, 'anchor', sign, 24);
  else if (kind === 'hands') spots = pairSpots(world, A, 'anchor', sign, 30);
  else if (kind === 'propose') spots = pairSpots(world, A, 'anchor', sign, 36);
  else spots = pairSpots(world, { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 }, 'center', 1, kind === 'photo' ? 30 : 40);
  const sp = { [from]: spots.a, [to]: spots.b } as Record<Slot, { x: number; y: number; d: Dir }>;
  if (kind === 'photo') { sp[from].d = 'down'; sp[to].d = 'down'; }
  i.spots = sp;
  for (const s of [from, to]) { const r = rt[s]; r.x = sp[s].x; r.y = sp[s].y; r.d = sp[s].d; r.grace = now + 2500; r.lastPos = now; r.budget = 260; r.dirty = true; r.anim = 'idle'; r.room = roomAt(world, r.x, r.y)?.row.id ?? r.room; }
  i.stage = 'move';
  run('UPDATE interactions SET status = ? WHERE id = ?', 'accepted', i.id);
  both({ t: 'ix_start', ix: ixSummary() });
  const s = loadSettings();
  if (kind === 'hug') { later(800, () => { setAnims('hug', 'hug'); setStage('play'); }); later(4200, () => endIx('done')); }
  else if (kind === 'hands') { later(800, () => setStage('play')); }
  else if (kind === 'dance') {
    const v = i.data.variant || 1;
    later(800, () => { setAnims(`dance${v}` as Anim, `dance${v}` as Anim); setStage('play', { variant: v }, { startAt: Date.now() }); });
    later(11_000, () => endIx('done'));
  } else if (kind === 'photo') {
    later(1000, () => setStage('pose')); later(2400, () => setStage('count', { n: 3 })); later(3400, () => setStage('count', { n: 2 }));
    later(4400, () => setStage('count', { n: 1 })); later(5400, () => setStage('flash')); later(6600, () => endIx('done'));
  } else if (kind === 'propose') {
    const texts = { line1: s.proposal_line1, line2: s.proposal_line2, yes: s.proposal_yes, hug: s.proposal_hug, later: s.proposal_later, yesReply: s.proposal_yes_reply, hugReply: s.proposal_hug_reply, laterReply: s.proposal_later_reply, track: s.proposal_track_id };
    later(1000, () => { setAnims('kneel', 'shy'); setStage('kneel', texts); });
    later(2400, () => setStage('ring')); later(5200, () => setStage('msg1')); later(12_800, () => setStage('msg2')); later(16_800, () => setStage('ask'));
    later(10 * 60_000, () => endIx('closed'));
  }
}
function proposalChoice(c: number) {
  if (!ix) return; const i = ix;
  for (const t of i.timers) clearTimeout(t); i.timers = [];
  if (c === 0) { setAnims('cheer', 'cheer'); setStage('yes'); later(8000, () => endIx('yes')); }
  else if (c === 1) { setAnims('hug', 'hug'); setStage('hug'); later(4200, () => { setAnims('kneel', 'shy'); setStage('ask'); }); }
  else { setAnims('kneel', 'shy'); setStage('later'); later(4800, () => endIx('later')); }
}
function endIx(result: string) {
  if (!ix) return; const i = ix;
  for (const t of i.timers) clearTimeout(t);
  ix = null;
  if (i.stage !== 'invited') for (const s of [i.from, i.to]) { rt[s].anim = rt[s].seat ? 'sit' : 'idle'; rt[s].animAt = Date.now(); }
  run('UPDATE interactions SET status = ?, resolved_at = ? WHERE id = ?', result, Date.now(), i.id);
  both({ t: 'ix_end', id: i.id, kind: i.kind, from: i.from, to: i.to, result, stage: i.stage });
}

// ---------------- music ----------------
function onMusic(slot: Slot, m: any) {
  const o = otherSlot(slot);
  if (!features.sharedMusic) return;
  switch (m.op) {
    case 'share_req': if (!rt[o].online) return send(slot, { t: 'notice', text: `${names()[o]} is away at the moment ♡` }); send(o, { t: 'music', op: 'share_req', from: slot, name: names()[slot] }); return;
    case 'share_ok': music = { ...music, shared: true, by: slot, at: Date.now() }; both({ t: 'music', op: 'shared', on: true, state: music }); return;
    case 'share_no': send(o, { t: 'music', op: 'share_no' }); return;
    case 'share_leave': music = { ...music, shared: false }; both({ t: 'music', op: 'shared', on: false, state: music }); return;
    case 'cmd': {
      if (!music.shared) return;
      const track = m.track == null ? null : Number(m.track);
      if (track != null && !get('SELECT 1 AS x FROM media WHERE id = ? AND kind = ?', track, 'audio')) return;
      music = { shared: true, track, playing: !!m.playing, pos: num(m.pos, 0, 86400) ?? 0, at: Date.now(), loop: !!m.loop, by: slot };
      send(o, { t: 'music', op: 'cmd', state: music, quiet: !!m.quiet });
      return;
    }
  }
}
