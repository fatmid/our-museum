import { all, get, getSetting } from './db.ts';
import { DEFAULT_LOOKS, DEFAULT_FEATURES } from '../shared/types.ts';
import type { MuseumBundle, PublicSettings, Slot, PlayerInfo, Look } from '../shared/types.ts';
import { DEFAULT_SETTINGS } from './seed.ts';
import type { WorldInput } from '../shared/world.ts';

export let version = Date.now();
export const bumpVersion = () => { version = Math.max(version + 1, Date.now()); return version; };

export function loadSettings(): PublicSettings {
  const out: any = {};
  for (const [k, d] of Object.entries(DEFAULT_SETTINGS)) out[k] = getSetting(k, d);
  out.features = { ...DEFAULT_FEATURES, ...out.features };
  return out as PublicSettings;
}
export const loadWorldInput = (): WorldInput => ({
  rooms: all('SELECT * FROM rooms ORDER BY sort_order, id'), connections: all('SELECT * FROM connections'),
  frames: all('SELECT * FROM frames'), furniture: all('SELECT * FROM furniture'),
});
export function loadPlayers(): Record<Slot, PlayerInfo> {
  const out: any = {};
  for (const p of all<any>('SELECT * FROM players')) {
    let look: Look = DEFAULT_LOOKS[p.slot as Slot];
    try { look = { ...look, ...JSON.parse(p.look) }; } catch { /* keep default */ }
    out[p.slot] = { slot: p.slot, name: p.display_name, look, spawn_room_id: p.spawn_room_id, spawn_tx: p.spawn_tx, spawn_ty: p.spawn_ty };
  }
  return out;
}
export function buildBundle(slot: Slot): MuseumBundle {
  const p = get<any>('SELECT last_x, last_y FROM players WHERE slot = ?', slot);
  return {
    version, you: slot, settings: loadSettings(), players: loadPlayers(),
    rooms: all('SELECT * FROM rooms ORDER BY sort_order, id'), connections: all('SELECT * FROM connections'),
    frames: all('SELECT * FROM frames WHERE hidden = 0 ORDER BY room_id, wall, sort_order, id'), furniture: all('SELECT * FROM furniture'),
    tracks: all("SELECT id, title FROM media WHERE kind = 'audio' ORDER BY id"),
    messages: all('SELECT id, text, room_id, sender, enabled FROM messages WHERE enabled = 1'),
    timeline: all('SELECT * FROM timeline WHERE hidden = 0 ORDER BY sort_order, id'),
    last: p && p.last_x != null ? { x: p.last_x, y: p.last_y } : null,
  };
}
