import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const env = process.env;
export const DATA_DIR = path.resolve(env.DATA_DIR || './data');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
export const CONTENT_DIR = path.resolve(env.CONTENT_DIR || './content');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

export const PORT = Number(env.PORT || 8080);
export const PRODUCTION = env.NODE_ENV === 'production';
export const TRUST_PROXY = env.TRUST_PROXY === '1';
export const PUBLIC_URL = (env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');

function loadSecret(): string {
  if (env.SESSION_SECRET && env.SESSION_SECRET.length >= 24) return env.SESSION_SECRET;
  if (PRODUCTION) { console.error('FATAL: SESSION_SECRET must be set (at least 24 characters) in production.'); process.exit(1); }
  const f = path.join(DATA_DIR, '.dev-secret');
  if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8').trim();
  const s = crypto.randomBytes(48).toString('base64url');
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}
export const SECRET = loadSecret();
