import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import sharp from 'sharp';
import { UPLOAD_DIR } from './config.ts';
import { get, run } from './db.ts';
import { HttpError } from './http.ts';

export function sniffAudio(b: Buffer): { ext: string; mime: string } | null {
  if (b.length < 12) return null;
  const s = (a: number, e: number) => b.subarray(a, e).toString('latin1');
  if (s(0, 3) === 'ID3' || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return { ext: 'mp3', mime: 'audio/mpeg' };
  if (s(4, 8) === 'ftyp') return { ext: 'm4a', mime: 'audio/mp4' };
  if (s(0, 4) === 'OggS') return { ext: 'ogg', mime: 'audio/ogg' };
  if (s(0, 4) === 'RIFF' && s(8, 12) === 'WAVE') return { ext: 'wav', mime: 'audio/wav' };
  if (s(0, 4) === 'fLaC') return { ext: 'flac', mime: 'audio/flac' };
  return null;
}
export function saveAudio(buf: Buffer, title: string, srcHash: string): number {
  const t = sniffAudio(buf);
  if (!t) throw new Error('Unsupported audio file (use MP3, M4A, OGG, WAV or FLAC).');
  const file = `${crypto.randomUUID()}.${t.ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, file), buf, { mode: 0o600 });
  return Number(run('INSERT INTO media (kind, title, file, thumb, mime, size, src_hash, created_at) VALUES (?,?,?,?,?,?,?,?)', 'audio', title, file, null, t.mime, buf.length, srcHash, Date.now()).lastInsertRowid);
}
export async function savePhoto(buf: Buffer, title: string, srcHash: string): Promise<number> {
  const opts = { failOn: 'error' as const, limitInputPixels: 100_000_000 };
  try { await sharp(buf, opts).metadata(); } catch { throw new Error('Not a readable image.'); }
  const id = crypto.randomUUID(); const full = `${id}.webp`, thumb = `${id}.t.webp`;
  // .rotate() applies EXIF orientation; re-encoding strips all metadata (including GPS location).
  const base = () => sharp(buf, opts).rotate();
  const info = await base().resize({ width: 1800, height: 1800, fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toFile(path.join(UPLOAD_DIR, full));
  await base().resize({ width: 480, height: 480, fit: 'inside', withoutEnlargement: true }).webp({ quality: 78 }).toFile(path.join(UPLOAD_DIR, thumb));
  fs.chmodSync(path.join(UPLOAD_DIR, full), 0o600); fs.chmodSync(path.join(UPLOAD_DIR, thumb), 0o600);
  return Number(run('INSERT INTO media (kind, title, file, thumb, mime, size, width, height, src_hash, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)', 'photo', title, full, thumb, 'image/webp', info.size, info.width, info.height, srcHash, Date.now()).lastInsertRowid);
}
export function deleteMediaFiles(id: number) {
  const m = get<any>('SELECT file, thumb FROM media WHERE id = ?', id); if (!m) return;
  for (const f of [m.file, m.thumb]) if (f) { try { fs.unlinkSync(path.join(UPLOAD_DIR, path.basename(f))); } catch { /* already gone */ } }
}
export function serveMedia(req: IncomingMessage, res: ServerResponse, id: number, variant: string) {
  const m = get<any>('SELECT * FROM media WHERE id = ?', id);
  if (!m) throw new HttpError(404, 'Not found');
  const fp = path.join(UPLOAD_DIR, path.basename(variant === 'thumb' && m.thumb ? m.thumb : m.file));
  let st: fs.Stats; try { st = fs.statSync(fp); } catch { throw new HttpError(404, 'Not found'); }
  const headers: Record<string, string> = { 'content-type': m.mime, 'cache-control': 'private, max-age=604800, immutable', 'accept-ranges': 'bytes', 'content-disposition': 'inline', 'x-content-type-options': 'nosniff' };
  const range = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
  if (range && (range[1] || range[2])) {
    let start = range[1] ? parseInt(range[1], 10) : st.size - parseInt(range[2], 10);
    let end = range[1] && range[2] ? parseInt(range[2], 10) : st.size - 1;
    start = Math.max(0, start); end = Math.min(st.size - 1, end);
    if (start > end) { res.writeHead(416, { 'content-range': `bytes */${st.size}` }); res.end(); return; }
    res.writeHead(206, { ...headers, 'content-range': `bytes ${start}-${end}/${st.size}`, 'content-length': String(end - start + 1) });
    fs.createReadStream(fp, { start, end }).pipe(res); return;
  }
  res.writeHead(200, { ...headers, 'content-length': String(st.size) });
  if (req.method === 'HEAD') { res.end(); return; }
  fs.createReadStream(fp).pipe(res);
}
