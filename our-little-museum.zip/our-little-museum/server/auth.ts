import type { IncomingMessage } from 'node:http';
import { get, run } from './db.ts';
import { cookie, parseCookies, randomToken, sha256 } from './security.ts';
import { HttpError, type Ctx } from './http.ts';
import type { Slot } from '../shared/types.ts';

export const PLAYER_COOKIE = 'olm_p';
export const PLAYER_SESSION_MS = 90 * 86_400_000;
export interface PlayerAuth { sessionId: number; slot: Slot; invitationId: string | null }

export function createSession(o: { slot: Slot; invitationId: string; ua?: string }): { token: string; maxAge: number } {
  const token = randomToken(32); const now = Date.now();
  run('INSERT INTO sessions (token_hash, kind, player_slot, invitation_id, created_at, last_seen, expires_at, user_agent) VALUES (?,?,?,?,?,?,?,?)',
    sha256(token), 'player', o.slot, o.invitationId, now, now, now + PLAYER_SESSION_MS, (o.ua || '').slice(0, 200));
  return { token, maxAge: Math.floor(PLAYER_SESSION_MS / 1000) };
}
export function setSessionCookie(c: Ctx, name: string, token: string, maxAge: number) { c.res.setHeader('set-cookie', cookie(name, token, { maxAge, secure: c.secure })); }
export const clearCookie = (c: Ctx, name: string) => setSessionCookie(c, name, '', 0);

/** A session is valid only while its invitation exists and has not been revoked. */
export function playerFromToken(token: string | undefined): PlayerAuth | null {
  if (!token) return null;
  const s = get<any>("SELECT s.id, s.player_slot, s.invitation_id, s.expires_at, s.last_seen, i.revoked_at, i.id AS inv FROM sessions s LEFT JOIN invitations i ON i.id = s.invitation_id WHERE s.token_hash = ? AND s.kind = 'player'", sha256(token));
  if (!s || s.expires_at < Date.now() || s.revoked_at || !s.inv) return null;
  if (Date.now() - s.last_seen > 60_000) run('UPDATE sessions SET last_seen = ? WHERE id = ?', Date.now(), s.id);
  return { sessionId: s.id, slot: s.player_slot, invitationId: s.invitation_id };
}
export const playerFromReq = (req: IncomingMessage) => playerFromToken(parseCookies(req.headers.cookie)[PLAYER_COOKIE]);
export function requirePlayer(c: Ctx): PlayerAuth {
  const p = playerFromReq(c.req);
  if (!p) throw new HttpError(401, 'Please open the museum from your invitation link.');
  return p;
}
export const purgeExpiredSessions = () => run('DELETE FROM sessions WHERE expires_at < ?', Date.now());
