import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { PORT, DATA_DIR, PUBLIC_URL, PRODUCTION } from './config.ts';
import { migrate, get, run } from './db.ts';
import { makeInviteToken } from './security.ts';
import { seedIfEmpty } from './seed.ts';
import { dispatch, securityHeaders, isSecure, send, json } from './http.ts';
import { registerPublicRoutes } from './publicRoutes.ts';
import { attachRealtime, notifyMuseumChanged } from './realtime.ts';
import { purgeExpiredSessions } from './auth.ts';
import { syncContent, watchContent } from './content.ts';
import { bumpVersion } from './bundle.ts';

migrate();
seedIfEmpty();
// First start only: print one invitation per person so the museum can be opened without a shell on the server.
if (!get('SELECT 1 AS x FROM invitations LIMIT 1')) {
  console.log('\n================ FIRST START: invitation links (valid 30 days) ================');
  for (const slot of ['fatmid', 'fatima'] as const) {
    const id = crypto.randomBytes(8).toString('hex');
    run('INSERT INTO invitations (id, player_slot, label, created_at, expires_at) VALUES (?,?,?,?,?)', id, slot, 'first start', Date.now(), Date.now() + 30 * 86_400_000);
    console.log(`  ${slot === 'fatmid' ? 'Fatmid ' : 'Fatima '} ${PUBLIC_URL}/?invite=${makeInviteToken(id)}`);
  }
  console.log('  Treat each link like a key. Make QR codes / revoke with:  node dist/cli.js invite|list|revoke');
  console.log('================================================================================\n');
}
await syncContent();
registerPublicRoutes();

const PUBLIC_DIR = path.resolve(process.env.PUBLIC_DIR || path.join(path.dirname(fileURLToPath(import.meta.url)), 'public'));
const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.map': 'application/json' };

function serveStatic(req: http.IncomingMessage, res: http.ServerResponse, pathname: string): boolean {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  let rel: string; try { rel = decodeURIComponent(pathname); } catch { return false; }
  if (rel.includes('\0')) return false;
  let fp = path.join(PUBLIC_DIR, path.normalize(rel));
  if (!fp.startsWith(PUBLIC_DIR)) return false;
  let isAsset = rel.startsWith('/assets/');
  if (!fs.existsSync(fp) || fs.statSync(fp).isDirectory()) {
    if (rel.startsWith('/api/') || rel.startsWith('/assets/') || path.extname(rel)) return false;
    fp = path.join(PUBLIC_DIR, 'index.html'); isAsset = false; // SPA fallback
  }
  if (!fs.existsSync(fp)) return false;
  const buf = fs.readFileSync(fp);
  res.writeHead(200, { 'content-type': MIME[path.extname(fp)] || 'application/octet-stream', 'cache-control': isAsset ? 'public, max-age=31536000, immutable' : 'no-cache', 'content-length': String(buf.length) });
  res.end(req.method === 'HEAD' ? undefined : buf);
  return true;
}

const server = http.createServer(async (req, res) => {
  securityHeaders(res, isSecure(req));
  let url: URL; try { url = new URL(req.url || '/', 'http://localhost'); } catch { return send(res, 400, 'Bad request'); }
  if (url.pathname === '/healthz') return json(res, 200, { ok: true });
  if (await dispatch(req, res, url)) return;
  if (serveStatic(req, res, url.pathname)) return;
  json(res, 404, { error: 'Not found' });
});
attachRealtime(server);
watchContent(() => { bumpVersion(); notifyMuseumChanged(); });
server.headersTimeout = 20_000; server.requestTimeout = 120_000; server.keepAliveTimeout = 65_000;
setInterval(purgeExpiredSessions, 3_600_000).unref();
server.listen(PORT, () => console.log(`Our Little Museum is open on port ${PORT}  (public url: ${PUBLIC_URL}, data: ${DATA_DIR}${PRODUCTION ? '' : ', development mode'})`));
process.on('SIGTERM', () => { server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); });
