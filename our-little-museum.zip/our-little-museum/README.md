# Our Little Museum ♡

A private, two-person, real-time virtual museum. Fatmid and Fatima Athar each open a link on their own device, walk
around the same little museum, look at photographs together, sit on benches, dance, hug, hold hands, listen to songs
together and leave each other notes. Nobody else can get in.

It is one small Node program (web server + WebSocket + SQLite) and a browser app drawn on an HTML canvas.
There is **no admin website**: photos, songs and text are plain files in the `content/` folder, and invitations are
made with a one-line command.

---

## 1. Try it on your computer (2 minutes)

Requires Node.js 22.13 or newer.

```bash
npm install
npm run build
npm start                   # prints two invitation links for the first start
```

Open the Fatmid link in one browser and the Fatima link in a second browser (or a private window); you will see each
other walking around. `http://localhost:8080` itself only shows the welcome gate; the museum needs an invitation.

## 2. Adding photographs and songs

Drop files into `content/photos` and `content/songs`, then describe them in `content/content.json`.
Full instructions with every option: **[content/README.md](content/README.md)**.

While the server runs it notices changes within ~10 seconds and updates both players' museums live, with no restart.
On a hosted site, redeploy after changing `content/` (see below). Photos are resized and re-saved on import, which
removes location data (EXIF/GPS). **Keep your repository private**, because your original photos are in it.

## 3. Invitations and the QR code

```bash
npm run invite -- fatima          # a link + a QR code image for Fatima   (also: fatmid)
npm run invite -- fatima --days 90
npm run cli -- list               # who has been invited, expiry, last use
npm run cli -- revoke <id>        # revoke one (the device is signed out within ~15 seconds)
npm run cli -- revoke all
npm run cli -- qr "https://..."   # QR code for any link
```

`invite` prints the link, draws the QR code in the terminal and saves `invite-fatima-<id>.png` and `.svg` in
`<DATA_DIR>/invites/`. Send her the picture (or the link). When she scans it she sees the welcome gate, taps
**OPEN OUR MUSEUM ♡**, and walks in; if you are already inside she sees you immediately.

* An invitation link is a key: anyone who opens it becomes that person. Send it privately, and revoke it if it leaks.
* After the first open, her phone remembers her for 90 days, so she does not need the link again unless she clears her
  browser data, signs out or you revoke access. Opening the link on a second device works too; if both are open at once,
  the older window pauses so she never appears twice.
* `PUBLIC_URL` must be set to the real https address before you make the QR code, otherwise the code points to localhost.

## 4. Deploy it (public https address for the QR code)

The museum keeps live state in memory and its data in a file, so it needs **one always-on instance with a small
persistent disk**. Serverless/free-sleeping hosts will not work. Ready-made configs are included for
[Fly.io](https://fly.io) (`fly.toml`, about a dollar or two a month) and Render (`render.yaml`, paid disk). Any host that
can run the `Dockerfile` with a persistent volume at `/data` works.

### Fly.io, step by step

```bash
# 0. put your photos/songs in content/ first (and keep the repo private)
# 1. install flyctl and sign in:  https://fly.io/docs/flyctl/install/   then   fly auth login
# 2. edit app = "..." in fly.toml (names are global), then:
fly launch --no-deploy --copy-config
fly volumes create museum_data --size 1 --region fra     # same region as fly.toml
# 3. secrets (SESSION_SECRET signs invitation links: never share it, never change it later)
fly secrets set SESSION_SECRET="$(node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))")" \
                PUBLIC_URL="https://YOUR-APP-NAME.fly.dev"
# 4. deploy
fly deploy
# 5. the first start prints two invitation links in the log:
fly logs                                  # look for "FIRST START: invitation links"
```

More invitations / QR images later: `fly ssh console -C "node --no-warnings dist/cli.js invite fatima"` (it prints
`Database used: /data`; if it shows anything else, the command ran in the wrong place). To download the QR picture:
`fly ssh sftp get /data/invites/<file>.png`. Or copy the link and run `npm run cli -- qr "<link>"` on your own computer.

Updating photos/songs: change `content/`, run `fly deploy`. The database (notes, invitations, positions) lives on the
volume and survives deploys.

### Environment variables (see `.env.example`)

| Name | Needed | Meaning |
|---|---|---|
| `SESSION_SECRET` | production | ≥24 random characters; signs invitation links. Changing it invalidates every existing link. |
| `PUBLIC_URL` | production | Public https address, no trailing slash. Used for links/QR codes and the Secure cookie flag. |
| `DATA_DIR` | no (`./data`) | Database + processed media. Must be a persistent volume in production. |
| `CONTENT_DIR` | no (`./content`) | Folder with `content.json`, `photos/`, `songs/`. |
| `PORT` | no (`8080`) | Listening port. |
| `TRUST_PROXY` | behind a proxy | `1` on Fly/Render/Railway/Cloudflare so client IPs (rate limits) are read correctly. |

## 5. Privacy and security, in plain words

* The public address shows only the welcome gate. Photos, notes, songs and the museum itself require a valid invitation
  session; without one every private request returns 401 and the live connection is refused. Search engines are told not
  to index anything (`robots.txt`, `X-Robots-Tag`).
* Invitation links are signed (HMAC) and can expire, be limited to N uses, or be revoked at any time. Revoking also signs
  out that device, even mid-visit.
* Photos and songs are served only to a signed-in player, never from a public folder. There is no upload endpoint on the
  web at all, no admin login and no admin API to attack.
* Notes are limited to 280 characters, stripped of markup, and only ever rendered as plain text. Rate limits protect
  sign-in attempts and notes. Sessions are HttpOnly, SameSite=Strict, Secure cookies; state-changing requests also need a
  custom header and same-origin check. No analytics, no third-party scripts, fonts or trackers.
* Everyone with access to your hosting account/volume can read the database (notes are stored as plain text).
* **Delete things:** remove a photo/song from `content/` and redeploy (it is removed from the museum and the disk).
  Delete notes by deleting the volume (`fly volumes destroy`) or the `museum.db` file. Remove all access: `revoke all`.

## 6. Tests

```bash
npm run build && npm test      # ~4 minutes; needs Playwright's Chromium (npx playwright install chromium)
```

The end-to-end test starts a real server and drives **two independent browser sessions** (a laptop and a phone-sized
touch device with separate cookies): 108 checks, listed in [docs/TESTING.md](docs/TESTING.md), plus a manual checklist
for the things only real devices can prove. Screenshots land in `tests/out/`.

## 7. How it is built

* `server/` Node 22: HTTP + WebSocket (`ws`), built-in SQLite (`node:sqlite`), `sharp` for photos. The server is
  authoritative for who is where (speed/collision checks), who sits where, and each shared moment (hug, hands, dance,
  photo, proposal), so a modified browser cannot cheat or glitch the other player.
* `client/` React + TypeScript for menus; the museum itself is a small custom 2D canvas engine with original
  characters, furniture and animations drawn in code (no image assets, no paid avatar services).
* `shared/` geometry, collision and path-finding used by both sides.
* Why not Supabase/Phaser from the brief? My build environment could not download those packages, so I chose a
  self-contained stack instead. It is simpler to deploy (one process, one disk), keeps all photos on your own server, and
  has no third-party account that could see them. The cost: a single instance, and less polished sprite art than an
  artist-made sprite sheet would give.

## 8. Known limitations (please read)

* **Not yet verified on real devices.** All testing ran in desktop Chromium (including an emulated phone) from one
  machine. Safari/iPhone, Firefox, real mobile networks and two separate internet connections are untested. Do the
  manual checklist in `docs/TESTING.md` on your two phones after deploying.
* **Not deployed by me.** I cannot create hosting accounts, and the sandbox had no Docker daemon, so the `Dockerfile`,
  `fly.toml` and `render.yaml` are written but unbuilt. Expect to fix small things on first deploy.
* **No admin panel** (as requested). Rooms are a fixed set of seven connected rooms; `content.json` can rename or
  describe them, give them music and add photos, but adding/removing/rearranging rooms means a code change.
* One instance only; one couple per deployment; exactly two identities.
* Photos: JPG/PNG/WebP/GIF work. iPhone `.heic` files are not supported by the prebuilt image library: export as JPG.
* Shared music keeps both phones within about a second or so, not frame-perfect; browsers need one tap before they
  allow sound. Shared walk/dance/hug moments need both people online and within a short distance.
* Node 22 prints an "experimental SQLite" notice (hidden by `--no-warnings`); it is stable in practice.
* The art is original but drawn in code; characters have 8 hairstyles, 8 outfits and colour choices rather than
  hand-animated sprite sheets.
