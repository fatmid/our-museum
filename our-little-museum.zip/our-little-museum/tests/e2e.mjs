// End-to-end test: two independent browser sessions (separate cookie jars, one desktop, one phone-sized) against a real server.
// Run:  npm run build && npm test        Screenshots land in tests/out/
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path'; import os from 'node:os';
import { fileURLToPath } from 'node:url'; import { createRequire } from 'node:module';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let chromium;
try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = createRequire('/home/claude/.npm-global/lib/node_modules/')('playwright')); }
const PORT = Number(process.env.TEST_PORT || 20000 + Math.floor(Math.random() * 20000)), BASE = `http://localhost:${PORT}`;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'olm-e2e-'));
const dataDir = path.join(tmp, 'data'), contentDir = path.join(tmp, 'content'), outDir = path.join(root, 'tests/out');
fs.mkdirSync(outDir, { recursive: true }); fs.cpSync(path.join(root, 'tests/fixtures/content'), contentDir, { recursive: true });
const env = { ...process.env, DATA_DIR: dataDir, CONTENT_DIR: contentDir, PUBLIC_URL: BASE, PORT: String(PORT), NODE_ENV: 'development' };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = []; const consoleErrors = [];
function check(name, ok, detail = '') { results.push({ name, ok: !!ok }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok || !detail ? '' : '   → ' + detail}`); return !!ok; }
async function until(fn, ms = 8000, step = 100) { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = await fn(); if (v) return v; } catch { /* retry */ } await sleep(step); } return null; }
const pages = {};
const step = async (name, fn) => { try { await fn(); } catch (e) { check(name + ' (crashed)', false, String(e.message).split('\n')[0]); for (const [k, p] of Object.entries(pages)) { try { await p.screenshot({ path: path.join(outDir, `crash-${name}-${k}.png`) }); } catch { /* page gone */ } } } };

// ---------------------------------------------------------------- server
let server; const serverLog = [];
async function startServer() {
  server = spawn(process.execPath, ['--no-warnings', 'dist/server.js'], { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
  server.stdout.on('data', (d) => serverLog.push(String(d))); server.stderr.on('data', (d) => serverLog.push(String(d)));
  if (!(await until(async () => (await fetch(BASE + '/healthz')).ok, 15000, 200))) throw new Error('server did not start:\n' + serverLog.join(''));
}
const stopServer = () => new Promise((res) => { if (!server) return res(); server.once('exit', res); server.kill('SIGTERM'); setTimeout(res, 4000); });
const cli = (...a) => execFileSync(process.execPath, ['--no-warnings', 'dist/cli.js', ...a], { cwd: root, env }).toString();
const invite = (slot) => cli('invite', slot).match(/http\S*invite=\S*/)[0];

// ---------------------------------------------------------------- page helpers
const S = (p) => p.evaluate(() => { const g = window.__olm.game; const f = (a) => ({ x: a.x, y: a.y, d: a.d, room: a.room, online: a.online, anim: g.effAnim(a), seat: a.seat }); return { me: f(g.me), peer: f(g.peer), ix: g.ix ? g.ix.kind + ':' + g.ix.stage : null }; });
const netStatus = (p) => p.evaluate(() => window.__olm?.net.status);
async function enter(page, url) {
  await page.goto(url); await page.click('.open-btn', { force: true });
  await page.waitForSelector('.museum canvas', { timeout: 20000 });
  await until(async () => (await netStatus(page)) === 'open', 15000);
  await until(async () => !(await page.locator('text=OPENING THE DOORS').count()), 10000); await sleep(300);
}
async function walkTo(page, x, y, tol = 5, maxMs = 30000) {
  const held = new Set(); const t0 = Date.now();
  const hold = async (want) => { for (const k of ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown']) { const w = want.has(k); if (w && !held.has(k)) { await page.keyboard.down(k); held.add(k); } else if (!w && held.has(k)) { await page.keyboard.up(k); held.delete(k); } } };
  try {
    while (Date.now() - t0 < maxMs) {
      const r = await page.evaluate(([x, y]) => { const g = window.__olm.game, m = g.me; const p = window.__olm.findPath(g.world, m.x, m.y, x, y); return { x: m.x, y: m.y, p }; }, [x, y]);
      if (Math.hypot(r.x - x, r.y - y) < tol) return true;
      if (!r.p) return false; const n = r.p.length <= 1 ? { x, y } : r.p[0]; const dx = n.x - r.x, dy = n.y - r.y; const want = new Set();
      if (dx > 2.5) want.add('ArrowRight'); else if (dx < -2.5) want.add('ArrowLeft'); if (dy > 2.5) want.add('ArrowDown'); else if (dy < -2.5) want.add('ArrowUp');
      await hold(want); await sleep(35);
    }
    return false;
  } finally { await hold(new Set()); }
}
const shot = (p, name) => p.screenshot({ path: path.join(outDir, name + '.png') });
const toastText = (p) => p.locator('.toasts').innerText().catch(() => '');
const btn = (p, name) => p.getByRole('button', { name });

// ================================================================ run
await startServer();
const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
const mk = async (opts) => { const c = await browser.newContext(opts); await c.addInitScript(() => { try { localStorage.setItem('olm.debug', '1'); localStorage.setItem('olm.hint-seen', '1'); localStorage.setItem('olm.vol', '0.05'); } catch { /* */ } }); return c; };
const attach = (p, tag) => { p.on('pageerror', (e) => consoleErrors.push(`${tag} pageerror: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource.*(401|403)/.test(m.text())) consoleErrors.push(`${tag} console: ${m.text()}`); }); };
const fatimaUrl = invite('fatima'), fatmidUrl = invite('fatmid');

// ---- TEST 15: a stranger
await step('stranger', async () => {
  const C = await mk({ viewport: { width: 1000, height: 700 } }); const p = await C.newPage(); attach(p, 'stranger');
  await p.goto(BASE); const html = await p.content();
  check('15a public gate shows no private content', !/Sample one|Sample melody|Fatima Athar/i.test(html) && /OUR LITTLE MUSEUM/.test(html));
  await p.click('.open-btn', { force: true }); const err = await until(async () => (await p.locator('.gate .err').count()) && (await p.locator('.gate .err').innerText()), 5000);
  check('15b "open" without an invitation is refused politely', /private/i.test(err || ''), err || 'no message');
  const codes = []; for (const u of ['/api/museum', '/api/media/1', '/api/media/1?v=thumb', '/api/notes']) codes.push((await C.request.get(BASE + u)).status());
  check('15c private API + photos return 401', codes.every((c) => c === 401), codes.join(','));
  const ws = await p.evaluate((u) => new Promise((res) => { const w = new WebSocket(u.replace('http', 'ws') + '/ws'); w.onopen = () => res('open'); w.onerror = () => res('refused'); w.onclose = () => res('refused'); setTimeout(() => res('timeout'), 4000); }), BASE);
  check('15d websocket refused without invitation', ws === 'refused', ws);
  const bad = await C.request.post(BASE + '/api/invite/redeem', { headers: { 'x-olm': '1', 'content-type': 'application/json' }, data: { token: 'abcd1234abcd1234.forgedforgedforgedforgedforged12' } });
  check('15e forged invitation token rejected', bad.status() === 403);
  const noHeader = await C.request.post(BASE + '/api/invite/redeem', { data: { token: fatimaUrl.split('invite=')[1] } });
  check('15f cross-site style POST (no x-olm header) rejected', noHeader.status() === 403, String(noHeader.status()));
  const adm = []; for (const u of ['/api/admin/me', '/api/admin/data', '/api/admin/login']) adm.push((await C.request.get(BASE + u)).status());
  check('15g no admin interface exists', adm.every((c) => c === 404), adm.join(','));
  await C.close();
});

// ---- TEST 1-3: both enter
const A = await mk({ viewport: { width: 1280, height: 800 } }); const pa = await A.newPage(); attach(pa, 'Fatmid'); pages.fatmid = pa;
const B = await mk({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); const pb = await B.newPage(); attach(pb, 'Fatima'); pages.fatima = pb;
await step('enter', async () => {
  await enter(pa, fatmidUrl); check('1 Fatmid opens the museum on a laptop', await pa.locator('.museum canvas').count() === 1);
  check('1b invitation token removed from the address bar', !pa.url().includes('invite='), pa.url());
  const alone = await pa.locator('.top-left .pill').nth(1).innerText(); check('1c alone: gentle offline indicator', /away/i.test(alone), alone);
  const offer = await until(async () => { const t = await pa.locator('.offer').innerText(); return /plays in this room/.test(t) ? t : null; }, 5000);
  check('1d room music is offered (not forced)', !!offer && !(await pa.evaluate(() => window.__olm.music.view.playing)), String(offer));
  await pb.goto(fatimaUrl); await sleep(500);
  check('2a Fatima sees her welcome on the gate', /Welcome home, Fatima/.test(await pb.locator('.gate .welcome').innerText()));
  await shot(pb, 'gate-mobile');
  await pb.click('.open-btn', { force: true }); await pb.waitForSelector('.museum canvas', { timeout: 20000 });
  await until(async () => (await netStatus(pb)) === 'open', 15000); await until(async () => !(await pb.locator('text=OPENING THE DOORS').count()), 10000); await sleep(600);
  const bOn = await until(async () => /is here/.test(await pb.locator('.top-left .pill').nth(1).innerText()), 5000);
  const aOn = await until(async () => /is here/.test(await pa.locator('.top-left .pill').nth(1).innerText()), 5000);
  check('2/3 Fatima joins and Fatmid is already there (she sees him)', bOn);
  check('2/3 Fatmid sees Fatima appear', aOn);
  const sa = await S(pa), sb = await S(pb); check('3 both characters in the same room', sa.me.room === sb.me.room && sa.peer.online && sb.peer.online, JSON.stringify([sa.me.room, sb.me.room]));
  await shot(pa, 'museum-fatmid'); await shot(pb, 'museum-fatima');
});

// ---- TEST 4/5: movement
await step('movement', async () => {
  let t0 = (await S(pb)).peer.x; await pa.keyboard.down('ArrowRight'); await sleep(800); await pa.keyboard.up('ArrowRight');
  const moved = await until(async () => (await S(pb)).peer.x > t0 + 30, 3000); check('4 Fatmid moves right; Fatima sees it', moved, `${t0} → ${(await S(pb)).peer.x}`);
  const ya = (await S(pa)).peer.y; await pb.keyboard.down('ArrowUp'); await sleep(500); await pb.keyboard.up('ArrowUp');
  check('5 Fatima moves up; Fatmid sees it', await until(async () => (await S(pa)).peer.y < ya - 15, 3000), `${ya} → ${(await S(pa)).peer.y}`);
  // wall collision: push left for a long time
  await pa.keyboard.down('ArrowLeft'); await sleep(3500); await pa.keyboard.up('ArrowLeft');
  const w = await pa.evaluate(() => { const g = window.__olm.game, r = g.world.rooms[0]; return { x: g.me.x, left: r.px + 32 }; });
  check('12a characters cannot walk through walls', w.x >= w.left + 6, JSON.stringify(w));
  // virtual joystick on the phone
  const jb = await pb.locator('.joy').boundingBox(); const px0 = (await S(pb)).me.x;
  await pb.mouse.move(jb.x + jb.width / 2, jb.y + jb.height / 2); await pb.mouse.down(); await pb.mouse.move(jb.x + jb.width / 2 + 40, jb.y + jb.height / 2, { steps: 4 }); await sleep(600); await pb.mouse.up();
  check('7a virtual joystick moves the phone character', (await S(pb)).me.x > px0 + 15, `${px0} → ${(await S(pb)).me.x}`);
});

// ---- notes + random messages
await step('notes', async () => {
  await pa.getByRole('button', { name: 'Menu' }).click(); await pa.getByRole('menuitem', { name: /LEAVE A NOTE/ }).click();
  await pa.locator('#note-text').fill('<img src=x onerror=alert(1)>See you at the bench <b>love</b>'); await pa.getByRole('button', { name: /Send/ }).click();
  const toast = await until(async () => /waiting/.test(await toastText(pb)), 5000); check('N1 recipient is told a note arrived', toast);
  await pb.getByRole('button', { name: 'Menu' }).click(); await pb.getByRole('menuitem', { name: /Notes for me/ }).click();
  const txt = await until(async () => { const t = await pb.locator('.sheet').innerText(); return /See you at the bench/.test(t) ? t : null; }, 5000) || await pb.locator('.sheet').innerText();
  check('N2 note delivered, scripts/HTML stripped', /See you at the bench/.test(txt) && !/onerror|<img|<b>/.test(txt), txt.slice(0, 120));
  check('N2b no injected element exists', await pb.locator('.sheet img').count() === 0);
  await pb.keyboard.press('Escape'); await sleep(300);
  await pb.getByRole('button', { name: 'Menu' }).click(); await pb.getByRole('menuitem', { name: /A LITTLE NOTE FOR YOU/ }).click();
  const seen = new Set(); let repeats = 0, last = '';
  for (let i = 0; i < 30; i++) { const q = (await pb.locator('.note-card blockquote').innerText()).trim(); if (q === last) repeats++; seen.add(q); last = q; await pb.getByRole('button', { name: /Another one/ }).click(); await sleep(40); }
  check('N3 random messages vary without immediate repeats', seen.size >= 20 && repeats === 0, `${seen.size} distinct, ${repeats} repeats`);
  await shot(pb, 'note-card-mobile'); await pb.keyboard.press('Escape'); await sleep(300);
});

// ---- TEST 6: shared viewing
let frame1;
await step('viewing', async () => {
  frame1 = await pa.evaluate(() => { const f = window.__olm.game.world.frames.find((f) => f.row.title === 'Sample one'); return { id: f.id, fx: f.fx, fy: f.fy }; });
  const [okA, okB] = await Promise.all([walkTo(pa, frame1.fx - 8, frame1.fy), walkTo(pb, frame1.fx + 26, frame1.fy)]);
  check('6a both walk to the same photograph (through doors/corridor)', okA && okB, `${okA} ${okB}`);
  await until(async () => (await pa.locator('button.prompt').count()) > 0, 3000); await shot(pa, 'near-photo');
  const prompt = await pa.locator('button.prompt').first().innerText(); check('6b "Press E to remember ♡" prompt', /remember/i.test(prompt), prompt);
  await pa.keyboard.press('e'); await pa.waitForSelector('.viewer', { timeout: 4000 });
  const v = await pa.locator('.viewer').innerText(); check('6c viewer shows title, caption and date', /Sample one/.test(v) && /A sample caption/.test(v) && /2024-01-01/.test(v) && /Play/.test(v), v.slice(0, 100));
  const imgOk = await until(() => pa.evaluate(() => { const i = document.querySelector('.viewer img'); return i && i.complete && i.naturalWidth > 0; }), 5000); check('6d photograph actually loads', imgOk);
  await shot(pa, 'viewer');
  const join = await until(async () => await pb.locator('.join-card').innerText(), 4000) || ''; check('6e peer is invited: "Fatmid is looking at this memory. Join him?"', /Fatmid is looking at this memory\. Join him\?/.test(join), join);
  await pb.getByRole('button', { name: /Join/ }).click(); await pb.waitForSelector('.viewer');
  const tg = await until(async () => (await pa.locator('.viewer .together').count()) && (await pb.locator('.viewer .together').count()), 4000);
  check('6f both viewing the same memory together', tg); await shot(pb, 'viewer-together-mobile');
  await pa.keyboard.press('Escape'); await until(async () => !(await pa.locator('.viewer').count()), 3000);
  check('6g one player can leave; the other stays', (await pa.locator('.viewer').count()) === 0 && (await pb.locator('.viewer').count()) === 1 && (await netStatus(pb)) === 'open');
  await pb.getByRole('button', { name: /Back to the museum/ }).click(); await sleep(300);
});

// ---- TEST 7: benches
await step('bench', async () => {
  const bench = await pa.evaluate((id) => { const b = window.__olm.game.world.benches.find((b) => b.frameId === id); return { key: b.key, seats: b.seats }; }, frame1.id);
  const [okA, okB] = await Promise.all([walkTo(pa, bench.seats[0].x, bench.seats[0].y + 24), walkTo(pb, bench.seats[1].x, bench.seats[1].y + 24)]);
  check('7a both walk up to the bench', okA && okB, JSON.stringify([okA, okB, (await S(pa)).me, (await S(pb)).me, bench.seats]));
  await until(async () => /SIT HERE/.test(await pa.locator('button.prompt').first().innerText().catch(() => '')), 3000);
  await shot(pa, 'sit-prompt'); await pa.getByRole('button', { name: /SIT HERE/ }).first().click();
  await until(async () => (await S(pa)).me.seat, 3000);
  await until(async () => /SIT HERE/.test(await pb.locator('button.prompt').first().innerText().catch(() => '')), 3000);
  await pb.getByRole('button', { name: /SIT HERE/ }).first().click();
  const both = await until(async () => { const a = await S(pa), b = await S(pb); return a.me.seat && b.me.seat && a.peer.seat && b.peer.seat; }, 4000);
  await sleep(600); const a = await S(pa); check('7b both seated on the same bench, each saw the other sit', both && a.me.seat.split(':')[0] === a.peer.seat.split(':')[0], JSON.stringify([a.me.seat, a.peer.seat]));
  check('7c "Some memories are better together." appears', (await until(async () => /better together/.test(await toastText(pa)), 3000)) !== null);
  check('7d seated characters are side by side', Math.abs(a.me.x - a.peer.x) < 40 && Math.abs(a.me.y - a.peer.y) < 6, JSON.stringify([a.me, a.peer]));
  await sleep(900); await shot(pa, 'sitting-together');
  check('7e STAND UP button shown', (await pa.getByRole('button', { name: 'STAND UP' }).count()) > 0);
  await pa.getByRole('button', { name: 'STAND UP' }).click(); await pb.getByRole('button', { name: 'STAND UP' }).click();
  check('7f both can stand up again', await until(async () => !(await S(pa)).me.seat && !(await S(pb)).me.seat, 3000));
});

// ---- TEST 8: dancing
await step('dance', async () => {
  await pa.locator('.actions-btn').click(); await shot(pa, 'actions-panel'); await pa.getByRole('button', { name: 'Dance · sway' }).click();
  check('8a Fatmid dances; Fatima sees the dance animation', await until(async () => (await S(pb)).peer.anim === 'dance1', 3000), (await S(pb)).peer.anim);
  await sleep(900); await shot(pb, 'dance-seen-by-fatima');
  await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: 'Return to idle' }).click();
  check('8b "return to idle" stops it for both', await until(async () => (await S(pb)).peer.anim === 'idle', 3000));
  await pb.locator('.actions-btn').click(); await pb.getByRole('button', { name: 'Send a heart' }).click();
  check('8c Fatima sends a heart; one-shot ends by itself', (await until(async () => (await S(pa)).peer.anim === 'heart', 2000)) && (await until(async () => (await S(pa)).peer.anim === 'idle', 5000)));
});

// ---- TEST 18: hugs
await step('hug', async () => {
  await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: /CAN I HAVE A HUG/ }).click();
  const inv = await until(async () => await pb.locator('.sheet').innerText(), 3000) || ''; check('18a Fatima receives the hug invitation', /hug/i.test(inv), inv.slice(0, 60));
  await shot(pb, 'hug-invite-mobile'); await pb.getByRole('button', { name: 'Not now' }).click();
  const tt = await until(async () => /maybe a little later/i.test(await toastText(pa)), 3000);
  check('18b declined hug: neutral, kind response (nothing negative)', tt && !/declin|reject|refus|no\b/i.test(await toastText(pa)), await toastText(pa));
  await sleep(500); await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: /CAN I HAVE A HUG/ }).click();
  await pb.getByRole('button', { name: /Of course/ }).click();
  const hug = await until(async () => (await S(pa)).me.anim === 'hug' && (await S(pb)).me.anim === 'hug', 4000); check('18c accepted hug: both play a synchronised hug', hug);
  const s = await S(pa); check('18d characters moved close together', Math.abs(s.me.x - s.peer.x) < 40, JSON.stringify([s.me.x, s.peer.x])); await shot(pa, 'hug');
  check('18e hug ends and both return to normal', await until(async () => (await S(pa)).me.anim === 'idle' && (await S(pb)).me.anim === 'idle' && !(await S(pa)).ix, 7000));
});

// ---- TEST 9/10: the proposal
await step('proposal', async () => {
  check('9a only Fatmid has the proposal button', (await (async () => { await pb.locator('.actions-btn').click(); const n = await pb.getByRole('button', { name: /ONE LITTLE QUESTION/ }).count(); await pb.keyboard.press('Escape'); return n; })()) === 0);
  await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: /ONE LITTLE QUESTION/ }).click();
  const inv = await until(async () => await pb.locator('.sheet h2').innerText(), 3000) || ''; check('9b Fatima receives the invitation first', /one little question/i.test(inv), inv);
  await pb.getByRole('button', { name: 'Not now' }).click();
  check('10 Fatima declines: handled gently, nothing locked', (await until(async () => /maybe a little later/i.test(await toastText(pa)), 3000)) && !(await S(pa)).ix && !(await pa.locator('.cine').count()));
  await sleep(600); await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: /ONE LITTLE QUESTION/ }).click(); await pb.getByRole('button', { name: /Okay/ }).click();
  const k = await until(async () => (await S(pa)).me.anim === 'kneel', 5000); check('9c accepted: Fatmid kneels, Fatima blushes', k && (await S(pb)).me.anim === 'shy', JSON.stringify([(await S(pa)).me.anim, (await S(pb)).me.anim]));
  await sleep(1800); await shot(pa, 'proposal-ring');
  const l1 = await until(async () => /if I could collect every beautiful moment of my life and place it in one room, you would still be my favourite part of it\./.test(await pb.locator('.cine').innerText()), 9000);
  check('9d first message appears exactly as written', l1); await shot(pb, 'proposal-message-mobile');
  const l2 = await until(async () => /Will you keep making beautiful memories with me\? ♡/.test(await pb.locator('.cine').innerText()), 10000); check('9e second message after a pause', l2);
  const ans = await until(async () => (await pb.getByRole('button', { name: 'YES, MY LOVE ♡' }).count()) && (await pb.getByRole('button', { name: /HUG FIRST/ }).count()) && (await pb.getByRole('button', { name: /NOT YET/ }).count()), 8000);
  check('9f Fatima gets all three answers; Fatmid only waits', ans && (await pa.getByRole('button', { name: 'YES, MY LOVE ♡' }).count()) === 0 && /Waiting for/.test(await pa.locator('.cine').innerText()));
  await shot(pb, 'proposal-answers-mobile');
  await pb.getByRole('button', { name: /HUG FIRST/ }).click(); check('9g "hug first" → synchronised hug', await until(async () => (await S(pa)).me.anim === 'hug' && (await S(pb)).me.anim === 'hug', 3000));
  await until(async () => (await pb.getByRole('button', { name: /NOT YET/ }).count()) > 0, 8000);
  await pb.getByRole('button', { name: /NOT YET/ }).click(); const later = await until(async () => /The museum will wait/.test(await pa.locator('.cine').innerText()), 3000);
  check('9h "not yet" ends gently without pressure', later && await until(async () => !(await pa.locator('.cine').count()) && !(await S(pa)).ix, 8000));
  // replay the scene and say yes
  await sleep(500); await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: /ONE LITTLE QUESTION/ }).click(); await pb.getByRole('button', { name: /Okay/ }).click();
  await until(async () => (await pb.getByRole('button', { name: 'YES, MY LOVE ♡' }).count()) > 0, 25000); await pb.getByRole('button', { name: 'YES, MY LOVE ♡' }).click();
  const yes = await until(async () => (await S(pa)).me.anim === 'cheer' && (await S(pb)).me.anim === 'cheer', 3000); check('9i replay + yes → celebration animation for both', yes); await sleep(700); await shot(pa, 'proposal-yes');
  check('9j scene ends and the museum is free again', await until(async () => !(await S(pa)).ix && !(await pb.locator('.cine').count()), 12000));
});

// ---- TEST 11: shared music
await step('music', async () => {
  await pa.getByRole('button', { name: 'Music' }).click(); const names = await pa.locator('.tracklist').innerText(); check('11a songs from content/ are in the player', /Sample Melody/.test(names) && /another sample/.test(names), names);
  await pa.getByRole('button', { name: /Listen together with/ }).click();
  const req = await until(async () => /would like to listen together/.test(await pb.locator('.music').innerText()), 4000); check('11b Fatima is asked (panel opens by itself)', req);
  await pb.getByRole('button', { name: 'Listen together' }).click();
  check('11c shared mode on for both', await until(async () => (await pa.evaluate(() => window.__olm.music.view.shared)) && (await pb.evaluate(() => window.__olm.music.view.shared)), 3000));
  await pa.locator('.track', { hasText: 'Sample Melody' }).click();
  const same = await until(async () => { const a = await pa.evaluate(() => window.__olm.music.view), b = await pb.evaluate(() => window.__olm.music.view); return a.track && a.track === b.track && b.playing ? [a, b] : null; }, 5000);
  check('11d same track starts on both devices', !!same, JSON.stringify(same));
  const drift = await pa.evaluate(() => window.__olm.music.audio.currentTime) - await pb.evaluate(() => window.__olm.music.audio.currentTime); check('11e playback positions within 1.5 s', Math.abs(drift) < 1.5, drift.toFixed(2));
  await pa.getByRole('button', { name: 'Pause' }).click(); check('11f pause is shared', await until(async () => !(await pb.evaluate(() => window.__olm.music.view.playing)), 3000));
  await pa.getByRole('button', { name: /Listen on my own/ }).click(); check('11g either person can go back to personal mode', await until(async () => !(await pb.evaluate(() => window.__olm.music.view.shared)), 3000));
  await pa.getByRole('button', { name: 'Music' }).click(); await pb.keyboard.press('Escape');
});

// ---- extras: timeline, hold hands, dance together, photo moment, look, reduced motion, Space, Promise Room
await step('extras', async () => {
  // timeline
  await pb.getByRole('button', { name: 'Menu' }).click(); await pb.getByRole('menuitem', { name: /HOW OUR STORY UNFOLDED/ }).click();
  await pb.waitForSelector('.tl-item'); const tl = await pb.locator('.tl').innerText();
  check('20a timeline lists the entries in order', /Sample beginning/.test(tl) && /Sample later/.test(tl) && tl.indexOf('Sample beginning') < tl.indexOf('Sample later'), tl.slice(0, 80));
  check('20b timeline photo loads', !!(await until(() => pb.evaluate(() => { const i = document.querySelector('.tl img'); return i && i.complete && i.naturalWidth > 0; }), 5000)));
  await shot(pb, 'timeline-mobile'); await pb.keyboard.press('Escape'); await until(async () => !(await pb.locator('.tl').count()), 2000);
  check('20c timeline closes with Escape', (await pb.locator('.tl').count()) === 0);

  // hold hands
  await pa.locator('.actions-btn').click(); await pa.getByRole('button', { name: 'Hold hands' }).click();
  await pb.getByRole('button', { name: /^Yes/ }).click();
  check('21a hand-holding accepted: both see it', await until(async () => /Holding hands/.test(await pa.locator('.chip-top').innerText().catch(() => '')) && /Holding hands/.test(await pb.locator('.chip-top').innerText().catch(() => '')), 4000));
  const h0 = await S(pb); let best = null;
  for (const key of ['ArrowRight', 'ArrowLeft']) {
    await pa.keyboard.down(key); await sleep(900); await pa.keyboard.up(key); await sleep(700);
    const ha = await S(pa), hb = await S(pb); const moved = Math.hypot(hb.me.x - h0.me.x, hb.me.y - h0.me.y), apart = Math.hypot(ha.me.x - hb.me.x, ha.me.y - hb.me.y);
    if (!best || moved > best.moved) best = { moved, apart, key };
    if (moved > 15) break;
  }
  check('21b they walk together at a comfortable distance', best.moved > 15 && best.apart < 90, `partner moved ${best.moved.toFixed(0)}px going ${best.key}, apart ${best.apart.toFixed(0)}px`);
  await shot(pa, 'hold-hands'); await pb.getByRole('button', { name: 'Let go' }).click();
  check('21c either person can let go', await until(async () => !(await S(pa)).ix && !(await S(pb)).ix, 3000));

  // dance together
  await pb.locator('.actions-btn').click(); await pb.getByRole('button', { name: 'Dance together' }).click(); await pa.getByRole('button', { name: /dance/i }).first().click();
  check('22a dance together: both dance the same way', await until(async () => { const a = await S(pa), b = await S(pb); return /^dance/.test(a.me.anim) && a.me.anim === b.me.anim && a.me.anim === a.peer.anim; }, 4000));
  await sleep(700); await shot(pa, 'dance-together'); await pa.getByRole('button', { name: 'Stop' }).click();
  check('22b either can stop; both return to idle', await until(async () => (await S(pa)).me.anim === 'idle' && (await S(pb)).me.anim === 'idle' && !(await S(pa)).ix, 4000));

  // Space = the contextual action
  await sleep(400); const sp0 = await S(pa); await pa.keyboard.press(' ');
  check('23 Space performs the contextual action (dance, or sit on a nearby bench)', await until(async () => { const s = await S(pa); return /^dance/.test(s.me.anim) || !!s.me.seat; }, 2500), JSON.stringify(sp0.me));
  await pa.keyboard.press(' '); await until(async () => { const s = await S(pa); return s.me.anim === 'idle' && !s.me.seat; }, 3000);

  // character: new look + reduced motion
  await pb.getByRole('button', { name: 'Menu' }).click(); await pb.getByRole('menuitem', { name: /Settings/ }).click();
  await pb.locator('#hair').selectOption('bob'); await pb.locator('#outfit').selectOption('cardigan');
  await pb.getByLabel(/Reduce motion/).check(); check('24a reduced-motion switch applies', await until(async () => await pb.evaluate(() => !!document.querySelector('.museum.reduce-motion')), 2000));
  await pb.getByLabel(/Reduce motion/).uncheck(); await shot(pb, 'settings-mobile'); await pb.getByRole('button', { name: 'Save my look' }).click();
  const look = await until(async () => { const l = await pa.evaluate(() => window.__olm.game.bundle.players.fatima.look); return l.hair === 'bob' && l.outfit === 'cardigan' ? l : null; }, 8000);
  check('24b new hairstyle/clothing saved and Fatmid sees it live', !!look, JSON.stringify(look));

  // photo moment
  await pa.getByRole('button', { name: 'Menu' }).click(); await pa.getByRole('menuitem', { name: /LET'S TAKE A MEMORY/ }).click();
  await pa.getByRole('button', { name: /^Polaroid/ }).click(); await pa.getByRole('button', { name: /^Ask/ }).click();
  await pb.getByRole('button', { name: /^Smile/ }).click();
  check('25a countdown shows for both', !!(await until(async () => (await pa.locator('.big-count').count()) && (await pb.locator('.big-count').count()), 8000)));
  const res = await until(async () => (await pa.locator('.photo-result img').count()) && (await pb.locator('.photo-result img').count()), 15000);
  check('25b both receive the picture', !!res); await shot(pb, 'photo-result-mobile');
  const [dl] = await Promise.all([pa.waitForEvent('download', { timeout: 8000 }), pa.getByRole('button', { name: 'Save picture' }).click()]);
  const file = path.join(outDir, 'our-little-memory.png'); await dl.saveAs(file);
  const sharp = (await import('sharp')).default; const meta = await sharp(file).metadata(); const st = await sharp(file).stats();
  check('25c saved picture is a real image with a frame (not blank)', dl.suggestedFilename() === 'our-little-memory.png' && meta.format === 'png' && meta.width >= 960 && st.channels.slice(0, 3).every((c) => c.stdev > 8), `${meta.width}x${meta.height} ${st.channels.map((c) => c.stdev.toFixed(0)).join('/')}`);
  await pa.getByRole('button', { name: 'Close' }).first().click(); await pb.getByRole('button', { name: 'Close' }).first().click();
  check('25d the museum is free again after the photo', await until(async () => !(await S(pa)).ix && !(await pa.locator('.photo-result').count()), 4000));

  // the Promise Room pedestal (long walk through the museum)
  const ped = await pa.evaluate(() => { const p = window.__olm.game.world.props.find((p) => p.kind === 'pedestal'); return { x: p.tx * 32 + 16, y: (p.ty + 1) * 32 + 14 }; });
  const there = await walkTo(pa, ped.x, ped.y, 6, 90000); const room = await pa.evaluate(() => window.__olm.game.getUi().roomName);
  check('26a Fatmid can walk all the way to the Promise Room', there && /Promise/.test(room), room);
  const pedOk = await until(async () => { await pa.keyboard.press('e'); await sleep(250); return (await pa.locator('.sheet h2').innerText().catch(() => '')).includes('PROMISE ROOM'); }, 4000);
  check('26b the pedestal offers "ONE LITTLE QUESTION"', !!pedOk && (await pa.getByRole('button', { name: /ONE LITTLE QUESTION/ }).count()) > 0); await shot(pa, 'promise-room');
  await pa.getByRole('button', { name: 'Not yet' }).click();
});

// ---- TEST 13/14: content updates without a restart
await step('content', async () => {
  const before = await pa.evaluate(() => window.__olm.game.bundle.frames.length);
  const cj = path.join(contentDir, 'content.json'); const c = JSON.parse(fs.readFileSync(cj, 'utf8'));
  fs.copyFileSync(path.join(contentDir, 'photos/sample6.jpg'), path.join(contentDir, 'photos/brand-new.jpg'));
  c.photos.push({ file: 'brand-new.jpg', title: 'Brand new memory', caption: 'Added while we were inside', room: 2, wall: 'south', bench: true });
  c.rooms['2'] = { song: 'another_sample.wav' }; fs.writeFileSync(cj, JSON.stringify(c, null, 2));
  const ok = await until(async () => (await pa.evaluate(() => window.__olm.game.bundle.frames.length)) === before + 1 && (await pb.evaluate(() => window.__olm.game.bundle.frames.length)) === before + 1, 25000, 500);
  check('13 new photo appears for both players without a restart/refresh', ok, `frames before ${before}`);
  const room2 = await pa.evaluate(() => { const b = window.__olm.game.bundle; const r = b.rooms[1]; return { track: r.music_track_id, title: b.tracks.find((t) => t.id === r.music_track_id)?.title }; });
  check('14 song assigned to a room via content.json', /another sample/.test(room2.title || ''), JSON.stringify(room2));
  const stat = await pa.evaluate(async () => { const f = window.__olm.game.bundle.frames.find((f) => f.title === 'Brand new memory'); const r = await fetch('/api/media/' + f.photo_id); return r.status; }); check('13b the new photo is downloadable by a player', stat === 200, String(stat));
});

// ---- TEST 16: narrow phones
await step('narrow', async () => {
  for (const [w, h] of [[390, 844], [320, 568]]) {
    await pb.setViewportSize({ width: w, height: h }); await sleep(500);
    const o = await pb.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: innerWidth, joy: !!document.querySelector('.joy') && getComputedStyle(document.querySelector('.joy')).display !== 'none', btn: document.querySelector('.actions-btn')?.getBoundingClientRect().height }));
    check(`16 ${w}px wide: no sideways scroll, joystick shown, buttons ≥ 44px`, o.sw <= o.iw && o.joy && o.btn >= 44, JSON.stringify(o));
    await pb.locator('.actions-btn').click(); const r = await pb.locator('.act-sheet').boundingBox(); await shot(pb, `actions-${w}`);
    check(`16b ${w}px: the actions sheet fits on screen`, r && r.x >= 0 && r.x + r.width <= w + 1 && r.y >= 0 && r.y + r.height <= h + 1, JSON.stringify(r));
    await pb.getByRole('button', { name: 'Close' }).click(); check(`16c ${w}px: the sheet has a visible close button that works`, await until(async () => !(await pb.locator('.act-sheet').count()), 2000));
  }
  await pb.setViewportSize({ width: 390, height: 844 }); await sleep(300);
});

// ---- TEST 17 + 12: refresh and reconnect
await step('refresh', async () => {
  const before = await S(pb); await pb.reload();
  check('17a after refresh the gate greets her by name (session remembered)', /Welcome home, Fatima/.test(await until(async () => await pb.locator('.gate .welcome').innerText(), 5000) || ''));
  await pb.click('.open-btn', { force: true }); await pb.waitForSelector('.museum canvas'); await until(async () => (await netStatus(pb)) === 'open', 15000); await sleep(800);
  const after = await S(pb); check('17b she returns to where she was, as the same player', after.me.room === before.me.room && Math.hypot(after.me.x - before.me.x, after.me.y - before.me.y) < 40, JSON.stringify([before.me, after.me]));
  check('17c Fatmid sees only ONE Fatima, online', (await S(pa)).peer.online);
  const pages = await B.pages().length; check('17d no duplicate player created', pages === 1);
});
await step('reconnect', async () => {
  const before = await S(pb);
  await pb.evaluate(() => window.__olm.net.ws.close()); // simulate a dropped connection
  const sawOff = await until(async () => !(await S(pa)).peer.online, 3000); check('12b Fatmid sees a gentle offline indicator when she drops', sawOff && /away/.test(await pa.locator('.top-left .pill').nth(1).innerText()));
  const back = await until(async () => (await netStatus(pb)) === 'open' && (await S(pa)).peer.online, 12000); check('12c she reconnects automatically and reappears', back);
  const after = await S(pb); check('12d same place after reconnecting', Math.hypot(after.me.x - before.me.x, after.me.y - before.me.y) < 10);
  const t0 = Date.now(); await stopServer(); await sleep(1500); const banner = (await pa.locator('.banner').count()) + (await netStatus(pa) !== 'open' ? 1 : 0);
  check('12e server outage: clients show "Reconnecting"', banner > 0);
  await startServer(); const both = await until(async () => (await netStatus(pa)) === 'open' && (await netStatus(pb)) === 'open' && (await S(pa)).peer.online, 25000, 300);
  check('12f after a server restart both clients recover by themselves', both, `${((Date.now() - t0) / 1000).toFixed(1)}s`);
  const rb = await S(pb); check('12g positions survive the restart', Math.hypot(rb.me.x - before.me.x, rb.me.y - before.me.y) < 40, JSON.stringify([before.me, rb.me]));
});

// ---- second browser tab for the same person must not create a second player
await step('dup', async () => {
  const p2 = await B.newPage(); attach(p2, 'Fatima-2'); await p2.goto(BASE); await p2.click('.open-btn', { force: true }); await p2.waitForSelector('.museum canvas'); await sleep(1500);
  const replaced = await until(async () => (await pb.locator('text=OPEN IN ANOTHER WINDOW').count()) > 0, 4000);
  check('8d a second window takes over; the first pauses (no duplicate characters)', replaced); await shot(pb, 'replaced-window');
  await p2.close(); await pb.getByRole('button', { name: 'Use this window' }).click(); check('8e she can switch back', await until(async () => (await netStatus(pb)) === 'open' && (await S(pa)).peer.online, 8000));
});

// ---- TEST 19: revoke
await step('revoke', async () => {
  const id = fatimaUrl.split('invite=')[1].split('.')[0]; check('19a invitation listed as active', new RegExp(id + '.*active').test(cli('list')));
  cli('revoke', id);
  const out = await until(async () => (await pb.locator('text=THE DOOR WAS CLOSED').count()) > 0, 30000, 500); check('19b revoked: her open museum is closed within ~30 s', out); await shot(pb, 'revoked');
  check('19c Fatmid sees her leave', await until(async () => !(await S(pa)).peer.online, 5000));
  const r = await B.request.get(BASE + '/api/museum'); check('19d her old session no longer works', r.status() === 401, String(r.status()));
  const C = await mk({ viewport: { width: 400, height: 800 } }); const p = await C.newPage(); await p.goto(fatimaUrl); await p.click('.open-btn', { force: true });
  check('19e the revoked link is refused', /not valid any more/i.test(await until(async () => await p.locator('.gate .err').innerText(), 5000) || '')); await C.close();
  const fresh = invite('fatima'); await pb.goto(fresh); await pb.click('.open-btn', { force: true }); await pb.waitForSelector('.museum canvas', { timeout: 15000 });
  check('19f a new invitation works again', await until(async () => (await S(pa)).peer.online, 10000));
  // a slow phone: she taps "Open" before the invitation check has finished
  const slow = await mk({ viewport: { width: 400, height: 800 } }); const ps = await slow.newPage(); attach(ps, 'slow-phone');
  await ps.route('**/api/invite/peek*', async (r) => { await sleep(1500); await r.continue(); });
  await ps.goto(invite('fatima')); await ps.click('.open-btn', { force: true });
  check('19g tapping "Open" before the invitation check finishes still works', !!(await until(async () => (await ps.locator('.museum canvas').count()) > 0, 20000)));
  await slow.close();
});

const realErrors = consoleErrors.filter((e) => /pageerror/.test(e) || !/WebSocket connection to|ERR_CONNECTION_REFUSED|Failed to load resource/.test(e)); // the refused sockets / outage are deliberate parts of the tests
check('no unexpected browser errors (page exceptions, failed requests)', realErrors.length === 0, realErrors.slice(0, 4).join(' | '));
await browser.close(); await stopServer();
const failed = results.filter((r) => !r.ok); console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
if (failed.length) { console.log('FAILED:\n  ' + failed.map((f) => f.name).join('\n  ')); console.log('\nserver log tail:\n' + serverLog.join('').split('\n').slice(-12).join('\n')); }
fs.rmSync(tmp, { recursive: true, force: true }); process.exit(failed.length ? 1 : 0);
